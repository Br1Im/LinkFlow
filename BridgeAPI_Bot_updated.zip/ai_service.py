# ai_service.py - AI Service для генерации контента через ProxyAPI.ru
import requests
import base64
import json
import asyncio
import aiohttp
from typing import Dict, Any, Optional, List
import config
from PIL import Image
from io import BytesIO

class AIService:
    """Сервис для работы с AI моделями через ProxyAPI.ru"""
    
    def __init__(self):
        self.api_key = config.PROXYAPI_KEY
        self.base_url = "https://api.proxyapi.ru/openai/v1"
        self.headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
    
    async def generate_text(self, prompt: str, model: str = "gpt-4o-mini") -> Dict[str, Any]:
        """
        Генерация текста через OpenAI API
        
        Args:
            prompt: Текстовый промпт
            model: Модель для генерации (по умолчанию gpt-4o-mini - самая дешевая)
            
        Returns:
            Dict с результатом генерации
        """
        try:
            payload = {
                "model": model,
                "messages": [
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                "max_tokens": 1000,
                "temperature": 0.7
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{self.base_url}/chat/completions",
                    headers=self.headers,
                    json=payload,
                    timeout=30
                ) as response:
                    
                    if response.status == 200:
                        data = await response.json()
                        
                        if "choices" in data and len(data["choices"]) > 0:
                            generated_text = data["choices"][0]["message"]["content"].strip()
                            
                            return {
                                "success": True,
                                "text": generated_text,
                                "model": model,
                                "usage": data.get("usage", {})
                            }
                    
                    error_text = await response.text()
                    return {
                        "success": False,
                        "error": f"API Error {response.status}",
                        "details": error_text
                    }
                    
        except Exception as e:
            return {
                "success": False,
                "error": "Network error",
                "details": str(e)
            }
    
    async def generate_image(self, prompt: str, model: str = "gpt-image-1-mini") -> Dict[str, Any]:
        """
        Генерация изображений через OpenAI API
        
        Args:
            prompt: Описание изображения
            model: Модель (gpt-image-1-mini - самая дешевая)
            
        Returns:
            Dict с base64 изображением или ссылкой
        """
        try:
            payload = {
                "model": model,
                "prompt": prompt,
                "size": "1024x1024",
                "quality": "high"  # Исправлено: используем "high" вместо "standard"
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{self.base_url}/images/generations",
                    headers=self.headers,
                    json=payload,
                    timeout=60  # Генерация изображений может занять больше времени
                ) as response:
                    
                    if response.status == 200:
                        data = await response.json()
                        
                        if "data" in data and len(data["data"]) > 0:
                            image_data = data["data"][0]
                            
                            # Для gpt-image-1 возвращается base64
                            if "b64_json" in image_data:
                                return {
                                    "success": True,
                                    "image_base64": image_data["b64_json"],
                                    "model": model,
                                    "format": "base64"
                                }
                            # Для DALL-E возвращается URL
                            elif "url" in image_data:
                                return {
                                    "success": True,
                                    "image_url": image_data["url"],
                                    "model": model,
                                    "format": "url"
                                }
                    
                    error_text = await response.text()
                    return {
                        "success": False,
                        "error": f"API Error {response.status}",
                        "details": error_text
                    }
                    
        except Exception as e:
            return {
                "success": False,
                "error": "Network error",
                "details": str(e)
            }
    
    async def generate_video(self, prompt: str, model: str = "sora-2") -> Dict[str, Any]:
        """
        Генерация видео через Sora API
        
        Args:
            prompt: Описание видео
            model: Модель (sora-2 - быстрая и дешевая)
            
        Returns:
            Dict с информацией о задании
        """
        try:
            # Используем JSON с правильными типами данных
            payload = {
                "prompt": prompt,
                "model": model,
                "size": "1280x720",
                "seconds": "4"  # Исправлено: используем строку и допустимое значение
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{self.base_url}/videos",
                    headers=self.headers,
                    json=payload,
                    timeout=30
                ) as response:
                    
                    if response.status == 200:
                        data = await response.json()
                        
                        return {
                            "success": True,
                            "video_id": data.get("id"),
                            "status": data.get("status"),
                            "model": model,
                            "message": "Видео генерируется. Проверьте статус через несколько минут."
                        }
                    
                    error_text = await response.text()
                    return {
                        "success": False,
                        "error": f"API Error {response.status}",
                        "details": error_text
                    }
                    
        except Exception as e:
            return {
                "success": False,
                "error": "Network error",
                "details": str(e)
            }
    
    def resize_image_to_target(self, image_data: bytes, target_size: str = "1280x720") -> bytes:
        """
        Изменяет размер изображения под нужное разрешение
        
        Args:
            image_data: Исходные данные изображения
            target_size: Целевой размер в формате "ширинаxвысота"
            
        Returns:
            bytes: Данные изображения с новым размером
        """
        try:
            # Парсим целевой размер
            width, height = map(int, target_size.split('x'))
            
            # Открываем изображение
            image = Image.open(BytesIO(image_data))
            
            # Изменяем размер с сохранением пропорций
            image = image.resize((width, height), Image.Resampling.LANCZOS)
            
            # Конвертируем в RGB если нужно
            if image.mode != 'RGB':
                image = image.convert('RGB')
            
            # Сохраняем в байты
            output = BytesIO()
            image.save(output, format='JPEG', quality=95)
            return output.getvalue()
            
        except Exception as e:
            print(f"❌ Error resizing image: {e}")
            return image_data  # Возвращаем оригинал при ошибке

    async def animate_photo(self, prompt: str, image_data: bytes, model: str = "sora-2") -> Dict[str, Any]:
            """
            Оживление фото через Sora API с референсным изображением

            Args:
                prompt: Описание анимации
                image_data: Данные изображения в байтах
                model: Модель (sora-2 - быстрая и дешевая)

            Returns:
                Dict с информацией о задании
            """
            try:
                print(f"🔍 Starting animate_photo with prompt: {prompt}")
                print(f"🔍 Original image data size: {len(image_data)} bytes")
                
                # Изменяем размер изображения под нужное разрешение
                target_size = "1280x720"
                resized_image_data = self.resize_image_to_target(image_data, target_size)
                print(f"🔍 Resized image data size: {len(resized_image_data)} bytes")
                
                # Создаем задание на генерацию видео с референсным изображением
                form_data = aiohttp.FormData()
                form_data.add_field('prompt', prompt)
                form_data.add_field('model', model)
                form_data.add_field('size', target_size)
                form_data.add_field('seconds', '4')

                # Добавляем референсное изображение с правильным параметром input_reference
                form_data.add_field('input_reference', resized_image_data, 
                                  filename='reference.jpg', 
                                  content_type='image/jpeg')

                print(f"🔍 Form data prepared, making request to {self.base_url}/videos")

                headers_video = {
                    "Authorization": f"Bearer {self.api_key}"
                }

                async with aiohttp.ClientSession() as session:
                    async with session.post(
                        f"{self.base_url}/videos",
                        headers=headers_video,
                        data=form_data,
                        timeout=30
                    ) as response:

                        print(f"🔍 Animate photo response: {response.status}")
                        response_text = await response.text()
                        print(f"📄 Response body: {response_text}")

                        if response.status == 200:
                            try:
                                data = await response.json()
                                return {
                                    "success": True,
                                    "video_id": data.get("id"),
                                    "status": data.get("status"),
                                    "model": model,
                                    "message": "Фото оживляется. Проверьте статус через несколько минут."
                                }
                            except Exception as json_error:
                                print(f"❌ JSON parsing error: {json_error}")
                                return {
                                    "success": False,
                                    "error": "Invalid JSON response",
                                    "details": f"JSON error: {json_error}, Response: {response_text}"
                                }

                        print(f"❌ API returned error {response.status}: {response_text}")
                        return {
                            "success": False,
                            "error": f"API Error {response.status}",
                            "details": response_text
                        }

            except Exception as e:
                return {
                    "success": False,
                    "error": "Network error",
                    "details": str(e)
                }

    
    async def check_video_status(self, video_id: str) -> Dict[str, Any]:
        """
        Проверка статуса генерации видео
        
        Args:
            video_id: ID видео задания
            
        Returns:
            Dict со статусом видео
        """
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    f"{self.base_url}/videos/{video_id}",
                    headers=self.headers,
                    timeout=10
                ) as response:
                    
                    if response.status == 200:
                        data = await response.json()
                        
                        return {
                            "success": True,
                            "video_id": video_id,
                            "status": data.get("status"),
                            "progress": data.get("progress", 0),
                            "ready": data.get("status") == "completed"
                        }
                    
                    return {
                        "success": False,
                        "error": f"API Error {response.status}"
                    }
                    
        except Exception as e:
            return {
                "success": False,
                "error": "Network error",
                "details": str(e)
            }
    
    async def download_video(self, video_id: str) -> Dict[str, Any]:
        """
        Скачивание готового видео
        
        Args:
            video_id: ID видео
            
        Returns:
            Dict с видео данными
        """
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    f"{self.base_url}/videos/{video_id}/content",
                    headers=self.headers,
                    timeout=60
                ) as response:
                    
                    if response.status == 200:
                        video_data = await response.read()
                        
                        return {
                            "success": True,
                            "video_data": video_data,
                            "content_type": response.headers.get("content-type", "video/mp4")
                        }
                    
                    return {
                        "success": False,
                        "error": f"API Error {response.status}"
                    }
                    
        except Exception as e:
            return {
                "success": False,
                "error": "Network error",
                "details": str(e)
            }
    
    # Готовые функции для конкретных задач
    
    async def generate_post(self, topic: str) -> Dict[str, Any]:
        """Генерация поста для Telegram канала"""
        prompt = f"""
        Создай интересный пост для Telegram канала на тему: {topic}
        
        Требования:
        - Длина: 200-300 слов
        - Используй эмодзи
        - Добавь призыв к действию
        - Сделай текст увлекательным и полезным
        - Используй разметку Telegram (жирный, курсив)
        """
        
        return await self.generate_text(prompt, "gpt-4o-mini")
    
    async def generate_channel_names(self, theme: str) -> Dict[str, Any]:
        """Генерация названий для канала"""
        prompt = f"""
        Придумай 10 креативных названий для Telegram канала на тему: {theme}
        
        Требования:
        - Названия должны быть запоминающимися
        - Длина: 3-20 символов
        - Подходящие для русскоязычной аудитории
        - Разные стили: серьезные, игривые, профессиональные
        
        Формат ответа:
        1. Название - краткое описание
        2. Название - краткое описание
        ...
        """
        
        return await self.generate_text(prompt, "gpt-4o-mini")
    
    async def generate_personal_prompt(self, task: str, context: str = "") -> Dict[str, Any]:
        """Генерация персонального промпта для ChatGPT/Claude"""
        prompt = f"""
        Создай детальный промпт для ChatGPT/Claude для решения задачи: {task}
        
        Контекст: {context}
        
        Промпт должен включать:
        - Четкую роль для AI
        - Подробное описание задачи
        - Формат ожидаемого ответа
        - Примеры (если нужно)
        - Ограничения и требования
        
        Сделай промпт максимально эффективным и подробным.
        """
        
        return await self.generate_text(prompt, "gpt-4o-mini")
    
    def calculate_water_intake(self, weight: float, activity_level: str = "medium") -> Dict[str, Any]:
        """Расчет нормы воды по весу"""
        try:
            # Базовая формула: 30-35 мл на кг веса
            base_water = weight * 32  # мл
            
            # Коррекция по активности
            activity_multipliers = {
                "low": 1.0,
                "medium": 1.2,
                "high": 1.5
            }
            
            multiplier = activity_multipliers.get(activity_level, 1.2)
            total_water = base_water * multiplier
            
            # Конвертация в литры
            water_liters = total_water / 1000
            
            return {
                "success": True,
                "weight": weight,
                "activity_level": activity_level,
                "daily_water_ml": int(total_water),
                "daily_water_liters": round(water_liters, 1),
                "glasses_200ml": int(total_water / 200),
                "recommendation": f"Рекомендуется пить {round(water_liters, 1)} литров воды в день ({int(total_water / 200)} стаканов по 200мл)"
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def calculate_bju(self, weight: float, height: float, age: int, gender: str, activity: str, goal: str = "maintain") -> Dict[str, Any]:
        """Расчет БЖУ (белки, жиры, углеводы)"""
        try:
            # Расчет базового метаболизма (формула Миффлина-Сан Жеора)
            if gender.lower() in ["м", "мужской", "male"]:
                bmr = 10 * weight + 6.25 * height - 5 * age + 5
            else:
                bmr = 10 * weight + 6.25 * height - 5 * age - 161
            
            # Коэффициенты активности
            activity_coeffs = {
                "низкая": 1.2,
                "легкая": 1.375,
                "умеренная": 1.55,
                "высокая": 1.725,
                "очень_высокая": 1.9
            }
            
            activity_coeff = activity_coeffs.get(activity, 1.55)
            daily_calories = bmr * activity_coeff
            
            # Коррекция по цели
            if goal == "lose":
                daily_calories *= 0.8  # Дефицит 20%
            elif goal == "gain":
                daily_calories *= 1.2  # Профицит 20%
            
            # Расчет БЖУ
            proteins = weight * 2.2  # г (2.2г на кг веса)
            fats = daily_calories * 0.25 / 9  # г (25% калорий от жиров)
            carbs = (daily_calories - proteins * 4 - fats * 9) / 4  # г (остальные калории)
            
            return {
                "success": True,
                "daily_calories": int(daily_calories),
                "proteins_g": int(proteins),
                "fats_g": int(fats),
                "carbs_g": int(carbs),
                "bmr": int(bmr),
                "goal": goal,
                "recommendation": f"Калории: {int(daily_calories)} ккал/день\nБелки: {int(proteins)}г\nЖиры: {int(fats)}г\nУглеводы: {int(carbs)}г"
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    async def get_crypto_top3(self) -> Dict[str, Any]:
        """Анализ топ-3 криптовалют"""
        prompt = """
        Проанализируй текущие топ-3 криптовалюты по капитализации и дай краткий обзор:
        
        Для каждой монеты укажи:
        - Название и символ
        - Текущие тренды
        - Краткий прогноз
        - Риски и возможности
        
        Ответ должен быть информативным, но не являться финансовой рекомендацией.
        Добавь дисклеймер о рисках инвестиций.
        """
        
        return await self.generate_text(prompt, "gpt-4o-mini")
    
    async def get_reliable_exchanges(self) -> Dict[str, Any]:
        """Список надежных криптобирж"""
        prompt = """
        Составь список из 5-7 самых надежных криптовалютных бирж на 2026 год:
        
        Для каждой биржи укажи:
        - Название
        - Основные преимущества
        - Поддерживаемые регионы
        - Особенности безопасности
        
        Добавь общие советы по безопасности при работе с биржами.
        """
        
        return await self.generate_text(prompt, "gpt-4o-mini")
    
    async def generate_crypto_horoscope(self, zodiac_sign: str) -> Dict[str, Any]:
        """Шуточный крипто-гороскоп"""
        prompt = f"""
        Создай шуточный крипто-гороскоп для знака зодиака {zodiac_sign}:
        
        Включи:
        - Прогноз для портфеля
        - "Счастливую" криптовалюту дня
        - Совет по трейдингу в стиле астрологии
        - Предупреждение о "ретроградном биткоине"
        
        Сделай текст веселым, но добавь дисклеймер что это юмор, а не финансовый совет.
        """
        
        return await self.generate_text(prompt, "gpt-4o-mini")
    
    async def text_to_speech(self, text: str, voice: str = "coral", instructions: str = "") -> Dict[str, Any]:
        """
        Синтез речи через OpenAI TTS API
        
        Args:
            text: Текст для озвучивания
            voice: Голос (alloy, ash, ballad, coral, echo, fable, nova, onyx, sage, shimmer)
            instructions: Инструкции для управления характеристиками речи
            
        Returns:
            Dict с аудио данными
        """
        try:
            payload = {
                "model": "gpt-4o-mini-tts",
                "input": text,
                "voice": voice,
                "response_format": "mp3"
            }
            
            # Добавляем инструкции если указаны
            if instructions:
                payload["instructions"] = instructions
            
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{self.base_url}/audio/speech",
                    headers=self.headers,
                    json=payload,
                    timeout=60
                ) as response:
                    
                    if response.status == 200:
                        audio_data = await response.read()
                        
                        return {
                            "success": True,
                            "audio_data": audio_data,
                            "format": "mp3",
                            "voice": voice,
                            "text_length": len(text)
                        }
                    
                    error_text = await response.text()
                    return {
                        "success": False,
                        "error": f"API Error {response.status}",
                        "details": error_text
                    }
                    
        except Exception as e:
            return {
                "success": False,
                "error": "Network error",
                "details": str(e)
            }


# Функции для работы с изображениями
def save_base64_image(base64_data: str, filename: str) -> bool:
    """Сохранение base64 изображения в файл"""
    try:
        image_data = base64.b64decode(base64_data)
        with open(filename, 'wb') as f:
            f.write(image_data)
        return True
    except Exception:
        return False

def image_to_base64(image_path: str) -> Optional[str]:
    """Конвертация изображения в base64"""
    try:
        with open(image_path, 'rb') as f:
            image_data = f.read()
        return base64.b64encode(image_data).decode('utf-8')
    except Exception:
        return None