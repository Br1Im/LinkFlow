# common.py - Общие функции для BridgeAPI бота
from datetime import datetime, timedelta, timezone
import config

# Конфигурация каналов
CHANNELS = {
    "crypto": {
        "id": -1003227332437,  # Крипто канал (тот же что у AI и Crypto ботов)
        "name": "Крипто-канал",
        "price": 1500,
        "duration_days": 30
    },
    "nutrition": {
        "id": -1003249409257,  # Nutrition канал
        "name": "Канал по питанию", 
        "price": 1200,
        "duration_days": 30
    },
    "fitness": {
        "id": -1003278587634,  # Fitness канал
        "name": "Фитнес-канал",
        "price": 1000,
        "duration_days": 30
    },
    "ai": {
        "id": -1003227332437,  # AI канал (тот же что у крипто)
        "name": "AI-канал",
        "price": 800,
        "duration_days": 30
    }
}

async def generate_invite_link(bot, user_id: int, channel_type: str):
    """
    Создает персональную инвайт-ссылку для пользователя
    
    Args:
        bot: Экземпляр бота
        user_id: ID пользователя
        channel_type: Тип канала (crypto, nutrition, fitness, ai)
        
    Returns:
        str: Инвайт-ссылка или None при ошибке
    """
    try:
        if channel_type not in CHANNELS:
            return None
            
        channel_config = CHANNELS[channel_type]
        
        # Реальные ссылки на каналы
        real_links = {
            "crypto": "https://t.me/+4pS4ZKK7sW01MGVi",      # Крипто канал
            "nutrition": "https://t.me/+c2epJDkrTLRjOTYy",   # Питание канал
            "ai": "https://t.me/+ZvOVfV_NT7s0NGNi",          # AI канал
            "fitness": "https://t.me/+Oy-CYHtzHqhmOWQy"      # Фитнес канал
        }
        
        return real_links.get(channel_type)
        
        # Реальный код (закомментирован):
        # channel_id = channel_config["id"]
        # duration_days = channel_config["duration_days"]
        # 
        # now = datetime.now(timezone.utc)
        # expire_dt = now + timedelta(days=duration_days)
        # 
        # min_dt = now + timedelta(minutes=5)
        # max_dt = now + timedelta(days=365)
        # 
        # if expire_dt < min_dt:
        #     expire_dt = min_dt
        # if expire_dt > max_dt:
        #     expire_dt = max_dt
        #     
        # expire_ts = int(expire_dt.timestamp())
        # 
        # invite = await bot.create_chat_invite_link(
        #     chat_id=channel_id,
        #     expire_date=expire_ts,
        #     member_limit=1,
        #     name=f"Invite for {user_id} - {channel_config['name']}"
        # )
        # 
        # return invite.invite_link
        
    except Exception as e:
        print(f"❌ Ошибка создания инвайт-ссылки: {e}")
        return None