#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Простая админ-панель для управления платежами
Полный функционал без Telegram бота
"""

from flask import Flask, request, jsonify, render_template_string
from flask_cors import CORS
import json
import uuid
import time
import os
from datetime import datetime
from payment_service_ultra import create_payment_fast as create_payment
from database import db
import logging
import threading
import queue

# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app, origins="*", methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"], 
     allow_headers=["Content-Type", "Authorization"])

# База данных созданных ссылок
payment_links = {}

# Система очередей для обработки запросов
payment_queue = queue.Queue()
processing_thread = None
queue_lock = threading.Lock()

def process_payment_queue():
    """Обработчик очереди платежей (ОПТИМИЗИРОВАННАЯ ВЕРСИЯ)"""
    logger.info("🚀 Обработчик очереди запущен и ждёт задачи...")
    while True:
        try:
            # Получаем задачу из очереди
            logger.info("⏳ Ожидание задачи из очереди...")
            task = payment_queue.get(timeout=30)  # Ждем максимум 30 секунд
            
            if task is None:  # Сигнал завершения
                logger.info("🛑 Получен сигнал завершения обработчика очереди")
                break
                
            request_id, amount, order_id, description, callback = task
            
            logger.info(f"🔄 Обработка запроса {request_id}: {amount} сум, orderId: {order_id}")
            
            # Создание платежа с автоматическим восстановлением (максимум 1 попытка восстановления)
            result = None
            logger.info(f"🚀 Вызываю create_payment для суммы {amount}...")
            
            try:
                result = create_payment(amount, description)
                logger.info(f"✅ create_payment завершён с результатом: success={result.get('success', False)}")
            except Exception as e:
                logger.error(f"❌ Ошибка в create_payment: {e}")
                result = {"success": False, "error": str(e)}
            
            # Вызываем callback с результатом
            if callback:
                logger.info(f"📞 Вызываю callback для запроса {request_id}")
                callback(request_id, result, order_id, amount)
            else:
                logger.warning(f"⚠️ Нет callback для запроса {request_id}")
                
            # Отмечаем задачу как выполненную
            payment_queue.task_done()
            logger.info(f"✅ Задача {request_id} завершена")
            
        except queue.Empty:
            # Таймаут - продолжаем ждать
            logger.debug("⏰ Таймаут ожидания задачи, продолжаю...")
            continue
        except Exception as e:
            logger.error(f"❌ Ошибка обработки очереди: {e}")
            if 'task' in locals():
                payment_queue.task_done()

def start_queue_processor():
    """Запуск обработчика очереди"""
    global processing_thread
    logger.info("🔧 Попытка запуска обработчика очереди...")
    with queue_lock:
        if processing_thread is None or not processing_thread.is_alive():
            logger.info("🚀 Создаю новый поток обработчика очереди...")
            processing_thread = threading.Thread(target=process_payment_queue, daemon=True)
            processing_thread.start()
            logger.info("🚀 Обработчик очереди запущен")
        else:
            logger.info("ℹ️ Обработчик очереди уже запущен")

# Запускаем обработчик очереди при старте
logger.info("🔧 Запуск обработчика очереди при старте приложения...")
start_queue_processor()

# HTML шаблон с тёмной темой и переключателем
ADMIN_PANEL_TEMPLATE = """<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Админ-панель платежей</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            /* Светлая тема */
            --bg-primary: #f8f9fa;
            --bg-secondary: #ffffff;
            --bg-tertiary: #f8f9fa;
            --text-primary: #212529;
            --text-secondary: #6c757d;
            --border-color: #e9ecef;
            --accent-color: #212529;
            --accent-hover: #495057;
            --success-color: #198754;
            --danger-color: #dc3545;
            --warning-color: #fd7e14;
            --shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        [data-theme="dark"] {
            /* Тёмная тема */
            --bg-primary: #1a1a1a;
            --bg-secondary: #2d2d2d;
            --bg-tertiary: #3a3a3a;
            --text-primary: #ffffff;
            --text-secondary: #b0b0b0;
            --border-color: #404040;
            --accent-color: #4a9eff;
            --accent-hover: #6bb6ff;
            --success-color: #28a745;
            --danger-color: #dc3545;
            --warning-color: #ffc107;
            --shadow: 0 1px 3px rgba(0, 0, 0, 0.3);
        }

        * { 
            margin: 0; 
            padding: 0; 
            box-sizing: border-box; 
            transition: background-color 0.3s ease, color 0.3s ease, border-color 0.3s ease;
        }
        
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: var(--bg-primary);
            min-height: 100vh;
            color: var(--text-primary);
        }
        
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 260px;
            height: 100vh;
            background: var(--bg-secondary);
            border-right: 1px solid var(--border-color);
            z-index: 1000;
            transition: all 0.3s ease;
        }
        
        .mobile-menu-btn {
            display: none;
            position: fixed;
            top: 16px;
            left: 16px;
            z-index: 1001;
            background: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: 6px;
            padding: 10px;
            box-shadow: var(--shadow);
            color: var(--text-primary);
            cursor: pointer;
            transition: all 0.2s ease;
        }
        
        .mobile-menu-btn:hover {
            background: var(--bg-tertiary);
            transform: scale(1.05);
        }
        
        .mobile-menu-btn:active {
            transform: scale(0.95);
        }
        
        /* Оверлей для мобильного меню */
        .sidebar-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 999;
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        
        .sidebar-overlay.active {
            display: block;
            opacity: 1;
        }
        
        .sidebar-header {
            padding: 24px 20px;
            border-bottom: 1px solid var(--border-color);
        }
        
        .sidebar-header h1 {
            font-size: 20px;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 4px;
        }
        
        .sidebar-header p {
            color: var(--text-secondary);
            font-size: 14px;
        }
        
        .sidebar-menu {
            padding: 16px 0;
        }
        
        .menu-item {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: var(--text-secondary);
            text-decoration: none;
            transition: all 0.2s ease;
            cursor: pointer;
            border: none;
            background: none;
            width: 100%;
            text-align: left;
            font-size: 14px;
        }
        
        .menu-item:hover {
            background: var(--bg-tertiary);
            color: var(--text-primary);
        }
        
        .menu-item.active {
            background: var(--accent-color);
            color: #ffffff;
        }
        
        .menu-item i {
            width: 16px;
            margin-right: 12px;
            font-size: 14px;
        }
        
        .main-content {
            margin-left: 260px;
            padding: 24px;
            min-height: 100vh;
        }
        
        .page {
            display: none;
            background: var(--bg-secondary);
            border-radius: 8px;
            padding: 24px;
            box-shadow: var(--shadow);
            border: 1px solid var(--border-color);
        }
        
        .page.active { display: block; }
        
        .page-header {
            margin-bottom: 24px;
            padding-bottom: 16px;
            border-bottom: 1px solid var(--border-color);
        }
        
        .page-header h2 {
            font-size: 24px;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 4px;
        }
        
        .page-header p {
            color: var(--text-secondary);
            font-size: 14px;
        }
        
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 16px;
            margin-bottom: 24px;
        }
        
        .form-group {
            margin-bottom: 16px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 6px;
            font-weight: 500;
            color: var(--text-primary);
            font-size: 14px;
        }
        
        .form-group input, .form-group textarea, .form-group select {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid var(--border-color);
            border-radius: 4px;
            font-size: 14px;
            transition: border-color 0.2s ease;
            background: var(--bg-primary);
            color: var(--text-primary);
        }
        
        .form-group input:focus, .form-group textarea:focus, .form-group select:focus {
            outline: none;
            border-color: var(--accent-color);
        }
        
        .btn {
            padding: 10px 16px;
            border: 1px solid var(--border-color);
            border-radius: 4px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s ease;
            margin-right: 8px;
            margin-bottom: 8px;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: var(--bg-secondary);
            color: var(--text-primary);
        }
        
        .btn:hover {
            background: var(--bg-tertiary);
            border-color: var(--accent-color);
        }
        
        .btn-primary {
            background: var(--accent-color);
            color: #ffffff;
            border-color: var(--accent-color);
        }
        
        .btn-primary:hover {
            background: var(--accent-hover);
            border-color: var(--accent-hover);
        }
        
        .btn-success {
            background: var(--bg-secondary);
            color: var(--success-color);
            border-color: var(--success-color);
        }
        
        .btn-success:hover {
            background: var(--success-color);
            color: #ffffff;
        }
        
        .btn-danger {
            background: var(--bg-secondary);
            color: var(--danger-color);
            border-color: var(--danger-color);
        }
        
        .btn-danger:hover {
            background: var(--danger-color);
            color: #ffffff;
        }
        
        .btn-warning {
            background: var(--bg-secondary);
            color: var(--warning-color);
            border-color: var(--warning-color);
        }
        
        .btn-warning:hover {
            background: var(--warning-color);
            color: #ffffff;
        }
        
        .card {
            background: var(--bg-secondary);
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 16px;
            border: 1px solid var(--border-color);
        }
        
        .card h3 {
            margin-bottom: 12px;
            color: var(--text-primary);
            font-weight: 600;
            font-size: 16px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin-bottom: 24px;
        }
        
        .stat-card {
            background: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 20px;
            text-align: center;
            transition: transform 0.2s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow);
        }
        
        .stat-card i {
            font-size: 24px;
            margin-bottom: 12px;
            color: var(--accent-color);
        }
        
        .stat-card h3 {
            font-size: 28px;
            font-weight: 600;
            margin-bottom: 4px;
            color: var(--text-primary);
        }
        
        .stat-card p {
            color: var(--text-secondary);
            font-size: 14px;
        }
        
        .table-container {
            background: var(--bg-secondary);
            border-radius: 8px;
            overflow: hidden;
            margin-top: 16px;
            border: 1px solid var(--border-color);
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .table th, .table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
            font-size: 14px;
        }
        
        .table th {
            background: var(--bg-tertiary);
            font-weight: 600;
            color: var(--text-primary);
        }
        
        .table tr:hover {
            background: var(--bg-tertiary);
        }
        
        .table td {
            color: var(--text-primary);
        }
        
        .status-badge {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 500;
            text-transform: uppercase;
        }
        
        .status-online { background: #d1e7dd; color: #0f5132; }
        .status-offline { background: #f8d7da; color: #842029; }
        .status-error { background: #fff3cd; color: #664d03; }
        
        .loading {
            text-align: center;
            padding: 40px;
            display: none;
        }
        
        .spinner {
            border: 2px solid var(--border-color);
            border-top: 2px solid var(--accent-color);
            border-radius: 50%;
            width: 32px;
            height: 32px;
            animation: spin 1s linear infinite;
            margin: 0 auto 16px;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .alert {
            padding: 12px 16px;
            border-radius: 4px;
            margin-bottom: 16px;
            border: 1px solid;
        }
        
        .alert-success {
            background: #d1e7dd;
            border-color: #badbcc;
            color: #0f5132;
        }
        
        .alert-error {
            background: #f8d7da;
            border-color: #f5c2c7;
            color: #842029;
        }
        
        .alert-info {
            background: #cff4fc;
            border-color: #b6effb;
            color: #055160;
        }
        
        .payment-link {
            background: var(--bg-tertiary);
            border: 1px solid var(--border-color);
            border-radius: 4px;
            padding: 16px;
            font-family: 'Monaco', 'Menlo', monospace;
            font-size: 13px;
            word-break: break-all;
            margin: 12px 0;
            color: var(--text-primary);
        }
        
        .qr-display {
            text-align: center;
            margin: 16px 0;
        }
        
        .qr-display img {
            max-width: 250px;
            border-radius: 4px;
            border: 1px solid var(--border-color);
        }
        
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            
            .sidebar.open {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
                padding: 16px;
                padding-top: 60px; /* Место для мобильной кнопки */
            }
            
            .form-grid {
                grid-template-columns: 1fr;
                gap: 12px;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
                gap: 12px;
            }
            
            .mobile-menu-btn {
                display: block;
            }
            
            /* Улучшения для мобильных форм */
            .form-group input, 
            .form-group textarea, 
            .form-group select {
                padding: 12px 14px;
                font-size: 16px; /* Предотвращает зум на iOS */
            }
            
            /* Кнопки на мобильных */
            .btn {
                padding: 12px 16px;
                font-size: 14px;
                margin-bottom: 12px;
                width: 100%;
                justify-content: center;
            }
            
            /* Таблицы на мобильных */
            .table-container {
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
            }
            
            .table {
                min-width: 600px;
            }
            
            .table th, 
            .table td {
                padding: 8px;
                font-size: 13px;
            }
            
            /* Карточки статистики */
            .stat-card {
                padding: 16px;
                text-align: center;
            }
            
            .stat-card h3 {
                font-size: 24px;
            }
            
            /* Заголовки страниц */
            .page-header h2 {
                font-size: 20px;
            }
            
            /* Ссылки платежей */
            .payment-link {
                font-size: 12px;
                padding: 12px;
                word-break: break-all;
            }
            
            /* QR коды */
            .qr-display img {
                max-width: 200px;
            }
        }
        
        /* Планшеты */
        @media (max-width: 1024px) and (min-width: 769px) {
            .sidebar {
                width: 220px;
            }
            
            .main-content {
                margin-left: 220px;
                padding: 20px;
            }
            
            .form-grid {
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            }
            
            .stats-grid {
                grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            }
        }
        
        /* Маленькие мобильные устройства */
        @media (max-width: 480px) {
            .main-content {
                padding: 12px;
                padding-top: 60px;
            }
            
            .page {
                padding: 16px;
                margin: 0 -4px;
            }
            
            .card {
                padding: 16px;
                margin-bottom: 12px;
            }
            
            .form-group {
                margin-bottom: 12px;
            }
            
            .btn {
                padding: 14px 16px;
                font-size: 15px;
            }
            
            .stat-card {
                padding: 12px;
            }
            
            .stat-card h3 {
                font-size: 20px;
            }
            
            .stat-card i {
                font-size: 20px;
                margin-bottom: 8px;
            }
            
            .page-header {
                margin-bottom: 16px;
                padding-bottom: 12px;
            }
            
            .page-header h2 {
                font-size: 18px;
            }
            
            .page-header p {
                font-size: 13px;
            }
            
            /* Сайдбар на маленьких экранах */
            .sidebar {
                width: 280px; /* Немного шире для удобства */
            }
            
            .sidebar-header {
                padding: 20px 16px;
            }
            
            .sidebar-header h1 {
                font-size: 18px;
            }
            
            .menu-item {
                padding: 14px 16px;
                font-size: 15px;
            }
            
            .menu-item i {
                width: 18px;
                margin-right: 10px;
                font-size: 15px;
            }
        }
        
        /* Очень маленькие экраны */
        @media (max-width: 360px) {
            .main-content {
                padding: 8px;
                padding-top: 60px;
            }
            
            .page {
                padding: 12px;
            }
            
            .card {
                padding: 12px;
            }
            
            .form-group input, 
            .form-group textarea, 
            .form-group select {
                padding: 10px 12px;
            }
            
            .btn {
                padding: 12px 14px;
                font-size: 14px;
            }
            
            .sidebar {
                width: 260px;
            }
        }
        
        /* Стили для селектора тем */
        .theme-selector {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-top: 10px;
        }
        
        .theme-option {
            border: 2px solid var(--border-color);
            border-radius: 8px;
            padding: 16px;
            cursor: pointer;
            transition: all 0.3s ease;
            background: var(--bg-secondary);
        }
        
        .theme-option:hover {
            border-color: var(--accent-color);
            transform: translateY(-2px);
            box-shadow: var(--shadow);
        }
        
        .theme-option.active {
            border-color: var(--accent-color);
            background: var(--bg-tertiary);
        }
        
        .theme-preview {
            width: 100%;
            height: 80px;
            border-radius: 6px;
            margin-bottom: 12px;
            overflow: hidden;
            border: 1px solid rgba(0,0,0,0.1);
        }
        
        .light-preview {
            background: #f8f9fa;
        }
        
        .dark-preview {
            background: #1a1a1a;
        }
        
        .preview-header {
            height: 20px;
            background: linear-gradient(90deg, #4facfe 0%, #00f2fe 100%);
        }
        
        .preview-content {
            display: flex;
            height: 60px;
        }
        
        .light-preview .preview-sidebar {
            width: 30%;
            background: #ffffff;
            border-right: 1px solid #e9ecef;
        }
        
        .light-preview .preview-main {
            flex: 1;
            background: #f8f9fa;
        }
        
        .dark-preview .preview-sidebar {
            width: 30%;
            background: #2d2d2d;
            border-right: 1px solid #404040;
        }
        
        .dark-preview .preview-main {
            flex: 1;
            background: #1a1a1a;
        }
        
        .theme-info {
            display: flex;
            align-items: center;
            gap: 8px;
            position: relative;
        }
        
        .theme-info i {
            font-size: 16px;
            color: var(--accent-color);
        }
        
        .theme-info span {
            font-weight: 500;
            color: var(--text-primary);
        }
        
        .theme-check {
            position: absolute;
            right: 0;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            background: var(--success-color);
            color: white;
            display: none;
            align-items: center;
            justify-content: center;
            font-size: 12px;
        }
        
        .theme-option.active .theme-check {
            display: flex;
        }
        
        @media (max-width: 768px) {
            .theme-selector {
                grid-template-columns: 1fr;
                gap: 15px;
            }
            
            .theme-preview {
                height: 60px;
            }
        }
    </style>
</head>
<body>
    <button class="mobile-menu-btn" onclick="toggleSidebar()">
        <i class="fas fa-bars"></i>
    </button>
    
    <div class="sidebar-overlay" id="sidebar-overlay" onclick="closeSidebar()"></div>
    
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <h1><i class="fas fa-credit-card"></i> PayAdmin</h1>
            <p>Панель управления платежами</p>
        </div>
        
        <div class="sidebar-menu">
            <button class="menu-item active" onclick="showPage('dashboard')">
                <i class="fas fa-chart-line"></i>
                Дашборд
            </button>
            <button class="menu-item" onclick="showPage('create-payment')">
                <i class="fas fa-plus-circle"></i>
                Создать ссылку
            </button>
            <button class="menu-item" onclick="showPage('payments')">
                <i class="fas fa-list"></i>
                Все платежи
            </button>
            <button class="menu-item" onclick="showPage('accounts')">
                <i class="fas fa-users"></i>
                Аккаунты входа
            </button>
            <button class="menu-item" onclick="showPage('cards')">
                <i class="fas fa-credit-card"></i>
                Реквизиты карт
            </button>
            <button class="menu-item" onclick="showPage('settings')">
                <i class="fas fa-cog"></i>
                Настройки
            </button>
        </div>
    </div>
    
    <div class="main-content">
        <!-- Дашборд -->
        <div id="dashboard" class="page active">
            <div class="page-header">
                <h2><i class="fas fa-chart-line"></i> Дашборд</h2>
                <p>Обзор системы и статистика</p>
            </div>
            
            <div class="stats-grid">
                <div class="stat-card">
                    <i class="fas fa-link"></i>
                    <h3 id="total-links">0</h3>
                    <p>Всего ссылок</p>
                </div>
                <div class="stat-card">
                    <i class="fas fa-users"></i>
                    <h3 id="total-accounts">0</h3>
                    <p>Аккаунтов</p>
                </div>
                <div class="stat-card">
                    <i class="fas fa-credit-card"></i>
                    <h3 id="total-cards">0</h3>
                    <p>Карт</p>
                </div>
                <div class="stat-card">
                    <i class="fas fa-clock"></i>
                    <h3 id="avg-time">0s</h3>
                    <p>Среднее время</p>
                </div>
            </div>
            
            <div class="card">
                <h3><i class="fas fa-info-circle"></i> Статус системы</h3>
                <div id="system-status">
                    <p><i class="fas fa-spinner fa-spin"></i> Проверка статуса...</p>
                </div>
            </div>
        </div>
        
        <!-- Создание платежа -->
        <div id="create-payment" class="page">
            <div class="page-header">
                <h2><i class="fas fa-plus-circle"></i> Создать платежную ссылку</h2>
                <p>Генерация ссылки для оплаты</p>
            </div>
            
            <form id="payment-form">
                <div class="form-grid">
                    <div class="form-group">
                        <label><i class="fas fa-money-bill"></i> Сумма (сум)</label>
                        <input type="number" name="amount" required min="1000" max="1000000" placeholder="10000">
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-magic"></i> Создать ссылку
                </button>
            </form>
            
            <div id="payment-loading" class="loading">
                <div class="spinner"></div>
                <h3>Создание платежной ссылки...</h3>
                <p>Это может занять 5-15 секунд</p>
            </div>
            
            <div id="payment-result" style="display: none;">
                <div class="card">
                    <h3><i class="fas fa-check-circle"></i> Ссылка создана успешно!</h3>
                    <div id="payment-result-content"></div>
                </div>
            </div>
        </div>
        
        <!-- Все платежи -->
        <div id="payments" class="page">
            <div class="page-header">
                <h2><i class="fas fa-list"></i> Все платежи</h2>
                <p>История созданных платежных ссылок</p>
            </div>
            
            <button class="btn btn-primary" onclick="loadPayments()">
                <i class="fas fa-sync"></i> Обновить
            </button>
            
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Сумма</th>
                            <th>Создано</th>
                            <th>Время</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody id="payments-table">
                        <tr>
                            <td colspan="5" style="text-align: center; padding: 40px;">
                                <i class="fas fa-spinner fa-spin"></i> Загрузка...
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Аккаунты -->
        <div id="accounts" class="page">
            <div class="page-header">
                <h2><i class="fas fa-users"></i> Аккаунты для входа</h2>
                <p>Управление аккаунтами elecsnet.ru</p>
            </div>
            
            <div class="card">
                <h3><i class="fas fa-plus"></i> Добавить аккаунт</h3>
                <form id="account-form">
                    <div class="form-grid">
                        <div class="form-group">
                            <label><i class="fas fa-phone"></i> Телефон</label>
                            <input type="tel" name="phone" required placeholder="+998901234567">
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-lock"></i> Пароль</label>
                            <input type="password" name="password" required placeholder="Пароль от аккаунта">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-plus"></i> Добавить аккаунт
                    </button>
                </form>
            </div>
            
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Телефон</th>
                            <th>Статус</th>
                            <th>Последняя проверка</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody id="accounts-table">
                        <tr>
                            <td colspan="4" style="text-align: center; padding: 40px;">
                                <i class="fas fa-spinner fa-spin"></i> Загрузка...
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Карты -->
        <div id="cards" class="page">
            <div class="page-header">
                <h2><i class="fas fa-credit-card"></i> Реквизиты карт</h2>
                <p>Управление банковскими картами для приема платежей</p>
            </div>
            
            <div class="card">
                <h3><i class="fas fa-plus"></i> Добавить карту</h3>
                <form id="card-form">
                    <div class="form-grid">
                        <div class="form-group">
                            <label><i class="fas fa-credit-card"></i> Номер карты</label>
                            <input type="text" name="card_number" required placeholder="9860 1001 2345 6789" maxlength="19">
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-user"></i> Владелец карты</label>
                            <input type="text" name="owner_name" required placeholder="IVAN PETROV">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-plus"></i> Добавить карту
                    </button>
                </form>
            </div>
            
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Номер карты</th>
                            <th>Владелец</th>
                            <th>Добавлена</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody id="cards-table">
                        <tr>
                            <td colspan="4" style="text-align: center; padding: 40px;">
                                <i class="fas fa-spinner fa-spin"></i> Загрузка...
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Настройки -->
        <div id="settings" class="page">
            <div class="page-header">
                <h2><i class="fas fa-cog"></i> Настройки системы</h2>
                <p>Конфигурация и параметры</p>
            </div>
            
            <div class="card">
                <h3><i class="fas fa-server"></i> Настройки сервера</h3>
                <form id="settings-form">
                    <div class="form-grid">
                        <div class="form-group">
                            <label><i class="fas fa-clock"></i> Таймаут браузера (сек)</label>
                            <input type="number" name="browser_timeout" value="30" min="10" max="120">
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-hourglass"></i> Таймаут страницы (сек)</label>
                            <input type="number" name="page_timeout" value="20" min="5" max="60">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Сохранить настройки
                    </button>
                </form>
            </div>
            
            <div class="card">
                <h3><i class="fas fa-palette"></i> Настройки интерфейса</h3>
                <div class="form-group">
                    <label><i class="fas fa-moon"></i> Тема оформления</label>
                    <div class="theme-selector">
                        <div class="theme-option" onclick="setTheme('light')" id="light-theme">
                            <div class="theme-preview light-preview">
                                <div class="preview-header"></div>
                                <div class="preview-content">
                                    <div class="preview-sidebar"></div>
                                    <div class="preview-main"></div>
                                </div>
                            </div>
                            <div class="theme-info">
                                <i class="fas fa-sun"></i>
                                <span>Светлая тема</span>
                                <div class="theme-check" id="light-check">
                                    <i class="fas fa-check"></i>
                                </div>
                            </div>
                        </div>
                        
                        <div class="theme-option" onclick="setTheme('dark')" id="dark-theme">
                            <div class="theme-preview dark-preview">
                                <div class="preview-header"></div>
                                <div class="preview-content">
                                    <div class="preview-sidebar"></div>
                                    <div class="preview-main"></div>
                                </div>
                            </div>
                            <div class="theme-info">
                                <i class="fas fa-moon"></i>
                                <span>Тёмная тема</span>
                                <div class="theme-check" id="dark-check">
                                    <i class="fas fa-check"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card">
                <h3><i class="fas fa-database"></i> Управление данными</h3>
                <button class="btn btn-warning" onclick="exportData()">
                    <i class="fas fa-download"></i> Экспорт данных
                </button>
                <button class="btn btn-danger" onclick="clearData()">
                    <i class="fas fa-trash"></i> Очистить все данные
                </button>
            </div>
        </div>
    </div>

    <script>
        // Управление темой
        function setTheme(theme) {
            const body = document.body;
            const lightOption = document.getElementById('light-theme');
            const darkOption = document.getElementById('dark-theme');
            
            // Убираем активный класс со всех опций
            lightOption.classList.remove('active');
            darkOption.classList.remove('active');
            
            if (theme === 'dark') {
                body.setAttribute('data-theme', 'dark');
                darkOption.classList.add('active');
                localStorage.setItem('theme', 'dark');
            } else {
                body.removeAttribute('data-theme');
                lightOption.classList.add('active');
                localStorage.setItem('theme', 'light');
            }
        }
        
        // Загрузка сохраненной темы
        function loadTheme() {
            const savedTheme = localStorage.getItem('theme') || 'light';
            setTheme(savedTheme);
        }
        
        // Восстановление активной вкладки
        function restoreActiveTab() {
            const savedTab = localStorage.getItem('activeTab') || 'dashboard';
            
            // Убираем активный класс со всех страниц и пунктов меню
            document.querySelectorAll('.page').forEach(page => {
                page.classList.remove('active');
            });
            document.querySelectorAll('.menu-item').forEach(item => {
                item.classList.remove('active');
            });
            
            // Активируем сохраненную вкладку
            const targetPage = document.getElementById(savedTab);
            if (targetPage) {
                targetPage.classList.add('active');
                currentPage = savedTab;
                
                // Активируем соответствующий пункт меню
                document.querySelectorAll('.menu-item').forEach(item => {
                    if (item.onclick && item.onclick.toString().includes(`'${savedTab}'`)) {
                        item.classList.add('active');
                    }
                });
                
                // Загружаем данные для страницы
                loadPageData(savedTab);
            } else {
                // Если сохраненная вкладка не найдена, показываем дашборд
                showPage('dashboard');
            }
        }
        
        // Глобальные переменные
        let currentPage = 'dashboard';
        
        // Переключение страниц
        function showPage(pageId) {
            // Скрываем все страницы
            document.querySelectorAll('.page').forEach(page => {
                page.classList.remove('active');
            });
            
            // Убираем активный класс с меню
            document.querySelectorAll('.menu-item').forEach(item => {
                item.classList.remove('active');
            });
            
            // Показываем нужную страницу
            document.getElementById(pageId).classList.add('active');
            
            // Активируем пункт меню
            if (event && event.target) {
                event.target.classList.add('active');
            } else {
                // Если вызвано программно, найдем нужный пункт меню
                document.querySelectorAll('.menu-item').forEach(item => {
                    if (item.onclick && item.onclick.toString().includes(`'${pageId}'`)) {
                        item.classList.add('active');
                    }
                });
            }
            
            currentPage = pageId;
            
            // Сохраняем активную вкладку
            localStorage.setItem('activeTab', pageId);
            
            // Загружаем данные для страницы
            loadPageData(pageId);
            
            // Закрываем мобильное меню
            if (window.innerWidth <= 768) {
                closeSidebar();
            }
        }
        
        // Загрузка данных для страницы
        function loadPageData(pageId) {
            switch(pageId) {
                case 'dashboard':
                    loadDashboard();
                    break;
                case 'payments':
                    loadPayments();
                    break;
                case 'accounts':
                    loadAccounts();
                    break;
                case 'cards':
                    loadCards();
                    break;
            }
        }
        
        // Мобильное меню
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('sidebar-overlay');
            
            sidebar.classList.toggle('open');
            overlay.classList.toggle('active');
        }
        
        function closeSidebar() {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('sidebar-overlay');
            
            sidebar.classList.remove('open');
            overlay.classList.remove('active');
        }
        
        // Закрытие меню при клике вне его области
        document.addEventListener('click', function(event) {
            const sidebar = document.getElementById('sidebar');
            const menuBtn = document.querySelector('.mobile-menu-btn');
            
            if (window.innerWidth <= 768 && 
                sidebar.classList.contains('open') && 
                !sidebar.contains(event.target) && 
                !menuBtn.contains(event.target)) {
                closeSidebar();
            }
        });
        
        // Закрытие меню при изменении размера экрана
        window.addEventListener('resize', function() {
            if (window.innerWidth > 768) {
                closeSidebar();
            }
        });
        
        // Загрузка дашборда
        async function loadDashboard() {
            try {
                const [linksRes, accountsRes, cardsRes] = await Promise.all([
                    fetch('/api/links'),
                    fetch('/api/accounts'),
                    fetch('/api/cards')
                ]);
                
                const links = await linksRes.json();
                const accounts = await accountsRes.json();
                const cards = await cardsRes.json();
                
                document.getElementById('total-links').textContent = Object.keys(links).length;
                document.getElementById('total-accounts').textContent = accounts.length;
                document.getElementById('total-cards').textContent = cards.length;
                
                // Среднее время создания
                const times = Object.values(links).map(l => l.elapsed_time || 0);
                const avgTime = times.length ? (times.reduce((a, b) => a + b, 0) / times.length).toFixed(1) : 0;
                document.getElementById('avg-time').textContent = avgTime + 's';
                
                // Статус системы
                document.getElementById('system-status').innerHTML = `
                    <p><i class="fas fa-check-circle" style="color: #10b981;"></i> Система работает нормально</p>
                    <p><i class="fas fa-globe"></i> Браузер: Готов</p>
                    <p><i class="fas fa-server"></i> Сервер: Онлайн</p>
                `;
                
            } catch (error) {
                console.error('Ошибка загрузки дашборда:', error);
            }
        }
        
        // Создание платежа
        document.getElementById('payment-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const formData = new FormData(e.target);
            const data = Object.fromEntries(formData);
            
            // Добавляем автоматическое описание
            data.description = `Платеж ${data.amount} сум`;
            
            document.getElementById('payment-loading').style.display = 'block';
            document.getElementById('payment-result').style.display = 'none';
            
            try {
                const response = await fetch('/api/create-payment', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });
                
                const result = await response.json();
                
                document.getElementById('payment-loading').style.display = 'none';
                
                if (result.success) {
                    document.getElementById('payment-result-content').innerHTML = `
                        <div class="alert alert-success">
                            <strong>Успех!</strong> Платежная ссылка создана за ${result.elapsed_time}s
                        </div>
                        <div class="payment-link">${result.payment_link}</div>
                        <button class="btn btn-primary" onclick="copyToClipboard('${result.payment_link}')">
                            <i class="fas fa-copy"></i> Копировать ссылку
                        </button>
                        ${result.qr_filename ? `
                            <div class="qr-display">
                                <h4>QR код для оплаты:</h4>
                                <img src="/qr/${result.qr_filename}" alt="QR код">
                            </div>
                        ` : ''}
                    `;
                } else {
                    document.getElementById('payment-result-content').innerHTML = `
                        <div class="alert alert-error">
                            <strong>Ошибка!</strong> ${result.error}
                        </div>
                    `;
                }
                
                document.getElementById('payment-result').style.display = 'block';
                
            } catch (error) {
                document.getElementById('payment-loading').style.display = 'none';
                document.getElementById('payment-result-content').innerHTML = `
                    <div class="alert alert-error">
                        <strong>Ошибка соединения!</strong> ${error.message}
                    </div>
                `;
                document.getElementById('payment-result').style.display = 'block';
            }
        });
        
        // Загрузка платежей
        async function loadPayments() {
            try {
                const response = await fetch('/api/links');
                const links = await response.json();
                
                const tbody = document.getElementById('payments-table');
                
                if (Object.keys(links).length === 0) {
                    tbody.innerHTML = `
                        <tr>
                            <td colspan="5" style="text-align: center; padding: 40px;">
                                <i class="fas fa-inbox"></i><br>
                                Пока нет созданных платежей
                            </td>
                        </tr>
                    `;
                } else {
                    tbody.innerHTML = Object.entries(links).map(([id, link]) => `
                        <tr>
                            <td><code>${id.substring(0, 8)}...</code></td>
                            <td><strong>${link.amount} сум</strong></td>
                            <td>${new Date(link.created_at).toLocaleString('ru-RU')}</td>
                            <td>${link.elapsed_time || 0}s</td>
                            <td>
                                <button class="btn btn-primary" onclick="copyToClipboard('${link.payment_link}')">
                                    <i class="fas fa-copy"></i>
                                </button>
                                <button class="btn btn-danger" onclick="deletePayment('${id}')">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                    `).join('');
                }
                
            } catch (error) {
                console.error('Ошибка загрузки платежей:', error);
            }
        }
        
        // Загрузка аккаунтов
        async function loadAccounts() {
            try {
                const response = await fetch('/api/accounts');
                const accounts = await response.json();
                
                const tbody = document.getElementById('accounts-table');
                
                if (accounts.length === 0) {
                    tbody.innerHTML = `
                        <tr>
                            <td colspan="4" style="text-align: center; padding: 40px;">
                                <i class="fas fa-user-plus"></i><br>
                                Добавьте первый аккаунт
                            </td>
                        </tr>
                    `;
                } else {
                    tbody.innerHTML = accounts.map((acc, index) => `
                        <tr>
                            <td><strong>${acc.phone}</strong></td>
                            <td>
                                <span class="status-badge status-${acc.status || 'offline'}">
                                    ${acc.status || 'offline'}
                                </span>
                            </td>
                            <td>${acc.last_check ? new Date(acc.last_check).toLocaleString('ru-RU') : 'Никогда'}</td>
                            <td>
                                <button class="btn btn-warning" onclick="checkAccount(${index})">
                                    <i class="fas fa-sync"></i>
                                </button>
                                <button class="btn btn-danger" onclick="deleteAccount(${index})">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                    `).join('');
                }
                
            } catch (error) {
                console.error('Ошибка загрузки аккаунтов:', error);
            }
        }
        
        // Загрузка карт
        async function loadCards() {
            try {
                const response = await fetch('/api/cards');
                const cards = await response.json();
                
                const tbody = document.getElementById('cards-table');
                
                if (cards.length === 0) {
                    tbody.innerHTML = `
                        <tr>
                            <td colspan="4" style="text-align: center; padding: 40px;">
                                <i class="fas fa-credit-card"></i><br>
                                Добавьте первую карту
                            </td>
                        </tr>
                    `;
                } else {
                    tbody.innerHTML = cards.map((card, index) => `
                        <tr>
                            <td><code>${card.card_number}</code></td>
                            <td><strong>${card.owner_name}</strong></td>
                            <td>${card.created_at ? new Date(card.created_at).toLocaleString('ru-RU') : 'Неизвестно'}</td>
                            <td>
                                <button class="btn btn-danger" onclick="deleteCard(${index})">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                    `).join('');
                }
                
            } catch (error) {
                console.error('Ошибка загрузки карт:', error);
            }
        }
        
        // Добавление аккаунта
        document.getElementById('account-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const formData = new FormData(e.target);
            const data = Object.fromEntries(formData);
            
            try {
                const response = await fetch('/api/accounts', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });
                
                const result = await response.json();
                
                if (result.success) {
                    e.target.reset();
                    loadAccounts();
                    alert('✅ Аккаунт добавлен успешно!');
                } else {
                    alert('❌ Ошибка: ' + result.error);
                }
                
            } catch (error) {
                alert('❌ Ошибка добавления аккаунта: ' + error.message);
            }
        });
        
        // Добавление карты
        document.getElementById('card-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const formData = new FormData(e.target);
            const data = Object.fromEntries(formData);
            
            try {
                const response = await fetch('/api/cards', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });
                
                const result = await response.json();
                
                if (result.success) {
                    e.target.reset();
                    loadCards();
                    alert('✅ Карта добавлена успешно!');
                } else {
                    alert('❌ Ошибка: ' + result.error);
                }
                
            } catch (error) {
                alert('❌ Ошибка добавления карты: ' + error.message);
            }
        });
        
        // Копирование в буфер обмена
        function copyToClipboard(text) {
            navigator.clipboard.writeText(text).then(() => {
                alert('📋 Ссылка скопирована в буфер обмена!');
            }).catch(() => {
                const textArea = document.createElement('textarea');
                textArea.value = text;
                document.body.appendChild(textArea);
                textArea.select();
                document.execCommand('copy');
                document.body.removeChild(textArea);
                alert('📋 Ссылка скопирована!');
            });
        }
        
        // Удаление платежа
        async function deletePayment(id) {
            if (confirm('Удалить этот платеж?')) {
                try {
                    const response = await fetch(`/api/links/${id}`, {
                        method: 'DELETE'
                    });
                    
                    if (response.ok) {
                        loadPayments();
                        alert('✅ Платеж удален!');
                    } else {
                        alert('❌ Ошибка удаления');
                    }
                } catch (error) {
                    alert('❌ Ошибка: ' + error.message);
                }
            }
        }
        
        // Удаление аккаунта
        async function deleteAccount(index) {
            if (confirm('Удалить этот аккаунт?')) {
                try {
                    const response = await fetch(`/api/accounts/${index}`, {
                        method: 'DELETE'
                    });
                    
                    if (response.ok) {
                        loadAccounts();
                        alert('✅ Аккаунт удален!');
                    } else {
                        alert('❌ Ошибка удаления');
                    }
                } catch (error) {
                    alert('❌ Ошибка: ' + error.message);
                }
            }
        }
        
        // Удаление карты
        async function deleteCard(index) {
            if (confirm('Удалить эту карту?')) {
                try {
                    const response = await fetch(`/api/cards/${index}`, {
                        method: 'DELETE'
                    });
                    
                    if (response.ok) {
                        loadCards();
                        alert('✅ Карта удалена!');
                    } else {
                        alert('❌ Ошибка удаления');
                    }
                } catch (error) {
                    alert('❌ Ошибка: ' + error.message);
                }
            }
        }
        
        // Проверка аккаунта
        async function checkAccount(index) {
            try {
                const response = await fetch(`/api/accounts/${index}/check`, {
                    method: 'POST'
                });
                
                const result = await response.json();
                
                if (result.success) {
                    loadAccounts();
                    alert('✅ Аккаунт проверен!');
                } else {
                    alert('❌ Ошибка проверки: ' + result.error);
                }
            } catch (error) {
                alert('❌ Ошибка: ' + error.message);
            }
        }
        
        // Форматирование номера карты
        document.addEventListener('DOMContentLoaded', function() {
            const cardInput = document.querySelector('input[name="card_number"]');
            if (cardInput) {
                cardInput.addEventListener('input', function(e) {
                    let value = e.target.value.replace(/\\s/g, '').replace(/[^0-9]/gi, '');
                    let formattedValue = value.match(/.{1,4}/g)?.join(' ') || value;
                    e.target.value = formattedValue;
                });
            }
        });
        
        // Экспорт данных
        function exportData() {
            alert('Функция экспорта данных в разработке');
        }
        
        // Очистка данных
        function clearData() {
            if (confirm('Вы уверены, что хотите очистить все данные? Это действие нельзя отменить!')) {
                alert('Функция очистки данных в разработке');
            }
        }
        
        // Инициализация при загрузке
        document.addEventListener('DOMContentLoaded', function() {
            loadTheme(); // Загружаем сохраненную тему
            restoreActiveTab(); // Восстанавливаем активную вкладку
            
            // Автообновление каждые 30 секунд
            setInterval(() => {
                if (currentPage === 'dashboard') {
                    loadDashboard();
                }
            }, 30000);
        });
    </script>
</body>
</html>
"""

@app.route('/')
def index():
    """Главная страница админ-панели"""
    return render_template_string(ADMIN_PANEL_TEMPLATE)

@app.route('/api/create-payment', methods=['POST'])
def create_payment_endpoint():
    """API для создания платежной ссылки"""
    logger.info("🔥 POST запрос получен на /api/create-payment")
    try:
        logger.info("📥 Парсинг JSON данных...")
        data = request.get_json()
        logger.info(f"📊 Получены данные: {data}")
        
        amount = int(data['amount'])
        description = data['description']
        
        logger.info(f"💰 Создание платежа: {amount} сум - {description}")
        
        payment_id = str(uuid.uuid4())
        
        payment_link = None
        qr_path = None
        qr_filename = None
        
        def payment_callback(link, qr_file_path):
            nonlocal payment_link, qr_path, qr_filename
            payment_link = link
            qr_path = qr_file_path
            if qr_file_path:
                qr_filename = qr_file_path.split('/')[-1] if '/' in qr_file_path else qr_file_path.split('\\')[-1]
        
        result = create_payment(amount, send_callback=payment_callback)
        
        if result.get("error"):
            return jsonify({
                "success": False,
                "error": result["error"]
            }), 400
        
        payment_links[payment_id] = {
            "id": payment_id,
            "amount": amount,
            "description": description,
            "payment_link": payment_link or result.get("payment_link", ""),
            "qr_path": qr_path,
            "qr_filename": qr_filename,
            "created_at": datetime.now().isoformat(),
            "elapsed_time": result.get("elapsed_time", 0)
        }
        
        logger.info(f"Платеж создан успешно: {payment_link}")
        
        return jsonify({
            "success": True,
            "payment_id": payment_id,
            "payment_link": payment_link or result.get("payment_link", ""),
            "qr_path": qr_path,
            "qr_filename": qr_filename,
            "elapsed_time": result.get("elapsed_time", 0)
        })
        
    except Exception as e:
        logger.error(f"❌ Ошибка создания платежа: {e}")
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

@app.route('/api/links')
def get_links():
    """Получение всех созданных ссылок"""
    return jsonify(payment_links)

@app.route('/api/links/<link_id>', methods=['DELETE'])
def delete_link(link_id):
    """Удаление ссылки"""
    if link_id in payment_links:
        del payment_links[link_id]
        return jsonify({"success": True})
    return jsonify({"success": False, "error": "Ссылка не найдена"}), 404

@app.route('/api/accounts')
def get_accounts():
    """Получение всех аккаунтов"""
    accounts = db.get_accounts()
    return jsonify(accounts)

@app.route('/api/accounts', methods=['POST'])
def add_account():
    """Добавление нового аккаунта"""
    try:
        data = request.get_json()
        phone = data['phone']
        password = data['password']
        
        # Добавляем аккаунт в базу
        db.add_account(phone, password)
        
        return jsonify({"success": True})
        
    except Exception as e:
        logger.error(f"Ошибка добавления аккаунта: {e}")
        return jsonify({"success": False, "error": str(e)}), 500

@app.route('/api/accounts/<int:index>', methods=['DELETE'])
def delete_account(index):
    """Удаление аккаунта"""
    try:
        accounts = db.get_accounts()
        if 0 <= index < len(accounts):
            db.delete_account(index)
            return jsonify({"success": True})
        return jsonify({"success": False, "error": "Аккаунт не найден"}), 404
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route('/api/accounts/<int:index>/check', methods=['POST'])
def check_account(index):
    """Проверка аккаунта"""
    try:
        # Здесь можно добавить реальную проверку аккаунта
        db.update_account_status(index, 'online')
        return jsonify({"success": True})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route('/api/cards')
def get_cards():
    """Получение всех карт"""
    cards = db.get_requisites()
    return jsonify(cards)

@app.route('/api/cards', methods=['POST'])
def add_card():
    """Добавление новой карты"""
    try:
        data = request.get_json()
        card_number = data['card_number'].replace(' ', '')
        owner_name = data['owner_name'].upper()
        
        db.add_requisite(card_number, owner_name)
        
        return jsonify({"success": True})
        
    except Exception as e:
        logger.error(f"Ошибка добавления карты: {e}")
        return jsonify({"success": False, "error": str(e)}), 500

@app.route('/api/cards/<int:index>', methods=['DELETE'])
def delete_card(index):
    """Удаление карты"""
    try:
        cards = db.get_requisites()
        if 0 <= index < len(cards):
            db.delete_requisite(index)
            return jsonify({"success": True})
        return jsonify({"success": False, "error": "Карта не найдена"}), 404
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route('/api/queue/status')
def queue_status():
    """Получение статуса очереди"""
    return jsonify({
        "queueSize": payment_queue.qsize(),
        "processingThreadAlive": processing_thread.is_alive() if processing_thread else False,
        "browserReady": is_browser_ready() if 'is_browser_ready' in globals() else False
    })

@app.route('/api/health')
def health_check():
    """Проверка здоровья системы"""
    try:
        from browser_manager import browser_manager
        from database import db
        
        # Проверяем компоненты системы
        browser_status = "ready" if browser_manager.is_ready else "not_ready"
        queue_size = payment_queue.qsize()
        thread_alive = processing_thread.is_alive() if processing_thread else False
        
        # Проверяем данные
        accounts = db.get_accounts()
        requisites = db.get_requisites()
        
        health_data = {
            "status": "healthy" if (browser_status == "ready" and thread_alive) else "degraded",
            "browser": {
                "status": browser_status,
                "ready": browser_manager.is_ready,
                "lastActivity": getattr(browser_manager, 'last_activity', 0)
            },
            "queue": {
                "size": queue_size,
                "processingThread": thread_alive
            },
            "data": {
                "accounts": len(accounts),
                "requisites": len(requisites)
            },
            "timestamp": time.time()
        }
        
        return jsonify(health_data)
        
    except Exception as e:
        return jsonify({
            "status": "error",
            "error": str(e),
            "timestamp": time.time()
        }), 500

@app.route('/qr/<filename>')
def serve_qr(filename):
    """Отдача QR кодов"""
    try:
        from flask import send_file
        from config import QR_TEMP_PATH
        
        qr_path = os.path.join(QR_TEMP_PATH, filename)
        if os.path.exists(qr_path):
            return send_file(qr_path, mimetype='image/png')
        else:
            return "QR код не найден", 404
    except Exception as e:
        logger.error(f"Ошибка отдачи QR кода: {e}")
        return "Ошибка", 500

# API токен для внешних запросов
API_TOKEN = "-3uVLlbWyy90eapOGkv70C2ZltaYTxq-HtDbq-DtlLo"

def verify_token():
    """Проверка Bearer токена"""
    auth_header = request.headers.get('Authorization')
    if not auth_header:
        return False
    
    try:
        token_type, token = auth_header.split(' ', 1)
        if token_type.lower() != 'bearer':
            return False
        return token == API_TOKEN
    except ValueError:
        return False

@app.route('/api/payment', methods=['POST'])
def create_payment_api():
    """API для создания платежа с авторизацией по токену и очередью"""
    
    # Проверка авторизации
    if not verify_token():
        return jsonify({
            "success": False,
            "error": "Unauthorized",
            "message": "Invalid or missing Bearer token"
        }), 401
    
    try:
        data = request.get_json()
        if not data:
            return jsonify({
                "success": False,
                "error": "Invalid JSON"
            }), 400
        
        # Валидация данных
        amount = data.get('amount')
        order_id = data.get('orderId')
        
        if not amount:
            return jsonify({
                "success": False,
                "error": "Missing required field: amount"
            }), 400
        
        if not isinstance(amount, (int, float)) or amount <= 0:
            return jsonify({
                "success": False,
                "error": "Invalid amount: must be positive number"
            }), 400
        
        if not order_id:
            return jsonify({
                "success": False,
                "error": "Missing required field: orderId"
            }), 400
        
        # Проверка на дублирование orderId
        for existing_id, existing_payment in payment_links.items():
            if existing_payment.get('order_id') == order_id:
                return jsonify({
                    "success": False,
                    "error": "Duplicate orderId",
                    "message": f"Payment with orderId '{order_id}' already exists"
                }), 409
        
        # Генерируем уникальный ID запроса
        request_id = str(uuid.uuid4())
        description = f"Платеж {amount} сум"
        
        # Создаем событие для ожидания результата
        result_event = threading.Event()
        result_data = {}
        
        def payment_callback(req_id, result, ord_id, amt):
            """Callback для получения результата из очереди"""
            result_data['result'] = result
            result_data['order_id'] = ord_id
            result_data['amount'] = amt
            result_event.set()
        
        # Добавляем задачу в очередь
        logger.info(f"📥 Добавляю в очередь: {amount} сум, orderId: {order_id}, позиция: {payment_queue.qsize() + 1}")
        payment_queue.put((request_id, amount, order_id, description, payment_callback))
        
        # Ждем результат с таймаутом 60 секунд
        if result_event.wait(timeout=60):
            result = result_data['result']
            
            if result.get('success'):
                # Сохраняем платеж с orderId
                payment_id = str(uuid.uuid4())
                payment_links[payment_id] = {
                    "payment_link": result['payment_link'],
                    "qr_base64": result.get('qr_base64', ''),
                    "qr_filename": result.get('qr_filename', ''),
                    "amount": amount,
                    "description": description,
                    "order_id": order_id,
                    "created_at": datetime.now().isoformat(),
                    "elapsed_time": result.get('elapsed_time', 0),
                    "account_used": result.get('account_used', '')
                }
                
                logger.info(f"✅ API платеж создан успешно: {result['payment_link']}")
                
                # Возвращаем ответ в формате API
                response_data = {
                    "success": True,
                    "paymentId": payment_id,
                    "orderId": order_id,
                    "amount": amount,
                    "paymentUrl": result['payment_link'],
                    "qrCode": result.get('qr_base64', ''),
                    "createdAt": datetime.now().isoformat(),
                    "elapsedTime": result.get('elapsed_time', 0),
                    "queuePosition": 0  # Уже обработан
                }
                
                # Добавляем QR URL если есть файл
                if result.get('qr_filename'):
                    response_data["qrImageUrl"] = f"/qr/{result['qr_filename']}"
                
                return jsonify(response_data), 201
                
            else:
                logger.error(f"❌ API ошибка создания платежа: {result.get('error', 'Unknown error')}")
                return jsonify({
                    "success": False,
                    "error": "Payment creation failed",
                    "message": result.get('error', 'Unknown error'),
                    "elapsedTime": result.get('elapsed_time', 0)
                }), 500
        else:
            # Таймаут ожидания
            logger.error(f"⏰ Таймаут обработки запроса {request_id}")
            return jsonify({
                "success": False,
                "error": "Request timeout",
                "message": "Payment processing took too long",
                "queuePosition": payment_queue.qsize()
            }), 408
            
    except Exception as e:
        logger.error(f"❌ API критическая ошибка: {e}")
        return jsonify({
            "success": False,
            "error": "Internal server error",
            "message": str(e)
        }), 500


@app.route('/api/pool/status', methods=['GET'])
def get_pool_status():
    """API для получения статуса пула браузеров"""
    try:
        from payment_service_ultra import get_pool_status
        status = get_pool_status()
        return jsonify({
            "success": True,
            "pool": status
        })
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


def start_admin_panel(host='0.0.0.0', port=5000):
    """Запуск админ-панели"""
    logger.info(f"🚀 Запуск админ-панели на http://{host}:{port}")
    
    # Автоматический прогрев браузера в фоне
    import threading
    import time
    
    def warmup_browser():
        try:
            logger.info("🔥 Запуск прогрева пула браузеров...")
            from payment_service_ultra import initialize_warmed_browser
            from database import db
            
            # Получаем данные
            accounts = db.get_accounts()
            requisites = db.get_requisites()
            
            if accounts and requisites:
                # Используем ультра-быстрый прогретый браузер
                success = initialize_warmed_browser()
                if success:
                    logger.info("✅ Ультра-быстрый браузер прогрет и готов к работе!")
                else:
                    logger.warning("⚠️ Не удалось прогреть ультра-быстрый браузер")
            else:
                logger.info("ℹ️ Нет данных для прогрева браузера (добавьте аккаунты и карты)")
                
        except Exception as e:
            logger.error(f"❌ Ошибка прогрева браузера: {e}")
    
    def periodic_warmup():
        """Периодический прогрев и восстановление браузера каждые 3 минуты"""
        while True:
            time.sleep(180)  # 3 минуты
            try:
                from payment_service_ultra import is_browser_ready, initialize_warmed_browser
                from database import db
                
                # Проверяем состояние
                if not is_browser_ready():
                    logger.info("🔄 Браузеры не готовы, запускаю восстановление...")
                    
                    accounts = db.get_accounts()
                    requisites = db.get_requisites()
                    
                    if accounts and requisites:
                        # Используем ультра-быстрый прогретый браузер
                        success = initialize_warmed_browser()
                        
                        if success:
                            logger.info("✅ Ультра-быстрый браузер восстановлен автоматически!")
                        else:
                            logger.error("❌ Не удалось восстановить ультра-быстрый браузер")
                    else:
                        logger.warning("⚠️ Нет данных для восстановления")
                else:
                    # Браузеры работают - логируем статус
                    from payment_service_ultra import get_pool_status
                    status = get_pool_status()
                    logger.debug(f"📊 Статус пула: {status}")
                        
            except Exception as e:
                logger.error(f"❌ Ошибка периодического прогрева: {e}")
    
    # Запускаем прогрев в отдельном потоке
    warmup_thread = threading.Thread(target=warmup_browser, daemon=True)
    warmup_thread.start()
    logger.info("� ЗаЛпуск прогрева браузера в фоне...")
    
    # Запускаем периодический прогрев
    periodic_thread = threading.Thread(target=periodic_warmup, daemon=True)
    periodic_thread.start()
    
    app.run(host=host, port=port, debug=False, use_reloader=False)

if __name__ == '__main__':
    start_admin_panel()