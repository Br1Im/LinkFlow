# -*- coding: utf-8 -*-
"""
Простая функция создания платежа - РАБОЧИЙ КОД из temp_webhook.py
"""

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from selenium.common.exceptions import TimeoutException, WebDriverException
import time
import subprocess
import tempfile
import logging

logger = logging.getLogger(__name__)

def kill_chrome_processes():
    """Убиваем все процессы Chrome перед запуском"""
    try:
        subprocess.run(['pkill', '-f', 'chrome'], capture_output=True, timeout=5)
        subprocess.run(['pkill', '-f', 'chromium'], capture_output=True, timeout=5)
        time.sleep(1)
    except:
        pass

def create_ultra_stable_driver():
    """Создание максимально стабильного Chrome драйвера"""
    
    kill_chrome_processes()
    
    options = webdriver.ChromeOptions()
    
    # КРИТИЧЕСКИЕ настройки для стабильности
    options.add_argument('--headless=new')
    options.add_argument('--no-sandbox')
    options.add_argument('--disable-dev-shm-usage')
    options.add_argument('--disable-gpu')
    options.add_argument('--disable-software-rasterizer')
    options.add_argument('--disable-setuid-sandbox')
    
    # Отключаем всё что может вызвать проблемы
    options.add_argument('--disable-blink-features=AutomationControlled')
    options.add_argument('--disable-extensions')
    options.add_argument('--disable-plugins')
    options.add_argument('--disable-images')
    # НЕ отключаем JavaScript - он нужен для авторизации!
    # options.add_argument('--disable-javascript')
    options.add_argument('--disable-web-security')
    options.add_argument('--disable-features=VizDisplayCompositor')
    options.add_argument('--disable-features=LockProfileCookieDatabase')
    options.add_argument('--disable-site-isolation-trials')
    options.add_argument('--disable-background-networking')
    options.add_argument('--disable-sync')
    options.add_argument('--disable-default-apps')
    options.add_argument('--disable-background-timer-throttling')
    options.add_argument('--disable-backgrounding-occluded-windows')
    options.add_argument('--disable-renderer-backgrounding')
    options.add_argument('--disable-field-trial-config')
    options.add_argument('--disable-ipc-flooding-protection')
    
    # Память и производительность
    options.add_argument('--memory-pressure-off')
    options.add_argument('--max_old_space_size=4096')
    # НЕ используем --single-process - он нестабилен
    # options.add_argument('--single-process')
    
    # Размер окна
    options.add_argument('--window-size=1920,1080')
    options.add_argument('--start-maximized')
    
    # Отключаем логи и автоматизацию
    options.add_experimental_option('excludeSwitches', ['enable-logging', 'enable-automation'])
    options.add_experimental_option('useAutomationExtension', False)
    
    # Быстрая загрузка страниц
    options.page_load_strategy = 'eager'
    
    # Создаем временную директорию для профиля
    temp_dir = tempfile.mkdtemp()
    options.add_argument(f'--user-data-dir={temp_dir}')
    
    try:
        service = Service('/usr/bin/chromedriver')
        driver = webdriver.Chrome(service=service, options=options)
    except:
        try:
            driver = webdriver.Chrome(options=options)
        except Exception as e:
            logger.error(f"Не удалось создать Chrome драйвер: {e}")
            raise
    
    driver.set_page_load_timeout(60)
    driver.implicitly_wait(10)
    
    return driver

def create_payment_ultra_stable(amount, requisite, account):
    """Создание платежа с максимальной стабильностью"""
    driver = None
    start_time = time.time()
    
    try:
        logger.info(f"[{time.time()-start_time:.1f}s] Создаю ультра-стабильный браузер...")
        
        driver = create_ultra_stable_driver()
        
        logger.info(f"[{time.time()-start_time:.1f}s] Браузер создан, открываю elecsnet...")
        
        # Переходим на elecsnet с повторными попытками
        max_retries = 3
        for attempt in range(max_retries):
            try:
                driver.get('https://1.elecsnet.ru/NotebookFront/services/0mhp/default.aspx?merchantId=36924&fromSegment=')
                logger.info(f"[{time.time()-start_time:.1f}s] Страница загружена (попытка {attempt + 1})")
                break
            except Exception as e:
                logger.warning(f"Попытка {attempt + 1} не удалась: {e}")
                if attempt == max_retries - 1:
                    raise
                time.sleep(2)
        
        time.sleep(1.2)  # Уменьшено с 1.5 до 1.2
        
        # Проверяем, нужна ли авторизация
        is_authorized = False
        try:
            login_btn = driver.find_element(By.CSS_SELECTOR, "a.login[href='main']")
            logger.info(f"[{time.time()-start_time:.1f}s] Требуется авторизация...")
            
            driver.execute_script("document.querySelector('a.login[href=\"main\"]').click();")
            time.sleep(0.2)  # Уменьшено с 0.3 до 0.2
            
            wait = WebDriverWait(driver, 5)  # Уменьшено с 6 до 5
            popup = wait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, "div.popup.login")))
            
            phone_input = driver.find_element(By.CSS_SELECTOR, "div.popup.login #Login_Value")
            phone_clean = account['phone'].replace("+7", "").replace(" ", "").replace("-", "")
            phone_input.send_keys(phone_clean)
            
            password_input = driver.find_element(By.CSS_SELECTOR, "div.popup.login #Password_Value")
            password_input.send_keys(account['password'])
            
            auth_btn = driver.find_element(By.CSS_SELECTOR, "div.popup.login #authBtn")
            driver.execute_script("arguments[0].click();", auth_btn)
            time.sleep(1.2)  # Уменьшено с 1.5 до 1.2
            
            driver.get('https://1.elecsnet.ru/NotebookFront/services/0mhp/default.aspx?merchantId=36924&fromSegment=')
            time.sleep(0.8)  # Уменьшено с 1 до 0.8
            
            try:
                driver.find_element(By.NAME, "requisites.m-36924.f-1")
                is_authorized = True
                logger.info(f"[{time.time()-start_time:.1f}s] ✅ Авторизация успешна")
            except:
                raise Exception("Авторизация не удалась - форма оплаты не найдена")
                
        except Exception as auth_error:
            if "форма оплаты не найдена" in str(auth_error):
                raise auth_error
            try:
                driver.find_element(By.NAME, "requisites.m-36924.f-1")
                is_authorized = True
                logger.info(f"[{time.time()-start_time:.1f}s] ✅ Уже авторизован")
            except:
                raise Exception("Не авторизован и не удалось авторизоваться")
        
        if not is_authorized:
            raise Exception("Авторизация не выполнена")
        
        # Заполняем реквизиты
        wait = WebDriverWait(driver, 20)
        
        logger.info(f"[{time.time()-start_time:.1f}s] Заполняю реквизиты...")
        
        card_input = wait.until(EC.element_to_be_clickable((By.NAME, "requisites.m-36924.f-1")))
        card_input.clear()
        card_input.send_keys(requisite['card_number'])
        
        name_input = wait.until(EC.element_to_be_clickable((By.NAME, "requisites.m-36924.f-2")))
        name_input.clear()
        name_input.send_keys(requisite['owner_name'])
        
        # Заполняем сумму
        logger.info(f"[{time.time()-start_time:.1f}s] Заполняю сумму {amount}...")
        amount_input = wait.until(EC.element_to_be_clickable((By.NAME, "summ.transfer")))
        amount_input.clear()
        amount_formatted = f"{int(amount):,}".replace(",", " ")
        amount_input.send_keys(amount_formatted)
        
        time.sleep(0.6)  # Увеличено с 0.5 до 0.6
        
        # Ждем обработки суммы - СБАЛАНСИРОВАННАЯ ОПТИМИЗАЦИЯ
        for i in range(18):  # Увеличено для надежности
            try:
                loader = driver.find_element(By.ID, "loadercontainer")
                if "display: none" in loader.get_attribute("style") or not loader.is_displayed():
                    logger.info(f"[{time.time()-start_time:.1f}s] Loader исчез после {i} попыток")
                    break
            except:
                break
            time.sleep(0.2)  # Оставляем 0.2
        
        # Нажимаем Оплатить
        logger.info(f"[{time.time()-start_time:.1f}s] Ищу кнопку Оплатить...")
        submit_btn = wait.until(EC.presence_of_element_located((By.NAME, "SubmitBtn")))
        
        # Ждем активации кнопки - СБАЛАНСИРОВАННАЯ ОПТИМИЗАЦИЯ
        for i in range(25):  # Увеличено для надежности
            disabled = submit_btn.get_attribute("disabled")
            if not disabled:
                logger.info(f"[{time.time()-start_time:.1f}s] Кнопка активна после {i} попыток")
                break
            time.sleep(0.2)  # Оставляем 0.2
        else:
            logger.warning(f"[{time.time()-start_time:.1f}s] Кнопка все еще disabled, но продолжаю...")
        
        time.sleep(0.6)  # Увеличено с 0.5 до 0.6
        
        # Проверяем заполнение полей перед нажатием
        logger.info(f"[{time.time()-start_time:.1f}s] Проверяю заполнение полей...")
        try:
            card_value = driver.find_element(By.NAME, "requisites.m-36924.f-1").get_attribute("value")
            name_value = driver.find_element(By.NAME, "requisites.m-36924.f-2").get_attribute("value")
            amount_value = driver.find_element(By.NAME, "summ.transfer").get_attribute("value")
            logger.info(f"[{time.time()-start_time:.1f}s] Карта: {card_value}, Имя: {name_value}, Сумма: {amount_value}")
        except Exception as e:
            logger.warning(f"Не удалось проверить поля: {e}")
        
        # Дополнительная проверка что loader исчез
        logger.info(f"[{time.time()-start_time:.1f}s] Финальная проверка loader...")
        for i in range(10):
            try:
                loader = driver.find_element(By.ID, "loadercontainer")
                if "display: none" in loader.get_attribute("style") or not loader.is_displayed():
                    logger.info(f"[{time.time()-start_time:.1f}s] Loader точно исчез")
                    break
            except:
                break
            time.sleep(0.2)
        
        # Нажимаем кнопку
        logger.info(f"[{time.time()-start_time:.1f}s] Нажимаю кнопку Оплатить...")
        try:
            # Пробуем обычный клик
            submit_btn.click()
            logger.info(f"[{time.time()-start_time:.1f}s] ✓ Кнопка нажата (обычный клик)")
        except Exception as e:
            logger.warning(f"Обычный клик не сработал: {e}, пробую JS...")
            try:
                driver.execute_script("arguments[0].click();", submit_btn)
                logger.info(f"[{time.time()-start_time:.1f}s] ✓ Кнопка нажата (JS клик)")
            except Exception as e2:
                logger.error(f"JS клик не сработал: {e2}, пробую прямой JS...")
                try:
                    driver.execute_script("document.querySelector('input[name=\"SubmitBtn\"]').click();")
                    logger.info(f"[{time.time()-start_time:.1f}s] ✓ Альтернативное нажатие")
                except Exception as e3:
                    raise Exception(f"Не удалось нажать кнопку: {e}, {e2}, {e3}")
        
        logger.info(f"[{time.time()-start_time:.1f}s] Ожидаю результат...")
        
        # Ждем изменения URL или появления результата
        old_url = driver.current_url
        logger.info(f"[{time.time()-start_time:.1f}s] URL до отправки: {old_url}")
        
        time.sleep(1)  # Уменьшено с 2 до 1 - даем время на отправку формы
        
        # Проверяем изменился ли URL
        new_url = driver.current_url
        logger.info(f"[{time.time()-start_time:.1f}s] URL после отправки: {new_url}")
        
        if old_url == new_url:
            logger.warning(f"[{time.time()-start_time:.1f}s] ⚠️ URL не изменился! Возможно форма не отправилась")
            # Проверяем наличие ошибок на странице
            try:
                error_elements = driver.find_elements(By.CSS_SELECTOR, ".error, .alert, .warning")
                if error_elements:
                    for err in error_elements:
                        if err.is_displayed():
                            logger.error(f"Ошибка на странице: {err.text}")
            except:
                pass
        
        # Ждем результат - АГРЕССИВНАЯ ОПТИМИЗАЦИЯ
        for i in range(50):  # Увеличено количество попыток для более частой проверки
            try:
                # Проверяем URL - если перешли на SBP, значит готово
                current_url = driver.current_url
                if "/SBP/" in current_url or "/sbp/" in current_url.lower():
                    logger.info(f"[{time.time()-start_time:.1f}s] Переход на SBP страницу!")
                    break
                    
                loader = driver.find_element(By.ID, "loadercontainer")
                if "display: none" in loader.get_attribute("style") or not loader.is_displayed():
                    break
            except:
                break
            time.sleep(0.2)  # Уменьшено с 0.3 до 0.2 - проверяем чаще
        
        time.sleep(0.3)  # Уменьшено с 0.5 до 0.3
        
        current_url = driver.current_url
        logger.info(f"[{time.time()-start_time:.1f}s] Текущий URL: {current_url}")
        
        logger.info(f"[{time.time()-start_time:.1f}s] Ищу результат...")
        
        wait_result = WebDriverWait(driver, 30)
        
        # Ищем QR код
        qr_code_base64 = None
        try:
            qr_img = wait_result.until(EC.presence_of_element_located((By.ID, "Image1")))
            qr_code_base64 = qr_img.get_attribute("src")
            logger.info(f"[{time.time()-start_time:.1f}s] QR найден")
        except:
            try:
                qr_img = driver.find_element(By.CSS_SELECTOR, "img[src*='qr'], img[src*='data:image']")
                qr_code_base64 = qr_img.get_attribute("src")
                logger.info(f"[{time.time()-start_time:.1f}s] QR найден альтернативным способом")
            except:
                logger.error(f"[{time.time()-start_time:.1f}s] QR код не найден")
        
        # Ищем ссылку на оплату
        payment_link = None
        try:
            payment_link_element = wait_result.until(EC.presence_of_element_located((By.ID, "LinkMobil")))
            payment_link = payment_link_element.get_attribute("href")
            logger.info(f"[{time.time()-start_time:.1f}s] Ссылка найдена")
        except:
            try:
                payment_link_element = driver.find_element(By.CSS_SELECTOR, "a[href*='qr.nspk.ru'], a[href*='nspk']")
                payment_link = payment_link_element.get_attribute("href")
                logger.info(f"[{time.time()-start_time:.1f}s] Ссылка найдена альтернативным способом")
            except:
                logger.error(f"[{time.time()-start_time:.1f}s] Ссылка не найдена")
        
        if not payment_link or not qr_code_base64:
            raise Exception(f"Не удалось найти элементы результата. URL: {current_url}")
        
        elapsed = time.time() - start_time
        logger.info(f"✅ Платеж создан за {elapsed:.1f} сек!")
        
        return {
            "payment_link": payment_link,
            "qr_base64": qr_code_base64,
            "elapsed_time": elapsed
        }
        
    except Exception as e:
        elapsed = time.time() - start_time
        logger.error(f"❌ Ошибка создания платежа: {e}")
        
        screenshot_base64 = None
        page_source = None
        if driver:
            try:
                logger.info(f"[{elapsed:.1f}s] Делаю скриншот ошибки...")
                screenshot = driver.get_screenshot_as_base64()
                screenshot_base64 = f"data:image/png;base64,{screenshot}"
                
                page_source = driver.page_source[:3000]
                logger.info(f"[{elapsed:.1f}s] Скриншот сохранен")
            except Exception as screenshot_error:
                logger.error(f"Не удалось сделать скриншот: {screenshot_error}")
        
        return {
            "error": str(e),
            "elapsed_time": elapsed,
            "screenshot": screenshot_base64,
            "page_source_preview": page_source
        }
    finally:
        if driver:
            try:
                driver.quit()
                logger.info(f"[{time.time()-start_time:.1f}s] Браузер закрыт")
            except:
                pass
            
            kill_chrome_processes()
