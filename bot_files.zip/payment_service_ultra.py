# -*- coding: utf-8 -*-
"""
Сервис создания платежей с прогретым браузером
УЛЬТРА-БЫСТРАЯ ВЕРСИЯ - 3-8 секунд на платеж
Браузер всегда готов, авторизован, с предзаполненными реквизитами
"""

import base64
import time
import os
import threading
import logging
from browser_manager import browser_manager
from database import db
from config import *

logger = logging.getLogger(__name__)

# Глобальные переменные для мониторинга
_last_auth_check = 0
_auth_check_interval = 1800  # 30 минут
_warmup_lock = threading.Lock()
_payment_lock = threading.Lock()  # Блокировка для создания платежей

def initialize_warmed_browser():
    """Инициализация и прогрев браузера с полной подготовкой"""
    global _last_auth_check
    
    with _warmup_lock:
        requisites = db.get_requisites()
        accounts = db.get_accounts()
        
        if not requisites or not accounts:
            print("⚠️ Нет аккаунтов или карт для инициализации браузера", flush=True)
            return False
        
        requisite = requisites[0]
        account = accounts[0]
        
        print(f"🔥 ИНИЦИАЛИЗАЦИЯ ПРОГРЕТОГО БРАУЗЕРА", flush=True)
        print(f"   Аккаунт: {account['phone']}", flush=True)
        print(f"   Карта: {requisite['card_number']}", flush=True)
        
        # Прогреваем браузер с полной подготовкой
        success = browser_manager.warmup_full(
            card_number=requisite['card_number'],
            owner_name=requisite['owner_name'],
            account=account
        )
        
        if success:
            _last_auth_check = time.time()
            print("🚀 БРАУЗЕР ГОТОВ К МГНОВЕННОМУ СОЗДАНИЮ ПЛАТЕЖЕЙ!", flush=True)
            
            # Запускаем фоновую проверку авторизации
            start_auth_monitor()
        
        return success

def check_and_refresh_auth():
    """Проверка и обновление авторизации каждые 30 минут"""
    global _last_auth_check
    
    current_time = time.time()
    if current_time - _last_auth_check < _auth_check_interval:
        return True
    
    print("🔄 Проверка авторизации (каждые 30 минут)...", flush=True)
    
    try:
        if browser_manager.check_auth():
            _last_auth_check = current_time
            print("✅ Авторизация актуальна", flush=True)
            return True
        else:
            print("⚠️ Авторизация устарела, обновляю...", flush=True)
            success = browser_manager.refresh_auth()
            if success:
                _last_auth_check = current_time
                print("✅ Авторизация обновлена", flush=True)
            return success
    except Exception as e:
        print(f"❌ Ошибка проверки авторизации: {e}", flush=True)
        return False

def start_auth_monitor():
    """Запуск фонового мониторинга авторизации"""
    def monitor():
        while browser_manager.is_ready:
            time.sleep(300)  # Проверяем каждые 5 минут
            if browser_manager.is_ready:
                check_and_refresh_auth()
    
    monitor_thread = threading.Thread(target=monitor, daemon=True)
    monitor_thread.start()
    print("🔍 Запущен мониторинг авторизации", flush=True)

def create_payment_fast(amount, send_callback=None):
    """
    УЛЬТРА-БЫСТРОЕ создание платежа - 3-8 секунд
    Использует полностью прогретый браузер
    """
    # КРИТИЧНО: Блокируем одновременное использование браузера
    with _payment_lock:
        start_time = time.time()
        
        print(f"⚡ УЛЬТРА-БЫСТРОЕ создание платежа на {amount} сум...", flush=True)
    
        # Проверяем готовность прогретого браузера
        if not browser_manager.is_ready:
            print("⚠️ Браузер не готов, инициализирую...", flush=True)
            if not initialize_warmed_browser():
                return {
                    "error": "Не удалось инициализировать браузер",
                    "elapsed_time": time.time() - start_time,
                    "success": False
                }
    
        # Проверяем авторизацию
        if not check_and_refresh_auth():
            print("❌ Проблемы с авторизацией, перепрогреваю браузер...", flush=True)
            if not initialize_warmed_browser():
                return {
                    "error": "Не удалось восстановить авторизацию",
                    "elapsed_time": time.time() - start_time,
                    "success": False
                }
    
        # Создаем платеж с прогретым браузером
        try:
            result = create_payment_with_warmed_browser(amount, start_time)
            
            # Обработка результата
            if result and result.get('payment_link'):
                # Сохраняем QR код
                qr_base64 = result.get('qr_base64', '')
                if qr_base64:
                    try:
                        qr_code_data = qr_base64.split(",")[1] if "," in qr_base64 else qr_base64
                        qr_filename = f"qr_{int(time.time())}.png"
                        
                        if not os.path.exists(QR_TEMP_PATH):
                            os.makedirs(QR_TEMP_PATH)
                        
                        qr_filepath = os.path.join(QR_TEMP_PATH, qr_filename)
                        with open(qr_filepath, "wb") as f:
                            f.write(base64.b64decode(qr_code_data))
                        
                        result["qr_filename"] = qr_filename
                        
                        # Callback если есть
                        if send_callback and callable(send_callback):
                            try:
                                send_callback(result['payment_link'], qr_filepath)
                            except Exception as e:
                                print(f"❌ Ошибка callback: {e}", flush=True)
                    except Exception as e:
                        print(f"⚠️ Ошибка сохранения QR: {e}", flush=True)
                
                result["success"] = True
                result["mode"] = "warmed_ultra_fast"
                
            else:
                if not result:
                    result = {}
                result["success"] = False
                result["mode"] = "warmed_ultra_fast"
                if not result.get("error"):
                    result["error"] = "Неизвестная ошибка создания платежа"
            
            return result
            
        except Exception as e:
            print(f"❌ Критическая ошибка: {e}", flush=True)
            return {
                "error": str(e),
                "elapsed_time": time.time() - start_time,
                "success": False,
                "mode": "warmed_ultra_fast"
            }

def create_payment_with_warmed_browser(amount, start_time):
    """
    Создание платежа с полностью прогретым браузером - МАКСИМАЛЬНАЯ СКОРОСТЬ
    Браузер уже авторизован и с предзаполненными реквизитами
    """
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    
    driver = browser_manager.driver
    
    if not driver:
        raise Exception("Прогретый браузер недоступен")
    
    try:
        print(f"[{time.time()-start_time:.1f}s] ⚡ Используем ПРОГРЕТЫЙ браузер...", flush=True)
        
        # Браузер уже на нужной странице с авторизацией и реквизитами!
        # Нужно только ввести сумму и нажать кнопку
        
        wait = WebDriverWait(driver, 8)
        
        # Проверяем что мы на правильной странице
        try:
            amount_input = driver.find_element(By.NAME, "summ.transfer")
            print(f"[{time.time()-start_time:.1f}s] ✅ Браузер на странице оплаты", flush=True)
        except:
            # Если не на странице оплаты, переходим
            print(f"[{time.time()-start_time:.1f}s] 🔄 Переход на страницу оплаты...", flush=True)
            driver.get('https://1.elecsnet.ru/NotebookFront/services/0mhp/default.aspx?merchantId=36924&fromSegment=')
            time.sleep(0.3)
            amount_input = wait.until(EC.element_to_be_clickable((By.NAME, "summ.transfer")))
        
        # Заполняем ТОЛЬКО сумму (реквизиты уже заполнены!)
        print(f"[{time.time()-start_time:.1f}s] 💰 Заполняю сумму {amount}...", flush=True)
        
        # Проверяем что поле суммы доступно
        try:
            amount_input = driver.find_element(By.NAME, "summ.transfer")
            print(f"[{time.time()-start_time:.1f}s] ✅ Поле суммы найдено", flush=True)
        except Exception as e:
            print(f"[{time.time()-start_time:.1f}s] ❌ Поле суммы не найдено: {e}", flush=True)
            raise Exception("Поле суммы недоступно")
        
        # Очищаем и заполняем поле суммы
        amount_input.clear()
        amount_formatted = f"{int(amount):,}".replace(",", " ")
        amount_input.send_keys(amount_formatted)
        print(f"[{time.time()-start_time:.1f}s] ✅ Сумма {amount_formatted} введена", flush=True)
        
        # Проверяем что сумма действительно введена
        entered_value = amount_input.get_attribute('value')
        print(f"[{time.time()-start_time:.1f}s] 📊 Введенное значение: '{entered_value}'", flush=True)
        
        # МАКСИМАЛЬНО ОПТИМИЗИРОВАННОЕ ожидание обработки суммы
        print(f"[{time.time()-start_time:.1f}s] ⏳ Ждем обработки суммы (МАКСИМАЛЬНО БЫСТРО)...", flush=True)
        
        # Минимальная начальная пауза
        time.sleep(1.0)  # Уменьшено с 1.5 до 1.0 секунды
        
        # Ждем пока сайт полностью обработает сумму - МАКСИМАЛЬНО БЫСТРО
        calculation_complete = False
        for i in range(20):  # Уменьшено с 25 до 20 попыток
            try:
                # ТОЛЬКО самые важные проверки
                button_ready = False
                try:
                    submit_btn = driver.find_element(By.NAME, "SubmitBtn")
                    button_disabled = submit_btn.get_attribute("disabled")
                    button_enabled = submit_btn.is_enabled()
                    button_ready = not button_disabled and button_enabled
                except:
                    button_ready = False
                
                # Лоадер скрыт
                loader_hidden = True
                try:
                    loader = driver.find_element(By.ID, "loadercontainer")
                    loader_style = loader.get_attribute("style")
                    loader_displayed = loader.is_displayed()
                    loader_hidden = "display: none" in loader_style or not loader_displayed
                except:
                    loader_hidden = True
                
                # УПРОЩЕННЫЕ КРИТЕРИИ для максимальной скорости
                if button_ready and loader_hidden:
                    print(f"[{time.time()-start_time:.1f}s] ✅ Сайт обработал сумму после {i+1} попыток", flush=True)
                    calculation_complete = True
                    break
                    
                if i % 10 == 0:  # Логируем очень редко
                    print(f"[{time.time()-start_time:.1f}s] 📊 Ожидание: btn={button_ready}, loader={loader_hidden}", flush=True)
                    
            except Exception as e:
                if i % 18 == 0:  # Логируем ошибки очень редко
                    print(f"[{time.time()-start_time:.1f}s] ⚠️ Ошибка проверки: {e}", flush=True)
            
            time.sleep(0.2)  # Уменьшено с 0.3 до 0.2 секунды - проверяем еще чаще
        
        if not calculation_complete:
            print(f"[{time.time()-start_time:.1f}s] ⚠️ Продолжаю без полной проверки", flush=True)
        
        # МИНИМАЛЬНАЯ дополнительная пауза
        print(f"[{time.time()-start_time:.1f}s] ⏳ Минимальная пауза...", flush=True)
        time.sleep(0.5)  # Уменьшено с 0.8 до 0.5 секунды
        
        # Нажимаем Оплатить
        print(f"[{time.time()-start_time:.1f}s] 🚀 Ищу кнопку Оплатить...", flush=True)
        
        # Получаем свежую ссылку на кнопку
        submit_btn = None
        try:
            submit_btn = wait.until(EC.presence_of_element_located((By.NAME, "SubmitBtn")))
        except:
            # Альтернативный поиск кнопки
            try:
                submit_btn = driver.find_element(By.CSS_SELECTOR, "input[type='submit'], button[type='submit']")
            except:
                raise Exception("Кнопка Оплатить не найдена")
        
        # УПРОЩЕННАЯ проверка кнопки для скорости
        print(f"[{time.time()-start_time:.1f}s] 🔍 Быстрая проверка кнопки...", flush=True)
        final_check_passed = False
        for i in range(5):  # Уменьшено с 10 до 5 попыток
            try:
                # Получаем свежую ссылку на кнопку
                submit_btn = driver.find_element(By.NAME, "SubmitBtn")
                
                # УПРОЩЕННАЯ проверка состояния кнопки
                disabled = submit_btn.get_attribute("disabled")
                enabled = submit_btn.is_enabled()
                
                button_ready = (not disabled and enabled)
                
                if button_ready:
                    print(f"[{time.time()-start_time:.1f}s] ✅ Кнопка готова к нажатию", flush=True)
                    final_check_passed = True
                    break
                    
                if i % 2 == 0:  # Логируем реже
                    print(f"[{time.time()-start_time:.1f}s] 📊 Кнопка: disabled={disabled}, enabled={enabled}", flush=True)
                    
            except Exception as e:
                if i % 3 == 0:
                    print(f"[{time.time()-start_time:.1f}s] ⚠️ Ошибка проверки: {e}", flush=True)
            time.sleep(0.2)  # Уменьшено с 0.5 до 0.2
        
        if not final_check_passed:
            print(f"[{time.time()-start_time:.1f}s] ⚠️ Продолжаю без полной проверки кнопки", flush=True)
        
        # Нажимаем кнопку - БЫСТРЫЙ подход
        print(f"[{time.time()-start_time:.1f}s] 🚀 Нажимаю кнопку Оплатить (БЫСТРО)...", flush=True)
        
        # Получаем свежую ссылку на кнопку перед кликом
        try:
            submit_btn = wait.until(EC.element_to_be_clickable((By.NAME, "SubmitBtn")))
        except:
            submit_btn = driver.find_element(By.NAME, "SubmitBtn")
        
        # Подготовка к клику
        driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", submit_btn)
        time.sleep(0.1)  # Минимальная пауза
        
        # Быстрый клик - сначала JavaScript
        click_success = False
        try:
            driver.execute_script("""
                var btn = arguments[0];
                btn.disabled = false;
                btn.removeAttribute('disabled');
                btn.click();
            """, submit_btn)
            print(f"[{time.time()-start_time:.1f}s] ✓ JavaScript клик выполнен", flush=True)
            click_success = True
        except Exception as e:
            print(f"[{time.time()-start_time:.1f}s] ⚠️ JavaScript клик не сработал: {e}", flush=True)
            # Fallback - стандартный клик
            try:
                submit_btn.click()
                print(f"[{time.time()-start_time:.1f}s] ✓ Стандартный клик выполнен", flush=True)
                click_success = True
            except Exception as e2:
                print(f"[{time.time()-start_time:.1f}s] ❌ Все клики не сработали: {e2}", flush=True)
                raise Exception(f"Не удалось нажать кнопку: {e}, {e2}")
        
        if not click_success:
            raise Exception("Не удалось нажать кнопку Оплатить")
        
        # Ждем результат - МАКСИМАЛЬНО БЫСТРОЕ ОЖИДАНИЕ
        print(f"[{time.time()-start_time:.1f}s] ⏳ Ожидаю результат (МАКСИМАЛЬНО БЫСТРО)...", flush=True)
        time.sleep(0.3)  # Еще меньше начальная пауза
        
        # Ждем перехода на страницу результата или появления результата - АГРЕССИВНО БЫСТРО
        result_found = False
        for i in range(25):  # Увеличено до 25 попыток, но с меньшим интервалом
            try:
                current_url = driver.current_url
                
                # Проверяем переход на SBP страницу
                if "/SBP/" in current_url or "/sbp/" in current_url.lower():
                    print(f"[{time.time()-start_time:.1f}s] 🎯 Переход на SBP страницу!", flush=True)
                    result_found = True
                    break
                    
                # Проверяем появление QR кода на текущей странице
                try:
                    qr_img = driver.find_element(By.ID, "Image1")
                    if qr_img.get_attribute("src"):
                        print(f"[{time.time()-start_time:.1f}s] 🎯 QR код появился на странице!", flush=True)
                        result_found = True
                        break
                except:
                    pass
                    
                # Проверяем появление ссылки на оплату
                try:
                    payment_link_element = driver.find_element(By.ID, "LinkMobil")
                    if payment_link_element.get_attribute("href"):
                        print(f"[{time.time()-start_time:.1f}s] 🎯 Ссылка оплаты появилась!", flush=True)
                        result_found = True
                        break
                except:
                    pass
                
                # Проверяем на ошибки
                try:
                    error_elements = driver.find_elements(By.CSS_SELECTOR, ".error, .alert-danger, .validation-error")
                    for error_el in error_elements:
                        if error_el.is_displayed() and error_el.text.strip():
                            error_text = error_el.text.strip()
                            print(f"[{time.time()-start_time:.1f}s] ❌ Ошибка на странице: {error_text}", flush=True)
                            raise Exception(f"Ошибка на сайте: {error_text}")
                except Exception as error_check:
                    if "Ошибка на сайте:" in str(error_check):
                        raise error_check
                
                if i % 10 == 0:  # Логируем еще реже
                    print(f"[{time.time()-start_time:.1f}s] 📊 Ожидание результата... URL: {current_url[:60]}", flush=True)
                    
            except Exception as e:
                if "Ошибка на сайте:" in str(e):
                    raise e
                if i % 20 == 0:  # Логируем ошибки очень редко
                    print(f"[{time.time()-start_time:.1f}s] ⚠️ Ошибка проверки результата: {e}", flush=True)
            
            time.sleep(0.3)  # Уменьшено с 0.5 до 0.3 секунды - проверяем чаще
        
        if not result_found:
            print(f"[{time.time()-start_time:.1f}s] ⚠️ Продолжаю поиск элементов...", flush=True)
        
        # Минимальное дополнительное время для полной загрузки
        time.sleep(0.3)  # Уменьшено с 0.5 до 0.3 секунды
        
        current_url = driver.current_url
        print(f"[{time.time()-start_time:.1f}s] 📍 Текущий URL: {current_url}", flush=True)
        
        wait_result = WebDriverWait(driver, 5)  # Уменьшено с 10 до 5 секунд
        
        # Ищем QR код - БЫСТРО
        qr_code_base64 = None
        try:
            qr_img = wait_result.until(EC.presence_of_element_located((By.ID, "Image1")))
            qr_code_base64 = qr_img.get_attribute("src")
            print(f"[{time.time()-start_time:.1f}s] ✅ QR найден", flush=True)
        except:
            try:
                qr_img = driver.find_element(By.CSS_SELECTOR, "img[src*='qr'], img[src*='data:image']")
                qr_code_base64 = qr_img.get_attribute("src")
                print(f"[{time.time()-start_time:.1f}s] ✅ QR найден (альтернативно)", flush=True)
            except:
                print(f"[{time.time()-start_time:.1f}s] ❌ QR код не найден", flush=True)
        
        # Ищем ссылку на оплату - БЫСТРО
        payment_link = None
        try:
            payment_link_element = wait_result.until(EC.presence_of_element_located((By.ID, "LinkMobil")))
            payment_link = payment_link_element.get_attribute("href")
            print(f"[{time.time()-start_time:.1f}s] ✅ Ссылка найдена", flush=True)
        except:
            try:
                payment_link_element = driver.find_element(By.CSS_SELECTOR, "a[href*='qr.nspk.ru'], a[href*='nspk']")
                payment_link = payment_link_element.get_attribute("href")
                print(f"[{time.time()-start_time:.1f}s] ✅ Ссылка найдена (альтернативно)", flush=True)
            except:
                print(f"[{time.time()-start_time:.1f}s] ❌ Ссылка не найдена", flush=True)
        
        if not payment_link or not qr_code_base64:
            # Сохраняем скриншот для диагностики
            try:
                screenshot_path = f'/tmp/debug_payment_{int(time.time())}.png'
                driver.save_screenshot(screenshot_path)
                print(f"[{time.time()-start_time:.1f}s] 📸 Скриншот ошибки сохранен: {screenshot_path}", flush=True)
                print(f"[{time.time()-start_time:.1f}s] 📍 Текущий URL: {driver.current_url}", flush=True)
                print(f"[{time.time()-start_time:.1f}s] 📄 Заголовок: {driver.title}", flush=True)
                
                # Ищем все ссылки на странице
                links = driver.find_elements(By.TAG_NAME, "a")
                print(f"[{time.time()-start_time:.1f}s] 🔗 Найдено {len(links)} ссылок на странице", flush=True)
                for i, link in enumerate(links[:5]):  # Показываем первые 5
                    href = link.get_attribute("href")
                    if href and ("qr" in href.lower() or "nspk" in href.lower()):
                        print(f"[{time.time()-start_time:.1f}s] 🎯 Найдена потенциальная ссылка {i}: {href}", flush=True)
                
                # Ищем все изображения
                images = driver.find_elements(By.TAG_NAME, "img")
                print(f"[{time.time()-start_time:.1f}s] 🖼️ Найдено {len(images)} изображений на странице", flush=True)
                for i, img in enumerate(images[:5]):  # Показываем первые 5
                    src = img.get_attribute("src")
                    if src and ("qr" in src.lower() or "data:image" in src.lower()):
                        print(f"[{time.time()-start_time:.1f}s] 🎯 Найдено потенциальное QR {i}: {src[:100]}...", flush=True)
                        
            except Exception as debug_error:
                print(f"[{time.time()-start_time:.1f}s] ⚠️ Ошибка отладки: {debug_error}", flush=True)
            
            raise Exception(f"Не удалось найти элементы результата. Link: {payment_link is not None}, QR: {qr_code_base64 is not None}, URL: {current_url}")
        
        elapsed = time.time() - start_time
        print(f"🚀⚡ ПЛАТЕЖ СОЗДАН ЗА {elapsed:.1f} СЕК С ПРОГРЕТЫМ БРАУЗЕРОМ! ⚡🚀", flush=True)
        
        # Возвращаемся на страницу оплаты для следующего платежа - БЫСТРО
        try:
            driver.get('https://1.elecsnet.ru/NotebookFront/services/0mhp/default.aspx?merchantId=36924&fromSegment=')
            print(f"[{time.time()-start_time:.1f}s] 🔄 Возврат на страницу оплаты...", flush=True)
            
            # Минимальное ожидание загрузки
            wait_return = WebDriverWait(driver, 5)  # Уменьшено с 10 до 5
            wait_return.until(EC.invisibility_of_element_located((By.ID, "loadercontainer")))
            
            card_input = wait_return.until(EC.presence_of_element_located((By.NAME, "requisites.m-36924.f-1")))
            name_input = wait_return.until(EC.presence_of_element_located((By.NAME, "requisites.m-36924.f-2")))
            
            # Заполняем реквизиты для следующего платежа
            from database import db
            requisites = db.get_requisites()
            if requisites:
                requisite = requisites[0]
                driver.execute_script("""
                    arguments[0].value = arguments[2];
                    arguments[0].dispatchEvent(new Event('input', { bubbles: true }));
                    arguments[1].value = arguments[3];
                    arguments[1].dispatchEvent(new Event('input', { bubbles: true }));
                """, card_input, name_input, requisite['card_number'], requisite['owner_name'])
                
                print(f"[{time.time()-start_time:.1f}s] ✅ Браузер готов к следующему платежу", flush=True)
                # НЕ сбрасываем is_ready - браузер остается готовым!
            else:
                print(f"[{time.time()-start_time:.1f}s] ⚠️ Нет реквизитов для восстановления", flush=True)
                browser_manager.is_ready = False
                
        except Exception as restore_error:
            print(f"[{time.time()-start_time:.1f}s] ⚠️ Ошибка восстановления браузера: {restore_error}", flush=True)
            browser_manager.is_ready = False
        
        return {
            "payment_link": payment_link,
            "qr_base64": qr_code_base64,
            "elapsed_time": elapsed
        }
        
    except Exception as e:
        elapsed = time.time() - start_time
        error_msg = str(e)
        print(f"❌ Ошибка создания платежа с прогретым браузером: {error_msg}", flush=True)
        
        # Если это ошибка сессии, перепрогреваем браузер
        if "invalid session id" in error_msg.lower() or "session" in error_msg.lower():
            print("🔄 Обнаружена ошибка сессии, перепрогреваю браузер...", flush=True)
            browser_manager.is_ready = False
            # Попробуем создать платеж еще раз с новым браузером
            if initialize_warmed_browser():
                print("🔄 Браузер перепрогрет, повторяю попытку...", flush=True)
                try:
                    return create_payment_with_warmed_browser(amount, start_time)
                except Exception as retry_error:
                    print(f"❌ Повторная попытка не удалась: {retry_error}", flush=True)
        
        # Если прогретый браузер сломался, сбрасываем его состояние
        browser_manager.is_ready = False
        
        return {
            "error": str(e),
            "elapsed_time": elapsed
        }

def warmup_for_user(user_id):
    """Прогрев браузера для пользователя"""
    return {"success": initialize_warmed_browser(), "mode": "warmed_ultra_fast"}

def is_browser_ready():
    """Проверка готовности браузера"""
    return browser_manager.is_ready

def get_pool_status():
    """Получить статус браузера"""
    return {
        "mode": "warmed_ultra_fast", 
        "ready": browser_manager.is_ready,
        "last_auth_check": _last_auth_check,
        "auth_valid": time.time() - _last_auth_check < _auth_check_interval
    }

def close_browser():
    """Закрытие браузера"""
    browser_manager.close()