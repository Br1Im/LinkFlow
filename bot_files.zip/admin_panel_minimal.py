#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Минимальная админ-панель для тестирования
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import logging

# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app, origins="*", methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"], 
     allow_headers=["Content-Type", "Authorization"])

@app.route('/')
def index():
    """Главная страница"""
    logger.info("🏠 GET запрос к главной странице")
    return "<h1>Минимальная админ-панель работает!</h1>"

@app.route('/api/create-payment', methods=['POST'])
def create_payment_endpoint():
    """API для создания платежной ссылки"""
    logger.info("🔥 POST запрос получен на /api/create-payment")
    try:
        logger.info("📥 Парсинг JSON данных...")
        data = request.get_json()
        logger.info(f"📊 Получены данные: {data}")
        
        amount = int(data['amount'])
        description = data['description']
        
        logger.info(f"💰 Создание платежа: {amount} сум - {description}")
        
        # Возвращаем тестовый ответ
        logger.info("🧪 ТЕСТОВЫЙ РЕЖИМ: Возвращаю фиктивный результат")
        return jsonify({
            "success": True,
            "payment_id": "test-123",
            "payment_link": "https://test.link",
            "message": "Тестовый платеж создан",
            "elapsed_time": 1.0
        })
        
    except Exception as e:
        logger.error(f"❌ Ошибка создания платежа: {e}")
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

@app.route('/api/health')
def health_check():
    """Проверка здоровья системы"""
    logger.info("🏥 GET запрос к /api/health")
    return jsonify({
        "status": "healthy",
        "message": "Минимальная система работает"
    })

if __name__ == '__main__':
    logger.info("🚀 Запуск минимальной админ-панели на http://0.0.0.0:5000")
    app.run(host='0.0.0.0', port=5000, debug=False)