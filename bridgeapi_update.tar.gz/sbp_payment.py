# sbp_payment.py - SBP payment integration for 1payment.com
import requests
import hashlib
import json
from typing import Dict, Optional, Any
import config


class SBPPaymentService:
    """Service for handling SBP payments through 1payment.com API"""
    
    def __init__(self):
        self.api_url = "https://api.1payment.com"
        self.project_id = config.SBP_SHOP_ID  # project_id из конфига
        self.api_key = config.SBP_SECRET_KEY  # API Key из конфига
        self.partner_id = "11656"  # partner_id из документации
        self.shop_url = config.SBP_SHOP_URL
    
    def create_payment_form(
        self, 
        amount: float, 
        user_id: int, 
        description: str = "Пополнение баланса",
        order_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Create payment form using 1payment.com API
        
        Args:
            amount: Payment amount in rubles
            user_id: Telegram user ID (required for security)
            description: Payment description
            order_id: Optional order ID (will be used as user_data)
            
        Returns:
            Dict with payment form URL and payment data
        """
        if not order_id:
            order_id = f"order_{user_id}_{int(amount * 100)}"
        
        # Prepare payment data according to 1payment.com API documentation
        payment_data = {
            "partner_id": self.partner_id,
            "project_id": self.project_id,
            "amount": int(amount),  # Amount as integer
            "description": description,
            "user_id": str(user_id),  # Required parameter for security
            "shop_url": self.shop_url,
            "user_data": order_id,  # Unique identifier for payment
            "success_url": f"{self.shop_url}/success",
            "failure_url": f"{self.shop_url}/failure"
        }
        
        # Generate signature according to documentation
        signature = self._generate_signature_init_form(payment_data)
        payment_data["sign"] = signature
        
        try:
            # Build URL with parameters
            params = "&".join([f"{k}={v}" for k, v in payment_data.items()])
            url = f"{self.api_url}/init_form?{params}"
            
            print(f"🌐 Request URL: {url}")
            
            response = requests.get(url, timeout=30)
            
            print(f"🌐 API Response Status: {response.status_code}")
            print(f"📥 API Response Text: {response.text}")
            
            if response.status_code == 200:
                result = response.json()
                
                # Check for error_code in response
                if "error_code" in result and result["error_code"] != 0:
                    error_messages = {
                        1: "Неверные параметры запроса",
                        2: "Неверная подпись",
                        3: "Платеж не найден",
                        4: "Недостаточно средств",
                        5: "Платеж уже обработан"
                    }
                    error_msg = error_messages.get(result["error_code"], f"Неизвестная ошибка (код: {result['error_code']})")
                    
                    return {
                        "success": False,
                        "error": "API Error",
                        "details": error_msg,
                        "error_code": result["error_code"],
                        "raw_response": result
                    }
                
                # Success response should contain URL
                payment_url = result.get("url")
                if not payment_url:
                    return {
                        "success": False,
                        "error": "Invalid response",
                        "details": "No payment URL in response",
                        "raw_response": result
                    }
                
                return {
                    "success": True,
                    "payment_url": payment_url,
                    "payment_id": order_id,  # Use order_id as payment_id
                    "order_id": order_id,
                    "amount": amount,
                    "raw_response": result
                }
            else:
                return {
                    "success": False,
                    "error": f"HTTP Error: {response.status_code}",
                    "details": response.text
                }
                
        except requests.RequestException as e:
            return {
                "success": False,
                "error": "Network error",
                "details": str(e)
            }
    
    def check_payment_status(self, payment_id: str) -> Dict[str, Any]:
        """
        Check payment status using 1payment.com API
        
        Args:
            payment_id: Payment ID from create_payment_form (user_data)
            
        Returns:
            Dict with payment status information
        """
        try:
            # Prepare status check data according to documentation
            status_data = {
                "partner_id": self.partner_id,
                "project_id": self.project_id,
                "user_data": payment_id  # Use user_data instead of order_id
            }
            
            # Generate signature for status check
            signature = self._generate_signature_status_payment(status_data)
            status_data["sign"] = signature
            
            # Build URL with parameters
            params = "&".join([f"{k}={v}" for k, v in status_data.items()])
            url = f"{self.api_url}/status_payment?{params}"
            
            print(f"🔍 Status check URL: {url}")
            
            response = requests.get(url, timeout=30)
            
            print(f"🔍 Status Response: {response.status_code} - {response.text}")
            
            if response.status_code == 200:
                result = response.json()
                
                # Check for error_code in response
                if "error_code" in result and result["error_code"] != 0:
                    return {
                        "success": False,
                        "error": f"API Error (код: {result['error_code']})",
                        "error_code": result["error_code"],
                        "raw_response": result
                    }
                
                # Map 1payment.com statuses to our format
                status = result.get("status")
                status_map = {
                    2: "pending",      # ожидание подтверждения платежа
                    3: "completed",    # успешная оплата
                    4: "failed"        # отказ в платеже
                }
                
                mapped_status = status_map.get(status, "unknown")
                
                return {
                    "success": True,
                    "status": mapped_status,
                    "original_status": status,
                    "status_description": result.get("status_description"),
                    "raw_response": result
                }
            else:
                return {
                    "success": False,
                    "error": f"HTTP Error: {response.status_code}",
                    "details": response.text
                }
                
        except requests.RequestException as e:
            return {
                "success": False,
                "error": "Network error",
                "details": str(e)
            }
    
    def _generate_signature_init_form(self, data: Dict[str, Any]) -> str:
        """
        Generate signature for init_form according to 1payment.com documentation
        
        Format: md5("init_form" + concatenated_params_in_alphabetical_order + API_Key)
        
        Args:
            data: Payment data dictionary
            
        Returns:
            Generated signature string
        """
        # Sort parameters by key alphabetically (excluding sign)
        sorted_params = sorted([(k, v) for k, v in data.items() if k != "sign"])
        
        # Create string for signing: init_form + params + API_Key
        sign_string = "init_form"
        
        for key, value in sorted_params:
            sign_string += f"{key}={value}&"
        
        # Remove last & and add API key
        sign_string = sign_string.rstrip("&")
        sign_string += self.api_key
        
        print(f"🔐 Sign string for init_form: {sign_string}")
        
        # Generate MD5 hash
        signature = hashlib.md5(sign_string.encode('utf-8')).hexdigest()
        
        print(f"🔐 Generated signature: {signature}")
        
        return signature
    
    def _generate_signature_status_payment(self, data: Dict[str, Any]) -> str:
        """
        Generate signature for status_payment according to 1payment.com documentation
        
        Format: md5("status_payment" + concatenated_params_in_alphabetical_order + API_Key)
        
        Args:
            data: Status check data dictionary
            
        Returns:
            Generated signature string
        """
        # Sort parameters by key alphabetically (excluding sign)
        sorted_params = sorted([(k, v) for k, v in data.items() if k != "sign"])
        
        # Create string for signing: status_payment + params + API_Key
        sign_string = "status_payment"
        
        for key, value in sorted_params:
            sign_string += f"{key}={value}&"
        
        # Remove last & and add API key
        sign_string = sign_string.rstrip("&")
        sign_string += self.api_key
        
        print(f"🔐 Sign string for status_payment: {sign_string}")
        
        # Generate MD5 hash
        signature = hashlib.md5(sign_string.encode('utf-8')).hexdigest()
        
        print(f"🔐 Generated signature: {signature}")
        
        return signature
    
    def format_payment_amount(self, amount: float) -> str:
        """Format amount for display"""
        return f"{amount:.2f} ₽"
    
    def validate_amount(self, amount: float) -> bool:
        """Validate payment amount"""
        return 1.0 <= amount <= 100000.0  # Min 1 ruble, max 100k rubles