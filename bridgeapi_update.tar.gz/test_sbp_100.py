#!/usr/bin/env python3
# test_sbp_100.py - Test SBP payment for 100 rubles

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from sbp_payment import SBPPaymentService
import json

def test_sbp_payment():
    """Test SBP payment creation for 100 rubles"""
    
    print("🧪 Testing SBP Payment Service")
    print("=" * 50)
    
    # Initialize payment service
    payment_service = SBPPaymentService()
    
    # Test payment data
    test_user_id = 123456789  # Test Telegram user ID
    test_amount = 100.0  # 100 rubles
    test_description = "Тестовый платеж СБП на 100 рублей"
    
    print(f"💰 Amount: {test_amount} ₽")
    print(f"👤 User ID: {test_user_id}")
    print(f"📝 Description: {test_description}")
    print()
    
    # Create payment form
    print("🚀 Creating payment form...")
    try:
        # Let's also check the raw request data
        import requests
        import hashlib
        
        # Prepare payment data (same as in SBPPaymentService)
        payment_data = {
            "shop_id": payment_service.shop_id,
            "amount": test_amount,
            "currency": "RUB",
            "order_id": f"order_{test_user_id}_{int(test_amount * 100)}",
            "description": test_description,
            "user_id": str(test_user_id),
            "shop_url": payment_service.shop_url,
            "payment_method": "sbp",
            "success_url": f"{payment_service.shop_url}/success",
            "fail_url": f"{payment_service.shop_url}/fail",
            "callback_url": f"{payment_service.shop_url}/callback"
        }
        
        print("📤 Request Data:")
        print(json.dumps(payment_data, indent=2, ensure_ascii=False))
        print()
        
        result = payment_service.create_payment_form(
            amount=test_amount,
            user_id=test_user_id,
            description=test_description
        )
        
        print("📋 Payment Result:")
        print(json.dumps(result, indent=2, ensure_ascii=False))
        
        if result.get("success"):
            print("\n✅ Payment form created successfully!")
            print(f"🔗 Payment URL: {result.get('payment_url')}")
            print(f"🆔 Payment ID: {result.get('payment_id')}")
        else:
            print("\n❌ Payment creation failed!")
            print(f"Error: {result.get('error')}")
            print(f"Details: {result.get('details')}")
            
    except Exception as e:
        print(f"❌ Exception occurred: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_sbp_payment()