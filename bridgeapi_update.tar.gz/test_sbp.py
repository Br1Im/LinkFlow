#!/usr/bin/env python3
# test_sbp.py - Test script for SBP payment integration

import asyncio
import os
from sbp_payment import SBPPaymentService
from db import init_db, create_payment, get_payment_by_id
import config

async def test_sbp_integration():
    """Test SBP payment integration"""
    
    print("🧪 Testing SBP Payment Integration")
    print("=" * 50)
    
    # Initialize database
    print("📊 Initializing database...")
    await init_db()
    print("✅ Database initialized")
    
    # Check configuration
    print("\n🔧 Checking configuration...")
    print(f"Shop ID: {config.SBP_SHOP_ID}")
    print(f"Shop URL: {config.SBP_SHOP_URL}")
    
    if not config.SBP_SECRET_KEY:
        print("❌ SBP_SECRET_KEY not configured!")
        print("Please set SBP_SECRET_KEY in your .env file")
        return
    else:
        print("✅ Secret key configured")
    
    # Test payment service
    print("\n💳 Testing payment service...")
    payment_service = SBPPaymentService()
    
    # Test amount validation
    print("Testing amount validation...")
    assert payment_service.validate_amount(100) == True
    assert payment_service.validate_amount(50) == False
    assert payment_service.validate_amount(100001) == False
    print("✅ Amount validation works")
    
    # Test signature generation (with dummy data)
    print("Testing signature generation...")
    test_data = {
        "shop_id": "802685",
        "amount": "100.00",
        "user_id": "123456789"
    }
    signature = payment_service._generate_signature(test_data)
    print(f"✅ Signature generated: {signature[:10]}...")
    
    # Test payment creation (if secret key is configured)
    if config.SBP_SECRET_KEY and config.SBP_SECRET_KEY != "":
        print("\n🚀 Testing payment creation...")
        try:
            result = payment_service.create_payment_form(
                amount=100.0,
                user_id=123456789,
                description="Test payment"
            )
            
            if result["success"]:
                print("✅ Payment form created successfully!")
                print(f"Payment ID: {result['payment_id']}")
                print(f"Payment URL: {result['payment_url']}")
                
                # Test database storage
                await create_payment(
                    user_id=123456789,
                    payment_id=result["payment_id"],
                    amount=10000  # 100 rubles in kopecks
                )
                
                # Test database retrieval
                payment = await get_payment_by_id(result["payment_id"])
                if payment:
                    print("✅ Payment stored and retrieved from database")
                else:
                    print("❌ Failed to retrieve payment from database")
                    
            else:
                print(f"❌ Payment creation failed: {result.get('error')}")
                
        except Exception as e:
            print(f"❌ Error testing payment creation: {e}")
    else:
        print("⚠️ Skipping payment creation test (no secret key)")
    
    print("\n🎉 SBP integration test completed!")
    print("\nNext steps:")
    print("1. Configure SBP_SECRET_KEY in .env file")
    print("2. Test with real payment amounts")
    print("3. Set up webhook handler for automatic status updates")
    print("4. Contact 1payment.com to configure callback URL")

if __name__ == "__main__":
    asyncio.run(test_sbp_integration())