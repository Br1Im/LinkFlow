# ai_handlers.py - Обработчики AI-инструментов для BridgeAPI_Bot
from aiogram import types, F
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.context import FSMContext
from aiogram.enums import ParseMode
import io
import asyncio
import logging

from ai_service import AIService
from db import get_balance, update_balance
from keyboards import back_button

# FSM состояния для AI-инструментов
class AIToolsFSM(StatesGroup):
    waiting_post_topic = State()
    waiting_channel_theme = State()
    waiting_prompt_task = State()
    waiting_prompt_context = State()
    waiting_water_weight = State()
    waiting_bju_data = State()
    waiting_image_prompt = State()
    waiting_video_prompt = State()
    waiting_tts_text = State()
    waiting_tts_voice = State()
    waiting_animate_photo = State()
    waiting_animate_prompt = State()

def setup_ai_handlers(dp, bot):
    """Регистрация обработчиков AI-инструментов"""
    
    ai_service = AIService()
    
    # ============ Генератор постов ============
    @dp.callback_query(F.data == "generate_post")
    async def generate_post_start(callback: types.CallbackQuery, state: FSMContext):
        text = (
            "📝 <b>Генератор постов для Telegram</b>\n\n"
            "Введите тему для поста:\n\n"
            "💡 <i>Например: \"Польза медитации\", \"Крипто-тренды 2026\", \"Здоровое питание\"</i>\n\n"
            "💰 Стоимость: 5₽"
        )
        
        await callback.message.edit_text(
            text,
            reply_markup=back_button(),
            parse_mode=ParseMode.HTML
        )
        await state.set_state(AIToolsFSM.waiting_post_topic)
        await callback.answer()
    
    @dp.message(AIToolsFSM.waiting_post_topic)
    async def generate_post_process(message: types.Message, state: FSMContext):
        topic = message.text.strip()
        
        if len(topic) < 3:
            await message.answer("⚠️ Тема слишком короткая. Введите более подробную тему:")
            return
        
        await handle_ai_tool_payment(
            message, "Генератор постов", 5,
            lambda: ai_service.generate_post(topic)
        )
        await state.clear()
    
    # ============ Генератор названий ============
    @dp.callback_query(F.data == "generate_names")
    async def generate_names_start(callback: types.CallbackQuery, state: FSMContext):
        text = (
            "💡 <b>Генератор названий каналов</b>\n\n"
            "Введите тематику канала:\n\n"
            "💡 <i>Например: \"Фитнес и здоровье\", \"Криптовалюты\", \"Программирование\"</i>\n\n"
            "💰 Стоимость: 10₽"
        )
        
        await callback.message.edit_text(
            text,
            reply_markup=back_button(),
            parse_mode=ParseMode.HTML
        )
        await state.set_state(AIToolsFSM.waiting_channel_theme)
        await callback.answer()
    
    @dp.message(AIToolsFSM.waiting_channel_theme)
    async def generate_names_process(message: types.Message, state: FSMContext):
        theme = message.text.strip()
        
        if len(theme) < 3:
            await message.answer("⚠️ Тематика слишком короткая. Опишите тему подробнее:")
            return
        
        await handle_ai_tool_payment(
            message, "Генератор названий", 10,
            lambda: ai_service.generate_channel_names(theme)
        )
        await state.clear()
    
    # ============ Персональный промпт ============
    @dp.callback_query(F.data == "generate_prompt")
    async def generate_prompt_start(callback: types.CallbackQuery, state: FSMContext):
        text = (
            "🎯 <b>Генератор персональных промптов</b>\n\n"
            "Опишите задачу для которой нужен промпт:\n\n"
            "💡 <i>Например: \"Написать продающий текст\", \"Анализ конкурентов\", \"Создать план обучения\"</i>\n\n"
            "💰 Стоимость: 15₽"
        )
        
        await callback.message.edit_text(
            text,
            reply_markup=back_button(),
            parse_mode=ParseMode.HTML
        )
        await state.set_state(AIToolsFSM.waiting_prompt_task)
        await callback.answer()
    
    @dp.message(AIToolsFSM.waiting_prompt_task)
    async def generate_prompt_task(message: types.Message, state: FSMContext):
        task = message.text.strip()
        
        if len(task) < 5:
            await message.answer("⚠️ Описание задачи слишком короткое. Опишите подробнее:")
            return
        
        await state.update_data(task=task)
        
        await message.answer(
            "📝 <b>Дополнительный контекст</b>\n\n"
            "Добавьте дополнительную информацию о задаче (необязательно):\n\n"
            "💡 <i>Например: \"Для IT-компании\", \"Целевая аудитория - подростки\", \"Бюджет ограничен\"</i>\n\n"
            "Или отправьте \"-\" чтобы пропустить этот шаг."
        )
        await state.set_state(AIToolsFSM.waiting_prompt_context)
    
    @dp.message(AIToolsFSM.waiting_prompt_context)
    async def generate_prompt_process(message: types.Message, state: FSMContext):
        context = message.text.strip()
        if context == "-":
            context = ""
        
        data = await state.get_data()
        task = data.get("task", "")
        
        await handle_ai_tool_payment(
            message, "Персональный промпт", 15,
            lambda: ai_service.generate_personal_prompt(task, context)
        )
        await state.clear()
    
    # ============ Калькулятор воды ============
    @dp.callback_query(F.data == "water_calculator")
    async def water_calculator_start(callback: types.CallbackQuery, state: FSMContext):
        text = (
            "💧 <b>Калькулятор нормы воды</b>\n\n"
            "Введите ваш вес в килограммах:\n\n"
            "💡 <i>Например: 70</i>\n\n"
            "💰 Стоимость: 10₽"
        )
        
        await callback.message.edit_text(
            text,
            reply_markup=back_button(),
            parse_mode=ParseMode.HTML
        )
        await state.set_state(AIToolsFSM.waiting_water_weight)
        await callback.answer()
    
    @dp.message(AIToolsFSM.waiting_water_weight)
    async def water_calculator_process(message: types.Message, state: FSMContext):
        try:
            weight = float(message.text.strip())
            
            if not (30 <= weight <= 200):
                await message.answer("⚠️ Введите корректный вес (30-200 кг):")
                return
            
            # Это простая функция, не требует AI API
            result = ai_service.calculate_water_intake(weight)
            
            if result.get("success"):
                text = (
                    f"💧 <b>Расчет нормы воды</b>\n\n"
                    f"👤 Вес: {weight} кг\n"
                    f"💧 Норма воды: {result['daily_water_liters']} л/день\n"
                    f"🥤 Это примерно {result['glasses_200ml']} стаканов по 200мл\n\n"
                    f"📋 {result['recommendation']}\n\n"
                    f"💡 <i>Увеличьте количество при активных тренировках или жаркой погоде</i>\n\n"
                    f"💰 Списано: 10₽"
                )
                
                keyboard = types.InlineKeyboardMarkup(inline_keyboard=[
                    [types.InlineKeyboardButton(text="🤖 Другие AI-инструменты", callback_data="ai_tools")],
                    [types.InlineKeyboardButton(text="⬅️ В главное меню", callback_data="back_to_main")]
                ])
                
                # Проверяем баланс и списываем
                user_id = message.from_user.id
                
                # Проверяем админские права
                import config
                is_admin = user_id in config.ADMIN_IDS
                
                balance = await get_balance(user_id)
                
                if not is_admin and balance < 10:
                    await message.answer(
                        f"❌ <b>Недостаточно средств</b>\n\n"
                        f"Стоимость: 10₽\n"
                        f"Ваш баланс: {balance}₽\n\n"
                        f"Пополните баланс для использования этой функции.",
                        reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[
                            [types.InlineKeyboardButton(text="💳 Пополнить баланс", callback_data="topup_balance")],
                            [types.InlineKeyboardButton(text="⬅️ Назад", callback_data="ai_tools")]
                        ]),
                        parse_mode=ParseMode.HTML
                    )
                else:
                    # Списываем средства только если не админ
                    if not is_admin:
                        await update_balance(user_id, -10)
                    
                    text = (
                        f"💧 <b>Расчет нормы воды</b>\n\n"
                        f"👤 Вес: {weight} кг\n"
                        f"💧 Норма воды: {result['daily_water_liters']} л/день\n"
                        f"🥤 Это примерно {result['glasses_200ml']} стаканов по 200мл\n\n"
                        f"📋 {result['recommendation']}\n\n"
                        f"💡 <i>Увеличьте количество при активных тренировках или жаркой погоде</i>\n\n"
                        f"{'👑 Админ-тест (бесплатно)' if is_admin else '💰 Списано: 10₽'}"
                    )
                    
                    keyboard = types.InlineKeyboardMarkup(inline_keyboard=[
                        [types.InlineKeyboardButton(text="🤖 Другие AI-инструменты", callback_data="ai_tools")],
                        [types.InlineKeyboardButton(text="⬅️ В главное меню", callback_data="back_to_main")]
                    ])
                    
                    await message.answer(text, reply_markup=keyboard, parse_mode=ParseMode.HTML)
            else:
                await message.answer(
                    f"❌ Ошибка расчета: {result.get('error')}",
                    reply_markup=back_button()
                )
                
        except ValueError:
            await message.answer("⚠️ Введите корректное число (например: 70):")
        
        await state.clear()
    
    # ============ Расчет БЖУ ============
    @dp.callback_query(F.data == "bju_calculator")
    async def bju_calculator_start(callback: types.CallbackQuery, state: FSMContext):
        text = (
            "🍽 <b>Расчет БЖУ (белки, жиры, углеводы)</b>\n\n"
            "Введите данные в формате:\n"
            "<code>вес рост возраст пол активность цель</code>\n\n"
            "💡 <b>Пример:</b>\n"
            "<code>70 175 25 м умеренная поддержание</code>\n\n"
            "📋 <b>Параметры:</b>\n"
            "• Пол: м/ж\n"
            "• Активность: низкая/легкая/умеренная/высокая\n"
            "• Цель: похудение/поддержание/набор\n\n"
            "💰 Стоимость: 10₽"
        )
        
        await callback.message.edit_text(
            text,
            reply_markup=back_button(),
            parse_mode=ParseMode.HTML
        )
        await state.set_state(AIToolsFSM.waiting_bju_data)
        await callback.answer()
    
    @dp.message(AIToolsFSM.waiting_bju_data)
    async def bju_calculator_process(message: types.Message, state: FSMContext):
        try:
            parts = message.text.strip().split()
            
            if len(parts) != 6:
                await message.answer(
                    "⚠️ Неверный формат. Используйте:\n"
                    "<code>вес рост возраст пол активность цель</code>\n\n"
                    "Пример: <code>70 175 25 м умеренная поддержание</code>",
                    parse_mode=ParseMode.HTML
                )
                return
            
            weight = float(parts[0])
            height = float(parts[1])
            age = int(parts[2])
            gender = parts[3].lower()
            activity = parts[4].lower()
            goal_map = {
                "похудение": "lose",
                "поддержание": "maintain", 
                "набор": "gain"
            }
            goal = goal_map.get(parts[5].lower(), "maintain")
            
            # Валидация
            if not (30 <= weight <= 200):
                await message.answer("⚠️ Вес должен быть от 30 до 200 кг")
                return
            if not (100 <= height <= 250):
                await message.answer("⚠️ Рост должен быть от 100 до 250 см")
                return
            if not (10 <= age <= 100):
                await message.answer("⚠️ Возраст должен быть от 10 до 100 лет")
                return
            
            # Расчет БЖУ
            result = ai_service.calculate_bju(weight, height, age, gender, activity, goal)
            
            if result.get("success"):
                text = (
                    f"🍽 <b>Расчет БЖУ</b>\n\n"
                    f"👤 Данные: {weight}кг, {height}см, {age} лет\n"
                    f"🎯 Цель: {goal_names.get(goal, 'Поддержание')}\n\n"
                    f"📊 <b>Суточная норма:</b>\n"
                    f"🔥 Калории: {result['daily_calories']} ккал\n"
                    f"🥩 Белки: {result['proteins_g']} г\n"
                    f"🥑 Жиры: {result['fats_g']} г\n"
                    f"🍞 Углеводы: {result['carbs_g']} г\n\n"
                    f"⚡ Базовый метаболизм: {result['bmr']} ккал\n\n"
                    f"{'👑 Админ-тест (бесплатно)' if is_admin else '💰 Списано: 10₽'}"
                )
                
                keyboard = types.InlineKeyboardMarkup(inline_keyboard=[
                    [types.InlineKeyboardButton(text="🤖 Другие AI-инструменты", callback_data="ai_tools")],
                    [types.InlineKeyboardButton(text="⬅️ В главное меню", callback_data="back_to_main")]
                ])
                
                # Проверяем баланс и списываем
                user_id = message.from_user.id
                
                # Проверяем админские права
                import config
                is_admin = user_id in config.ADMIN_IDS
                
                balance = await get_balance(user_id)
                
                if not is_admin and balance < 10:
                    await message.answer(
                        f"❌ <b>Недостаточно средств</b>\n\n"
                        f"Стоимость: 10₽\n"
                        f"Ваш баланс: {balance}₽",
                        reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[
                            [types.InlineKeyboardButton(text="💳 Пополнить баланс", callback_data="topup_balance")]
                        ]),
                        parse_mode=ParseMode.HTML
                    )
                else:
                    # Списываем средства только если не админ
                    if not is_admin:
                        await update_balance(user_id, -10)
                    
                    await message.answer(text, reply_markup=keyboard, parse_mode=ParseMode.HTML)
            else:
                await message.answer(f"❌ Ошибка расчета: {result.get('error')}")
                
        except (ValueError, IndexError):
            await message.answer(
                "⚠️ Ошибка в данных. Проверьте формат:\n"
                "<code>70 175 25 м умеренная поддержание</code>",
                parse_mode=ParseMode.HTML
            )
        
        await state.clear()
    
    # ============ Крипто-инструменты ============
    @dp.callback_query(F.data == "crypto_top3")
    async def crypto_top3(callback: types.CallbackQuery):
        await handle_ai_tool_payment(
            callback, "Топ-3 криптовалют", 5,
            lambda: ai_service.get_crypto_top3()
        )
    
    @dp.callback_query(F.data == "crypto_exchanges")
    async def crypto_exchanges(callback: types.CallbackQuery):
        await handle_ai_tool_payment(
            callback, "Надежные биржи", 5,
            lambda: ai_service.get_reliable_exchanges()
        )
    
    @dp.callback_query(F.data == "crypto_horoscope")
    async def crypto_horoscope(callback: types.CallbackQuery):
        # Получаем знак зодиака пользователя
        from handlers import get_zodiac_sign
        from db import get_birthdate
        
        user_id = callback.from_user.id
        birthdate = await get_birthdate(user_id)
        
        if not birthdate:
            await callback.message.edit_text(
                "📅 <b>Сначала укажите дату рождения</b>\n\n"
                "Для крипто-гороскопа нужно знать ваш знак зодиака.\n"
                "Перейдите в раздел \"Гороскоп\" и укажите дату рождения.",
                reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[
                    [types.InlineKeyboardButton(text="🔮 Указать дату рождения", callback_data="horoscope")],
                    [types.InlineKeyboardButton(text="⬅️ Назад", callback_data="ai_tools")]
                ]),
                parse_mode=ParseMode.HTML
            )
            await callback.answer()
            return
        
        # Определяем знак зодиака
        day, month, year = map(int, birthdate.split("."))
        zodiac = get_zodiac_sign(day, month)
        
        await handle_ai_tool_payment(
            callback, "Крипто-гороскоп", 10,
            lambda: ai_service.generate_crypto_horoscope(zodiac)
        )
    
    # ============ AI Генерация изображений ============
    @dp.callback_query(F.data == "ai_generate_image")
    async def ai_generate_image_start(callback: types.CallbackQuery, state: FSMContext):
        text = (
            "🖼 <b>AI Генерация изображений</b>\n\n"
            "Опишите изображение, которое хотите создать:\n\n"
            "💡 <b>Примеры:</b>\n"
            "• Футуристический город на закате\n"
            "• Кот-космонавт в скафандре\n"
            "• Абстрактная картина в стиле Пикассо\n\n"
            "💰 Стоимость: 120₽"
        )
        
        await callback.message.edit_text(
            text,
            reply_markup=back_button(),
            parse_mode=ParseMode.HTML
        )
        await state.set_state(AIToolsFSM.waiting_image_prompt)
        await callback.answer()
    
    @dp.message(AIToolsFSM.waiting_image_prompt)
    async def ai_generate_image_process(message: types.Message, state: FSMContext):
        prompt = message.text.strip()
        
        if len(prompt) < 5:
            await message.answer("⚠️ Описание слишком короткое. Опишите изображение подробнее:")
            return
        
        user_id = message.from_user.id
        
        # Проверяем админские права
        import config
        is_admin = user_id in config.ADMIN_IDS
        
        balance = await get_balance(user_id)
        
        if not is_admin and balance < 120:
            await message.answer(
                f"❌ <b>Недостаточно средств</b>\n\n"
                f"Стоимость: 120₽\n"
                f"Ваш баланс: {balance}₽",
                reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[
                    [types.InlineKeyboardButton(text="💳 Пополнить баланс", callback_data="topup_balance")]
                ]),
                parse_mode=ParseMode.HTML
            )
            await state.clear()
            return
        
        # Списываем средства только если не админ
        if not is_admin:
            await update_balance(user_id, -120)
        
        # Показываем процесс
        processing_msg = await message.answer(
            f"🎨 <b>Генерация изображения...</b>\n\n"
            f"Описание: {prompt}\n"
            f"{'👑 Админ-тест (бесплатно)' if is_admin else f'Списано: 120₽'}\n\n"
            f"⏳ Это может занять до 60 секунд...",
            parse_mode=ParseMode.HTML
        )
        
        try:
            # Генерируем изображение
            result = await ai_service.generate_image(prompt)
            
            if result.get("success"):
                if result.get("format") == "base64":
                    # Конвертируем base64 в файл
                    import base64
                    image_data = base64.b64decode(result["image_base64"])
                    
                    # Отправляем изображение
                    photo = types.BufferedInputFile(image_data, filename="generated_image.png")
                    
                    await bot.send_photo(
                        chat_id=message.chat.id,
                        photo=photo,
                        caption=f"🎨 <b>Сгенерированное изображение</b>\n\n📝 Описание: {prompt}\n{'👑 Админ-тест (бесплатно)' if is_admin else '💰 Стоимость: 120₽'}",
                        parse_mode=ParseMode.HTML,
                        reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[
                            [types.InlineKeyboardButton(text="🎨 Создать еще", callback_data="ai_generate_image")],
                            [types.InlineKeyboardButton(text="⬅️ В главное меню", callback_data="back_to_main")]
                        ])
                    )
                    
                    await processing_msg.delete()
                    
                elif result.get("format") == "url":
                    await processing_msg.edit_text(
                        f"🎨 <b>Изображение готово!</b>\n\n"
                        f"📝 Описание: {prompt}\n"
                        f"🔗 Ссылка: {result['image_url']}\n\n"
                        f"{'👑 Админ-тест (бесплатно)' if is_admin else '💰 Списано: 120₽'}",
                        reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[
                            [types.InlineKeyboardButton(text="🎨 Создать еще", callback_data="ai_generate_image")],
                            [types.InlineKeyboardButton(text="⬅️ В главное меню", callback_data="back_to_main")]
                        ]),
                        parse_mode=ParseMode.HTML
                    )
            else:
                # Возвращаем деньги при ошибке (только если не админ)
                if not is_admin:
                    await update_balance(user_id, 120)
                
                await processing_msg.edit_text(
                    f"❌ <b>Ошибка генерации</b>\n\n"
                    f"Не удалось создать изображение: {result.get('error', 'Неизвестная ошибка')}\n\n"
                    f"{'👑 Админ-тест (ошибка)' if is_admin else '💰 Средства возвращены на баланс'}",
                    reply_markup=back_button(),
                    parse_mode=ParseMode.HTML
                )
                
        except Exception as e:
            # Возвращаем деньги при исключении (только если не админ)
            if not is_admin:
                await update_balance(user_id, 120)
            
            await processing_msg.edit_text(
                f"❌ <b>Техническая ошибка</b>\n\n"
                f"Произошла ошибка при генерации изображения.\n\n"
                f"{'👑 Админ-тест (ошибка)' if is_admin else '💰 Средства возвращены на баланс'}",
                reply_markup=back_button(),
                parse_mode=ParseMode.HTML
            )
        
        await state.clear()
    
    # ============ AI Генерация видео ============
    @dp.callback_query(F.data == "ai_generate_video")
    async def ai_generate_video_start(callback: types.CallbackQuery, state: FSMContext):
        text = (
            "🎬 <b>AI Генерация видео</b>\n\n"
            "Опишите видео, которое хотите создать:\n\n"
            "💡 <b>Примеры:</b>\n"
            "• Волны океана на закате\n"
            "• Полет через облака\n"
            "• Танцующие огни северного сияния\n"
            "• Кот играет с мячиком\n\n"
            "⏱ Длительность: 5 секунд\n"
            "📐 Разрешение: 1280x720 (HD)\n"
            "💰 Стоимость: 150₽"
        )
        
        await callback.message.edit_text(
            text,
            reply_markup=back_button(),
            parse_mode=ParseMode.HTML
        )
        await state.set_state(AIToolsFSM.waiting_video_prompt)
        await callback.answer()
    
    @dp.message(AIToolsFSM.waiting_video_prompt)
    async def ai_generate_video_process(message: types.Message, state: FSMContext):
        prompt = message.text.strip()
        
        if len(prompt) < 5:
            await message.answer("⚠️ Описание слишком короткое. Опишите видео подробнее:")
            return
        
        user_id = message.from_user.id
        
        # Проверяем админские права
        import config
        is_admin = user_id in config.ADMIN_IDS
        
        balance = await get_balance(user_id)
        
        if not is_admin and balance < 150:
            await message.answer(
                f"❌ <b>Недостаточно средств</b>\n\n"
                f"Стоимость: 150₽\n"
                f"Ваш баланс: {balance}₽",
                reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[
                    [types.InlineKeyboardButton(text="💳 Пополнить баланс", callback_data="topup_balance")]
                ]),
                parse_mode=ParseMode.HTML
            )
            await state.clear()
            return
        
        # Списываем средства только если не админ
        if not is_admin:
            await update_balance(user_id, -150)
        
        # Показываем процесс
        processing_msg = await message.answer(
            f"🎬 <b>Генерация видео...</b>\n\n"
            f"Описание: {prompt}\n"
            f"{'👑 Админ-тест (бесплатно)' if is_admin else f'Списано: 150₽'}\n\n"
            f"⏳ Это может занять 2-5 минут...",
            parse_mode=ParseMode.HTML
        )
        
        try:
            # Создаем задание на генерацию видео
            result = await ai_service.generate_video(prompt)
            
            if result.get("success"):
                video_id = result.get("video_id")
                
                await processing_msg.edit_text(
                    f"🎬 <b>Видео генерируется...</b>\n\n"
                    f"📝 Описание: {prompt}\n"
                    f"🆔 ID задания: {video_id}\n\n"
                    f"⏳ Ожидайте, это займет несколько минут...\n"
                    f"🔄 Проверяем статус каждые 30 секунд",
                    parse_mode=ParseMode.HTML
                )
                
                # Сохраняем video_id для проверки статуса
                await state.update_data(video_id=video_id, prompt=prompt, user_id=user_id)
                
                # Запускаем проверку статуса через 30 секунд
                asyncio.create_task(check_video_status_loop(bot, message.chat.id, video_id, prompt, processing_msg.message_id))
                
            else:
                # Возвращаем деньги при ошибке (только если не админ)
                if not is_admin:
                    await update_balance(user_id, 150)
                
                await processing_msg.edit_text(
                    f"❌ <b>Ошибка создания видео</b>\n\n"
                    f"Не удалось запустить генерацию: {result.get('error', 'Неизвестная ошибка')}\n\n"
                    f"{'👑 Админ-тест (ошибка)' if is_admin else '💰 Средства возвращены на баланс'}",
                    reply_markup=back_button(),
                    parse_mode=ParseMode.HTML
                )
                
        except Exception as e:
            # Логируем ошибку
            logging.error(f"Ошибка генерации видео: {str(e)}", exc_info=True)
            
            # Возвращаем деньги при исключении (только если не админ)
            if not is_admin:
                await update_balance(user_id, 150)
            
            await processing_msg.edit_text(
                f"❌ <b>Техническая ошибка</b>\n\n"
                f"Произошла ошибка при создании видео.\n\n"
                f"{'👑 Админ-тест (ошибка)' if is_admin else '💰 Средства возвращены на баланс'}",
                reply_markup=back_button(),
                parse_mode=ParseMode.HTML
            )
        
        await state.clear()
    
    # ============ AI Синтез речи ============
    @dp.callback_query(F.data == "ai_text_to_speech")
    async def ai_text_to_speech_start(callback: types.CallbackQuery, state: FSMContext):
        text = (
            "🎤 <b>AI Синтез речи</b>\n\n"
            "Введите текст для озвучивания:\n\n"
            "💡 <b>Примеры:</b>\n"
            "• Добро пожаловать в наш магазин!\n"
            "• Сегодня отличная погода для прогулки\n"
            "• Это важное объявление для всех\n\n"
            "📝 <b>Ограничения:</b>\n"
            "• Максимум 1000 символов\n"
            "• Поддерживается русский и английский\n\n"
            "💰 Стоимость: 50₽"
        )
        
        await callback.message.edit_text(
            text,
            reply_markup=back_button(),
            parse_mode=ParseMode.HTML
        )
        await state.set_state(AIToolsFSM.waiting_tts_text)
        await callback.answer()
    
    @dp.message(AIToolsFSM.waiting_tts_text)
    async def ai_text_to_speech_text(message: types.Message, state: FSMContext):
        text = message.text.strip()
        
        if len(text) < 5:
            await message.answer("⚠️ Текст слишком короткий. Введите минимум 5 символов:")
            return
        
        if len(text) > 1000:
            await message.answer("⚠️ Текст слишком длинный. Максимум 1000 символов:")
            return
        
        # Сохраняем текст и показываем выбор голоса
        await state.update_data(tts_text=text)
        
        voice_text = (
            f"🎤 <b>Выбор голоса</b>\n\n"
            f"📝 Ваш текст: {text[:100]}{'...' if len(text) > 100 else ''}\n\n"
            f"🎭 Выберите голос для озвучивания:"
        )
        
        keyboard = types.InlineKeyboardMarkup(inline_keyboard=[
            [
                types.InlineKeyboardButton(text="🌸 Coral (женский)", callback_data="voice_coral"),
                types.InlineKeyboardButton(text="🔥 Alloy (нейтральный)", callback_data="voice_alloy")
            ],
            [
                types.InlineKeyboardButton(text="🌙 Nova (женский)", callback_data="voice_nova"),
                types.InlineKeyboardButton(text="⚡ Echo (мужской)", callback_data="voice_echo")
            ],
            [
                types.InlineKeyboardButton(text="🎭 Fable (британский)", callback_data="voice_fable"),
                types.InlineKeyboardButton(text="💎 Onyx (мужской)", callback_data="voice_onyx")
            ],
            [types.InlineKeyboardButton(text="⬅️ Назад", callback_data="ai_tools")]
        ])
        
        await message.answer(voice_text, reply_markup=keyboard, parse_mode=ParseMode.HTML)
        await state.set_state(AIToolsFSM.waiting_tts_voice)
    
    @dp.callback_query(F.data.startswith("voice_"))
    async def ai_text_to_speech_process(callback: types.CallbackQuery, state: FSMContext):
        voice = callback.data.replace("voice_", "")
        data = await state.get_data()
        text = data.get("tts_text", "")
        
        user_id = callback.from_user.id
        
        # Проверяем админские права
        import config
        is_admin = user_id in config.ADMIN_IDS
        
        balance = await get_balance(user_id)
        
        if not is_admin and balance < 50:
            await callback.message.edit_text(
                f"❌ <b>Недостаточно средств</b>\n\n"
                f"Стоимость: 50₽\n"
                f"Ваш баланс: {balance}₽",
                reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[
                    [types.InlineKeyboardButton(text="💳 Пополнить баланс", callback_data="topup_balance")]
                ]),
                parse_mode=ParseMode.HTML
            )
            await callback.answer()
            await state.clear()
            return
        
        # Списываем средства только если не админ
        if not is_admin:
            await update_balance(user_id, -50)
        
        # Показываем процесс
        voice_names = {
            "coral": "Coral (женский)",
            "alloy": "Alloy (нейтральный)", 
            "nova": "Nova (женский)",
            "echo": "Echo (мужской)",
            "fable": "Fable (британский)",
            "onyx": "Onyx (мужской)"
        }
        
        admin_status = " 👑 (АДМИН - БЕСПЛАТНО)" if is_admin else f" - Списано: 50₽"
        
        processing_msg = await callback.message.edit_text(
            f"🎤 <b>Синтез речи...</b>\n\n"
            f"📝 Текст: {text[:100]}{'...' if len(text) > 100 else ''}\n"
            f"🎭 Голос: {voice_names.get(voice, voice)}\n"
            f"{'👑 Админ-тест' if is_admin else f'Списано: 50₽'}\n\n"
            f"⏳ Генерируем аудио...",
            parse_mode=ParseMode.HTML
        )
        await callback.answer()
        
        try:
            # Определяем инструкции для голоса
            instructions_map = {
                "coral": "Говори с теплой и дружелюбной интонацией",
                "alloy": "Говори четко и нейтрально",
                "nova": "Говори мягко и приятно",
                "echo": "Говори уверенно и четко",
                "fable": "Говори с британским акцентом",
                "onyx": "Говори глубоким и уверенным голосом"
            }
            
            instructions = instructions_map.get(voice, "Говори четко и естественно")
            
            # Генерируем речь
            result = await ai_service.text_to_speech(text, voice, instructions)
            
            if result.get("success"):
                audio_data = result["audio_data"]
                
                # Отправляем аудио
                audio_file = types.BufferedInputFile(audio_data, filename="speech.mp3")
                
                await bot.send_audio(
                    chat_id=callback.message.chat.id,
                    audio=audio_file,
                    caption=f"🎤 <b>Синтез речи готов!</b>\n\n📝 Текст: {text[:100]}{'...' if len(text) > 100 else ''}\n🎭 Голос: {voice_names.get(voice, voice)}\n{'👑 Админ-тест (бесплатно)' if is_admin else '💰 Стоимость: 50₽'}\n\n<i>⚠️ Это речь, сгенерированная ИИ</i>",
                    parse_mode=ParseMode.HTML,
                    reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[
                        [types.InlineKeyboardButton(text="🎤 Озвучить еще", callback_data="ai_text_to_speech")],
                        [types.InlineKeyboardButton(text="⬅️ В главное меню", callback_data="back_to_main")]
                    ])
                )
                
                await processing_msg.delete()
                
            else:
                # Возвращаем деньги при ошибке (только если не админ)
                if not is_admin:
                    await update_balance(user_id, 50)
                
                await processing_msg.edit_text(
                    f"❌ <b>Ошибка синтеза речи</b>\n\n"
                    f"Не удалось создать аудио: {result.get('error', 'Неизвестная ошибка')}\n\n"
                    f"{'👑 Админ-тест (ошибка)' if is_admin else '💰 Средства возвращены на баланс'}",
                    reply_markup=back_button(),
                    parse_mode=ParseMode.HTML
                )
                
        except Exception as e:
            # Возвращаем деньги при исключении (только если не админ)
            if not is_admin:
                await update_balance(user_id, 50)
            
            await processing_msg.edit_text(
                f"❌ <b>Техническая ошибка</b>\n\n"
                f"Произошла ошибка при синтезе речи.\n\n"
                f"{'👑 Админ-тест (ошибка)' if is_admin else '💰 Средства возвращены на баланс'}",
                reply_markup=back_button(),
                parse_mode=ParseMode.HTML
            )
        
        await state.clear()


    # ============ AI Оживление фото ============
    @dp.callback_query(F.data == "ai_animate_photo")
    async def ai_animate_photo_start(callback: types.CallbackQuery, state: FSMContext):
        text = (
            "🎭 <b>AI Оживление фото</b>\n\n"
            "Отправьте фотографию для анимации:\n\n"
            "💡 <b>Подходящие фото:</b>\n"
            "• Портреты людей\n"
            "• Животные\n"
            "• Объекты с четкими контурами\n\n"
            "📝 <b>Требования:</b>\n"
            "• Формат: JPG, PNG, WebP\n"
            "• Размер: до 10 МБ\n"
            "• Разрешение: желательно 1280x720\n\n"
            "💰 Стоимость: 130₽"
        )
        
        await callback.message.edit_text(
            text,
            reply_markup=back_button(),
            parse_mode=ParseMode.HTML
        )
        await state.set_state(AIToolsFSM.waiting_animate_photo)
        await callback.answer()
    
    @dp.message(AIToolsFSM.waiting_animate_photo)
    async def ai_animate_photo_image(message: types.Message, state: FSMContext):
        if not message.photo:
            await message.answer("⚠️ Пожалуйста, отправьте фотографию:")
            return
        
        # Получаем фото в максимальном разрешении
        photo = message.photo[-1]
        
        # Проверяем размер файла (10 МБ = 10485760 байт)
        if photo.file_size and photo.file_size > 10485760:
            await message.answer("⚠️ Файл слишком большой. Максимум 10 МБ:")
            return
        
        # Сохраняем информацию о фото
        await state.update_data(photo_file_id=photo.file_id)
        
        prompt_text = (
            "🎭 <b>Описание анимации</b>\n\n"
            "Опишите как должно двигаться изображение:\n\n"
            "💡 <b>Примеры:</b>\n"
            "• Человек моргает и слегка улыбается\n"
            "• Волосы развеваются на ветру\n"
            "• Глаза следят за камерой\n"
            "• Легкое покачивание головой\n\n"
            "📝 Будьте конкретны но не слишком сложны"
        )
        
        await message.answer(prompt_text, parse_mode=ParseMode.HTML)
        await state.set_state(AIToolsFSM.waiting_animate_prompt)
    
    @dp.message(AIToolsFSM.waiting_animate_prompt)
    async def ai_animate_photo_process(message: types.Message, state: FSMContext):
        prompt = message.text.strip()
        
        if len(prompt) < 5:
            await message.answer("⚠️ Описание слишком короткое. Опишите анимацию подробнее:")
            return
        
        user_id = message.from_user.id
        
        # Проверяем админские права
        import config
        is_admin = user_id in config.ADMIN_IDS
        
        balance = await get_balance(user_id)
        
        if not is_admin and balance < 130:
            await message.answer(
                f"❌ <b>Недостаточно средств</b>\n\n"
                f"Стоимость: 130₽\n"
                f"Ваш баланс: {balance}₽",
                reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[
                    [types.InlineKeyboardButton(text="💳 Пополнить баланс", callback_data="topup_balance")]
                ]),
                parse_mode=ParseMode.HTML
            )
            await state.clear()
            return
        
        # Списываем средства только если не админ
        if not is_admin:
            await update_balance(user_id, -130)
        
        # Показываем процесс
        processing_msg = await message.answer(
            f"🎭 <b>Оживление фото...</b>\n\n"
            f"Описание: {prompt}\n"
            f"{'👑 Админ-тест (бесплатно)' if is_admin else f'Списано: 130₽'}\n\n"
            f"⏳ Это может занять 2-5 минут...",
            parse_mode=ParseMode.HTML
        )
        
        try:
            # Получаем данные фото
            data = await state.get_data()
            photo_file_id = data.get("photo_file_id")
            
            # Скачиваем фото
            file_info = await bot.get_file(photo_file_id)
            photo_data = await bot.download_file(file_info.file_path)
            
            # Создаем задание на оживление фото
            result = await ai_service.animate_photo(prompt, photo_data.read())
            
            if result.get("success"):
                video_id = result.get("video_id")
                
                await processing_msg.edit_text(
                    f"🎭 <b>Фото оживляется...</b>\n\n"
                    f"📝 Описание: {prompt}\n"
                    f"🆔 ID задания: {video_id}\n\n"
                    f"⏳ Ожидайте, это займет несколько минут...\n"
                    f"🔄 Проверяем статус каждые 30 секунд",
                    parse_mode=ParseMode.HTML
                )
                
                # Сохраняем video_id для проверки статуса
                await state.update_data(video_id=video_id, prompt=prompt, user_id=user_id)
                
                # Запускаем проверку статуса через 30 секунд
                asyncio.create_task(check_video_status_loop(bot, message.chat.id, video_id, f"Оживление: {prompt}", processing_msg.message_id))
                
            else:
                # Возвращаем деньги при ошибке (только если не админ)
                if not is_admin:
                    await update_balance(user_id, 130)
                
                await processing_msg.edit_text(
                    f"❌ <b>Ошибка оживления фото</b>\n\n"
                    f"Не удалось запустить анимацию: {result.get('error', 'Неизвестная ошибка')}\n\n"
                    f"{'👑 Админ-тест (ошибка)' if is_admin else '💰 Средства возвращены на баланс'}",
                    reply_markup=back_button(),
                    parse_mode=ParseMode.HTML
                )
                
        except Exception as e:
            # Возвращаем деньги при исключении (только если не админ)
            if not is_admin:
                await update_balance(user_id, 130)
            
            await processing_msg.edit_text(
                f"❌ <b>Техническая ошибка</b>\n\n"
                f"Произошла ошибка при оживлении фото.\n\n"
                f"{'👑 Админ-тест (ошибка)' if is_admin else '💰 Средства возвращены на баланс'}",
                reply_markup=back_button(),
                parse_mode=ParseMode.HTML
            )
        
        await state.clear()


async def check_video_status_loop(bot, chat_id, video_id, prompt, message_id):
    """Автоматическая проверка статуса видео каждые 30 секунд"""
    ai_service = AIService()
    
    for attempt in range(20):  # Максимум 10 минут (20 * 30 сек)
        await asyncio.sleep(30)
        
        try:
            status_result = await ai_service.check_video_status(video_id)
            
            if status_result.get("success"):
                status = status_result.get("status")
                progress = status_result.get("progress", 0)
                
                if status == "completed":
                    # Скачиваем и отправляем видео
                    download_result = await ai_service.download_video(video_id)
                    
                    if download_result.get("success"):
                        video_data = download_result["video_data"]
                        video_file = types.BufferedInputFile(video_data, filename="generated_video.mp4")
                        
                        await bot.send_video(
                            chat_id=chat_id,
                            video=video_file,
                            caption=f"🎬 <b>Видео готово!</b>\n\n📝 {prompt}\n💰 Стоимость: 150₽",
                            parse_mode=ParseMode.HTML,
                            reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[
                                [types.InlineKeyboardButton(text="🎬 Создать еще", callback_data="ai_generate_video")],
                                [types.InlineKeyboardButton(text="⬅️ В главное меню", callback_data="back_to_main")]
                            ])
                        )
                        
                        # Удаляем сообщение о процессе
                        try:
                            await bot.delete_message(chat_id, message_id)
                        except:
                            pass
                        
                        return
                    
                elif status == "failed":
                    # Уведомляем об ошибке
                    await bot.edit_message_text(
                        chat_id=chat_id,
                        message_id=message_id,
                        text=f"❌ <b>Генерация видео не удалась</b>\n\n💰 Средства будут возвращены",
                        parse_mode=ParseMode.HTML
                    )
                    return
                    
                else:
                    # Обновляем прогресс
                    await bot.edit_message_text(
                        chat_id=chat_id,
                        message_id=message_id,
                        text=f"🎬 <b>Видео генерируется...</b>\n\n📝 {prompt}\n📊 Прогресс: {progress}%\n⏳ Осталось примерно {(20-attempt)*30//60} минут",
                        parse_mode=ParseMode.HTML
                    )
                    
        except Exception as e:
            print(f"Error checking video status: {e}")
            continue
    
    # Если время истекло
    await bot.edit_message_text(
        chat_id=chat_id,
        message_id=message_id,
        text=f"⏰ <b>Время ожидания истекло</b>\n\nВидео все еще может генерироваться. Проверьте статус позже.",
        parse_mode=ParseMode.HTML
    )


async def handle_ai_tool_payment(callback_or_message, tool_name: str, cost: int, ai_function):
    """Универсальный обработчик оплаты AI-инструментов"""
    
    # Определяем тип объекта
    if hasattr(callback_or_message, 'from_user'):
        if hasattr(callback_or_message, 'message'):
            # Это callback
            user_id = callback_or_message.from_user.id
            message = callback_or_message.message
            is_callback = True
        else:
            # Это message
            user_id = callback_or_message.from_user.id
            message = callback_or_message
            is_callback = False
    else:
        return
    
    # Проверяем админские права
    import config
    is_admin = user_id in config.ADMIN_IDS
    
    balance = await get_balance(user_id)
    
    # Если админ - пропускаем проверку баланса
    if not is_admin and balance < cost:
        text = (
            f"❌ <b>Недостаточно средств</b>\n\n"
            f"Стоимость: {cost}₽\n"
            f"Ваш баланс: {balance}₽\n"
            f"Не хватает: {cost - balance}₽\n\n"
            f"Пополните баланс для использования этой функции."
        )
        
        keyboard = types.InlineKeyboardMarkup(inline_keyboard=[
            [types.InlineKeyboardButton(text="💳 Пополнить баланс", callback_data="topup_balance")],
            [types.InlineKeyboardButton(text="⬅️ Назад", callback_data="ai_tools")]
        ])
        
        if is_callback:
            await message.edit_text(text, reply_markup=keyboard, parse_mode=ParseMode.HTML)
            await callback_or_message.answer()
        else:
            await message.answer(text, reply_markup=keyboard, parse_mode=ParseMode.HTML)
        return
    
    # Списываем средства только если не админ
    if not is_admin:
        await update_balance(user_id, -cost)
    
    # Показываем процесс
    admin_text = " 👑 (АДМИН - БЕСПЛАТНО)" if is_admin else f" - Списано: {cost}₽"
    processing_text = (
        f"🔄 <b>Обработка запроса...</b>\n\n"
        f"Инструмент: {tool_name}\n"
        f"Статус: {'👑 Админ-тест' if is_admin else f'Оплачено {cost}₽'}\n\n"
        f"Пожалуйста, подождите..."
    )
    
    if is_callback:
        await message.edit_text(processing_text, reply_markup=None, parse_mode=ParseMode.HTML)
        await callback_or_message.answer()
    else:
        processing_msg = await message.answer(processing_text, parse_mode=ParseMode.HTML)
    
    # Выполняем AI функцию
    try:
        result = await ai_function()
        
        if result.get("success"):
            success_text = (
                f"✅ <b>{tool_name}</b>\n\n"
                f"{result.get('text', 'Результат готов!')}\n\n"
                f"{'👑 Админ-тест (бесплатно)' if is_admin else f'💰 Списано: {cost}₽'}"
            )
            
            keyboard = types.InlineKeyboardMarkup(inline_keyboard=[
                [types.InlineKeyboardButton(text="🤖 Другие AI-инструменты", callback_data="ai_tools")],
                [types.InlineKeyboardButton(text="⬅️ В главное меню", callback_data="back_to_main")]
            ])
            
            if is_callback:
                await message.edit_text(success_text, reply_markup=keyboard, parse_mode=ParseMode.HTML)
            else:
                await processing_msg.edit_text(success_text, reply_markup=keyboard, parse_mode=ParseMode.HTML)
        else:
            # Возвращаем деньги при ошибке (только если не админ)
            if not is_admin:
                await update_balance(user_id, cost)
            
            error_text = (
                f"❌ <b>Ошибка обработки</b>\n\n"
                f"Не удалось выполнить запрос: {result.get('error', 'Неизвестная ошибка')}\n\n"
                f"{'👑 Админ-тест (ошибка)' if is_admin else '💰 Средства возвращены на баланс'}"
            )
            
            if is_callback:
                await message.edit_text(error_text, reply_markup=back_button(), parse_mode=ParseMode.HTML)
            else:
                await processing_msg.edit_text(error_text, reply_markup=back_button(), parse_mode=ParseMode.HTML)
            
    except Exception as e:
        # Возвращаем деньги при исключении (только если не админ)
        if not is_admin:
            await update_balance(user_id, cost)
        
        error_text = (
            f"❌ <b>Техническая ошибка</b>\n\n"
            f"Произошла ошибка при обработке запроса.\n\n"
            f"{'👑 Админ-тест (ошибка)' if is_admin else '💰 Средства возвращены на баланс'}"
        )
        
        if is_callback:
            await message.edit_text(error_text, reply_markup=back_button(), parse_mode=ParseMode.HTML)
        else:
            await processing_msg.edit_text(error_text, reply_markup=back_button(), parse_mode=ParseMode.HTML)