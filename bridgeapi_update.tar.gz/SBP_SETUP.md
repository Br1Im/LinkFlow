# SBP Payment Setup for BridgeAPI Bot

## Настройка платежей по СБП через 1payment.com

### Конфигурация

1. **Получите данные от 1payment.com:**
   - Shop ID: `802685` (уже настроен)
   - Secret Key: получите от менеджера 1payment.com
   - Настройте callback URL для webhook'ов

2. **Обновите .env файл:**
```env
# SBP Payment Configuration
SBP_SHOP_ID=802685
SBP_SECRET_KEY=your_secret_key_from_1payment
SBP_SHOP_URL=https://t.me/BridgeAPI_bot
```

### Требования API

Согласно документации https://docs.1payment.com/create-form-sbp, в запросах передаются:

- `shop_id` - ID магазина (802685)
- `amount` - сумма платежа
- `user_id` - уникальный ID пользователя (используется Telegram user ID)
- `shop_url` - URL источника платежа (https://t.me/BridgeAPI_bot)
- `signature` - подпись для безопасности

### Безопасность

- Параметр `user_id` обязателен для антифрод-системы
- Используется Telegram user ID как уникальный идентификатор
- Все запросы подписываются MD5 хешем с секретным ключом

### Webhook Integration

Для автоматического обновления статуса платежей настройте webhook:

1. **Настройте callback URL в 1payment.com:**
   - URL: `https://your-domain.com/payment-callback`
   - Method: POST

2. **Запустите webhook handler:**
```python
# Пример с Flask
from webhook_handler import PaymentWebhookHandler
from flask import Flask, request, jsonify

app = Flask(__name__)
webhook_handler = PaymentWebhookHandler()

@app.route('/payment-callback', methods=['POST'])
def payment_callback():
    callback_data = request.get_json()
    result = await webhook_handler.handle_payment_callback(callback_data)
    return jsonify(result)
```

### Функциональность

1. **Создание платежа:**
   - Пользователь вводит сумму (100-50000 рублей)
   - Создается платежная форма через API 1payment.com
   - Пользователь получает ссылку для оплаты через СБП

2. **Проверка статуса:**
   - Ручная проверка через кнопку "Проверить оплату"
   - Автоматическое обновление через webhook (рекомендуется)

3. **Обработка платежа:**
   - При успешной оплате баланс пользователя пополняется
   - Статус платежа обновляется в базе данных
   - Пользователь получает уведомление

### Тестирование

1. Убедитесь, что все переменные окружения настроены
2. Проверьте подключение к API 1payment.com
3. Протестируйте создание платежа с минимальной суммой
4. Проверьте webhook обработку (если настроен)

### Поддержка

При возникновении проблем:
- Проверьте логи бота
- Убедитесь в корректности Secret Key
- Свяжитесь с поддержкой 1payment.com для настройки callback URL

### Изменения в коде

Основные файлы:
- `sbp_payment.py` - сервис для работы с API 1payment.com
- `handlers.py` - обработчики для пополнения баланса
- `db.py` - функции для работы с платежами
- `webhook_handler.py` - обработка callback'ов от платежной системы
- `config.py` - конфигурация SBP платежей