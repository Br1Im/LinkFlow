# run.py - Запуск объединенного бота
import asyncio
import logging
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode

import config
from handlers import setup_handlers
from ai_handlers import setup_ai_handlers
from admin_handlers import setup_admin_handlers
from db import init_db

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

async def main():
    # Инициализация БД
    await init_db()
    logger.info("База данных инициализирована")
    
    # Создание бота
    bot = Bot(
        token=config.API_TOKEN,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML)
    )
    
    dp = Dispatcher()
    
    # Регистрация обработчиков
    setup_handlers(dp, bot)
    setup_ai_handlers(dp, bot)
    setup_admin_handlers(dp, bot)
    logger.info("Обработчики зарегистрированы")
    
    # Удаление вебхука и старых апдейтов
    await bot.delete_webhook(drop_pending_updates=True)
    
    logger.info("🚀 Объединенный бот запущен!")
    
    # Запуск поллинга
    await dp.start_polling(bot)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        logger.info("Бот остановлен")
