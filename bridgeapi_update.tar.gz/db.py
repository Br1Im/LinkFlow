# db.py - База данных для объединенного бота
import aiosqlite
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List

DB_PATH = "bridgeapi_bot.db"

async def init_db():
    """Инициализация базы данных"""
    async with aiosqlite.connect(DB_PATH) as db:
        # Таблица пользователей
        await db.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                balance INTEGER DEFAULT 0,
                birthdate TEXT,
                horoscope_active INTEGER DEFAULT 0,
                horoscope_expires TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Таблица подписок на каналы
        await db.execute("""
            CREATE TABLE IF NOT EXISTS subscriptions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                channel_key TEXT,
                expires_at TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        """)
        
        # Таблица платежей
        await db.execute("""
            CREATE TABLE IF NOT EXISTS payments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                payment_id TEXT,
                amount INTEGER,
                status TEXT DEFAULT 'pending',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        """)
        
        # Таблица истории гороскопов
        await db.execute("""
            CREATE TABLE IF NOT EXISTS horoscope_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                horoscope_text TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        """)
        
        await db.commit()

async def get_or_create_user(user_id: int, username: str = None) -> Dict[str, Any]:
    """Получить или создать пользователя"""
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM users WHERE user_id = ?", (user_id,)) as cursor:
            row = await cursor.fetchone()
            if row:
                return dict(row)
        
        # Создаем нового пользователя
        await db.execute(
            "INSERT INTO users (user_id, username, balance) VALUES (?, ?, 0)",
            (user_id, username)
        )
        await db.commit()
        
        async with db.execute("SELECT * FROM users WHERE user_id = ?", (user_id,)) as cursor:
            row = await cursor.fetchone()
            return dict(row)

async def update_balance(user_id: int, amount: int):
    """Обновить баланс пользователя"""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE users SET balance = balance + ? WHERE user_id = ?",
            (amount, user_id)
        )
        await db.commit()

async def get_balance(user_id: int) -> int:
    """Получить баланс пользователя"""
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT balance FROM users WHERE user_id = ?", (user_id,)) as cursor:
            row = await cursor.fetchone()
            return row[0] if row else 0

async def create_payment(user_id: int, payment_id: str, amount: int, order_id: str = None):
    """Создать запись о платеже"""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO payments (user_id, payment_id, amount, status) VALUES (?, ?, ?, 'pending')",
            (user_id, payment_id, amount)
        )
        await db.commit()

async def update_payment_status(payment_id: str, status: str):
    """Обновить статус платежа"""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE payments SET status = ? WHERE payment_id = ?",
            (status, payment_id)
        )
        await db.commit()

async def get_payment_by_id(payment_id: str) -> Optional[Dict[str, Any]]:
    """Получить платеж по ID"""
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM payments WHERE payment_id = ?",
            (payment_id,)
        ) as cursor:
            row = await cursor.fetchone()
            return dict(row) if row else None

async def get_pending_payments(user_id: int) -> list:
    """Получить ожидающие платежи пользователя"""
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM payments WHERE user_id = ? AND status = 'pending' ORDER BY created_at DESC",
            (user_id,)
        ) as cursor:
            rows = await cursor.fetchall()
            return [dict(row) for row in rows]

async def activate_horoscope(user_id: int, days: int):
    """Активировать гороскоп на N дней"""
    expires = (datetime.now() + timedelta(days=days)).isoformat()
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE users SET horoscope_active = 1, horoscope_expires = ? WHERE user_id = ?",
            (expires, user_id)
        )
        await db.commit()

async def check_horoscope_active(user_id: int) -> bool:
    """Проверить активен ли гороскоп"""
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "SELECT horoscope_expires FROM users WHERE user_id = ?",
            (user_id,)
        ) as cursor:
            row = await cursor.fetchone()
            if not row or not row[0]:
                return False
            expires = datetime.fromisoformat(row[0])
            return expires > datetime.now()

async def add_subscription(user_id: int, channel_key: str, days: int):
    """Добавить подписку на канал"""
    expires = (datetime.now() + timedelta(days=days)).isoformat()
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO subscriptions (user_id, channel_key, expires_at) VALUES (?, ?, ?)",
            (user_id, channel_key, expires)
        )
        await db.commit()

async def get_active_subscriptions(user_id: int):
    """Получить активные подписки пользователя"""
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM subscriptions WHERE user_id = ? AND expires_at > datetime('now')",
            (user_id,)
        ) as cursor:
            rows = await cursor.fetchall()
            return [dict(row) for row in rows]


async def save_birthdate(user_id: int, birthdate: str):
    """Сохранить дату рождения"""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE users SET birthdate = ? WHERE user_id = ?",
            (birthdate, user_id)
        )
        await db.commit()

async def get_birthdate(user_id: int) -> Optional[str]:
    """Получить дату рождения"""
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "SELECT birthdate FROM users WHERE user_id = ?",
            (user_id,)
        ) as cursor:
            row = await cursor.fetchone()
            return row[0] if row and row[0] else None

async def save_horoscope(user_id: int, horoscope_text: str):
    """Сохранить гороскоп в историю"""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO horoscope_history (user_id, horoscope_text) VALUES (?, ?)",
            (user_id, horoscope_text)
        )
        await db.commit()

async def get_horoscope_info(user_id: int) -> Optional[Dict[str, Any]]:
    """Получить информацию о подписке на гороскоп"""
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "SELECT horoscope_expires FROM users WHERE user_id = ?",
            (user_id,)
        ) as cursor:
            row = await cursor.fetchone()
            if not row or not row[0]:
                return None
            
            expires = datetime.fromisoformat(row[0])
            is_active = expires > datetime.now()
            days_left = (expires - datetime.now()).days if is_active else 0
            
            return {
                "expires": expires,
                "is_active": is_active,
                "days_left": days_left
            }

async def get_all_users() -> List[Dict[str, Any]]:
    """Получить всех пользователей (для админки)"""
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM users ORDER BY created_at DESC"
        ) as cursor:
            rows = await cursor.fetchall()
            return [dict(row) for row in rows]

async def get_user_by_id(user_id: int) -> Optional[Dict[str, Any]]:
    """Получить пользователя по ID"""
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM users WHERE user_id = ?",
            (user_id,)
        ) as cursor:
            row = await cursor.fetchone()
            return dict(row) if row else None

async def get_user_payments(user_id: int) -> List[Dict[str, Any]]:
    """Получить все платежи пользователя"""
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM payments WHERE user_id = ? ORDER BY created_at DESC",
            (user_id,)
        ) as cursor:
            rows = await cursor.fetchall()
            return [dict(row) for row in rows]

async def get_all_payments_stats() -> List[Dict[str, Any]]:
    """Получить статистику по всем платежам"""
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM payments ORDER BY created_at DESC"
        ) as cursor:
            rows = await cursor.fetchall()
            return [dict(row) for row in rows]
