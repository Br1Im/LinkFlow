#!/usr/bin/env python3
# setup_sbp.py - Setup script for SBP payment integration

import os
import shutil

def setup_sbp_integration():
    """Setup SBP payment integration"""
    
    print("🚀 Setting up SBP Payment Integration for BridgeAPI Bot")
    print("=" * 60)
    
    # Check if .env file exists
    if not os.path.exists('.env'):
        if os.path.exists('.env.example'):
            print("📋 Creating .env file from .env.example...")
            shutil.copy('.env.example', '.env')
            print("✅ .env file created")
        else:
            print("❌ .env.example file not found!")
            return
    else:
        print("✅ .env file already exists")
    
    # Read current .env
    env_vars = {}
    if os.path.exists('.env'):
        with open('.env', 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    key, value = line.split('=', 1)
                    env_vars[key] = value
    
    # Check required variables
    required_vars = {
        'API_TOKEN': 'Telegram Bot Token',
        'SBP_SHOP_ID': 'Shop ID from 1payment.com (default: 802685)',
        'SBP_SECRET_KEY': 'Secret Key from 1payment.com',
        'SBP_SHOP_URL': 'Bot URL (default: https://t.me/BridgeAPI_bot)',
        'SUPPORT_USERNAME': 'Support username (default: @eva_support1)'
    }
    
    print("\n🔧 Checking configuration...")
    missing_vars = []
    
    for var, description in required_vars.items():
        if var in env_vars and env_vars[var] and env_vars[var] != f'your_{var.lower()}_here':
            print(f"✅ {var}: configured")
        else:
            print(f"❌ {var}: {description}")
            missing_vars.append(var)
    
    if missing_vars:
        print(f"\n⚠️ Missing configuration variables: {', '.join(missing_vars)}")
        print("\nPlease update your .env file with the following:")
        print("-" * 40)
        for var in missing_vars:
            if var == 'SBP_SHOP_ID':
                print(f"{var}=802685")
            elif var == 'SBP_SHOP_URL':
                print(f"{var}=https://t.me/BridgeAPI_bot")
            elif var == 'SUPPORT_USERNAME':
                print(f"{var}=@eva_support1")
            else:
                print(f"{var}=your_value_here")
        print("-" * 40)
    
    # Check file structure
    print("\n📁 Checking file structure...")
    required_files = [
        'sbp_payment.py',
        'webhook_handler.py',
        'handlers.py',
        'db.py',
        'config.py',
        'run.py'
    ]
    
    for file in required_files:
        if os.path.exists(file):
            print(f"✅ {file}")
        else:
            print(f"❌ {file} - missing!")
    
    print("\n📚 Setup Instructions:")
    print("1. Configure missing environment variables in .env file")
    print("2. Get Secret Key from 1payment.com manager")
    print("3. Run: python test_sbp.py to test integration")
    print("4. Run: python run.py to start the bot")
    print("5. Set up webhook handler for automatic payment processing")
    
    print("\n📖 Documentation:")
    print("- Read SBP_SETUP.md for detailed setup instructions")
    print("- API Documentation: https://docs.1payment.com/create-form-sbp")
    
    print("\n🎯 Contact Information:")
    print("- Partner ID: 11656")
    print("- Project ID: 802685")
    print("- Bot: @BridgeAPI_bot")
    
    if not missing_vars:
        print("\n🎉 Configuration looks good! You can now test the integration.")
    else:
        print(f"\n⚠️ Please configure {len(missing_vars)} missing variables before testing.")

if __name__ == "__main__":
    setup_sbp_integration()