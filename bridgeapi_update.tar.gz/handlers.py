# handlers.py - Обработчики объединенного бота
import asyncio
import requests
from datetime import datetime
from aiogram import types, Dispatcher, F
from aiogram.filters import Command
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.context import FSMContext
from aiogram.enums import ParseMode

import config
from keyboards import main_menu, back_button, horoscope_menu, subscriptions_menu, balance_menu, ai_tools_menu, ai_image_generator_menu
import config as bot_config
from db import (
    get_or_create_user, get_balance,
    save_birthdate, get_birthdate, save_horoscope,
    create_payment, update_payment_status, get_payment_by_id, update_balance
)
from ai_service import AIService
from ai_handlers import AIToolsFSM

# FSM состояния
class HoroscopeFSM(StatesGroup):
    waiting_birthdate = State()

class TopupFSM(StatesGroup):
    waiting_amount = State()

def setup_handlers(dp: Dispatcher, bot):
    
    # ============ /start ============
    @dp.message(Command("start"))
    async def cmd_start(message: types.Message, state: FSMContext):
        await state.clear()
        user = await get_or_create_user(message.from_user.id, message.from_user.username)
        
        await message.answer(
            config.WELCOME_TEXT,
            reply_markup=main_menu(),
            parse_mode=ParseMode.HTML
        )
    
    # ============ Главное меню ============
    @dp.callback_query(F.data == "back_to_main")
    async def back_to_main(callback: types.CallbackQuery, state: FSMContext):
        await state.clear()
        await callback.message.edit_text(
            config.WELCOME_TEXT,
            reply_markup=main_menu(),
            parse_mode=ParseMode.HTML
        )
        await callback.answer()
    
    # ============ Политика конфиденциальности ============
    def split_text_smart(text: str, max_length: int = 3800) -> list:
        """Умное разбиение текста на части по разделам"""
        parts = []
        current_part = ""
        
        lines = text.split('\n')
        
        for line in lines:
            # Если добавление строки превысит лимит
            if len(current_part) + len(line) + 1 > max_length:
                # Сохраняем текущую часть
                if current_part:
                    parts.append(current_part.strip())
                current_part = line + '\n'
            else:
                current_part += line + '\n'
        
        # Добавляем последнюю часть
        if current_part.strip():
            parts.append(current_part.strip())
        
        return parts
    
    @dp.callback_query(F.data == "privacy_policy")
    async def show_privacy_policy(callback: types.CallbackQuery):
        parts = split_text_smart(config.PRIVACY_POLICY_TEXT)
        total_parts = len(parts)
        
        keyboard = []
        if total_parts > 1:
            keyboard.append([types.InlineKeyboardButton(
                text=f"➡️ Далее (2/{total_parts})", 
                callback_data="privacy_part_2"
            )])
        else:
            keyboard.append([types.InlineKeyboardButton(
                text="◀️ В главное меню", 
                callback_data="back_to_main"
            )])
        
        await callback.message.edit_text(
            parts[0],
            reply_markup=types.InlineKeyboardMarkup(inline_keyboard=keyboard),
            parse_mode=ParseMode.HTML
        )
        await callback.answer()
    
    @dp.callback_query(F.data.startswith("privacy_part_"))
    async def show_privacy_part(callback: types.CallbackQuery):
        part_num = int(callback.data.split("_")[-1])
        parts = split_text_smart(config.PRIVACY_POLICY_TEXT)
        total_parts = len(parts)
        
        if part_num > total_parts:
            await callback.answer("Эта часть не существует")
            return
        
        keyboard = []
        
        # Кнопка "Назад"
        if part_num > 1:
            keyboard.append([types.InlineKeyboardButton(
                text=f"⬅️ Назад ({part_num-1}/{total_parts})", 
                callback_data=f"privacy_part_{part_num-1}" if part_num > 2 else "privacy_policy"
            )])
        
        # Кнопка "Далее"
        if part_num < total_parts:
            keyboard.append([types.InlineKeyboardButton(
                text=f"➡️ Далее ({part_num+1}/{total_parts})", 
                callback_data=f"privacy_part_{part_num+1}"
            )])
        
        # Кнопка "В главное меню"
        keyboard.append([types.InlineKeyboardButton(
            text="◀️ В главное меню", 
            callback_data="back_to_main"
        )])
        
        await callback.message.edit_text(
            parts[part_num - 1],
            reply_markup=types.InlineKeyboardMarkup(inline_keyboard=keyboard),
            parse_mode=ParseMode.HTML
        )
        await callback.answer()
    
    # ============ Пользовательское соглашение ============
    @dp.callback_query(F.data == "user_agreement")
    async def show_user_agreement(callback: types.CallbackQuery):
        text = bot_config.USER_AGREEMENT_TEXT
        
        await callback.message.edit_text(
            text,
            reply_markup=back_button(),
            parse_mode=ParseMode.HTML,
            disable_web_page_preview=True
        )
        await callback.answer()
    
    # ============ AI Генератор изображений ============
    @dp.callback_query(F.data == "ai_image_generator")
    async def show_ai_image_generator(callback: types.CallbackQuery):
        text = (
            "🎨 <b>AI Генератор изображений</b>\n\n"
            "Создавайте уникальные изображения с помощью искусственного интеллекта!\n\n"
            "<b>Доступные функции:</b>\n\n"
            "🖼 <b>Генерация изображений</b> - создание картинок по текстовому описанию\n"
            "💰 Стоимость: 120₽\n\n"
            "🎤 <b>Синтез речи</b> - озвучивание текста с выбором голоса\n"
            "💰 Стоимость: 50₽\n\n"
            "🎭 <b>Оживление фото</b> - анимация статичных портретов\n"
            "💰 Стоимость: 130₽\n\n"
            "🎬 <b>Генерация видео</b> - создание короткого видео из текста\n"
            "💰 Стоимость: 150₽\n\n"
            "👑 <i>Для админов все функции бесплатны!</i>"
        )
        
        from keyboards import ai_image_generator_menu
        
        await callback.message.edit_text(
            text,
            reply_markup=ai_image_generator_menu(),
            parse_mode=ParseMode.HTML
        )
        await callback.answer()
    
    # ============ Генерация изображений (перенаправление) ============
    @dp.callback_query(F.data == "generate_image")
    async def generate_image_redirect(callback: types.CallbackQuery, state: FSMContext):
        # Вызываем функцию генерации изображений
        text = (
            "🖼 <b>AI Генерация изображений</b>\n\n"
            "Опишите изображение, которое хотите создать:\n\n"
            "💡 <b>Примеры:</b>\n"
            "• Футуристический город на закате\n"
            "• Кот-космонавт в скафандре\n"
            "• Абстрактная картина в стиле Пикассо\n\n"
            "💰 Стоимость: 120₽\n\n"
            "👑 <i>Для админов - бесплатно!</i>"
        )
        
        await callback.message.edit_text(
            text,
            reply_markup=back_button(),
            parse_mode=ParseMode.HTML
        )
        await state.set_state(AIToolsFSM.waiting_image_prompt)
        await callback.answer()
    
    # ============ Оживление фото (перенаправление) ============
    @dp.callback_query(F.data == "animate_photo")
    async def animate_photo_redirect(callback: types.CallbackQuery, state: FSMContext):
        # Вызываем функцию оживления фото
        text = (
            "🎭 <b>AI Оживление фото</b>\n\n"
            "Отправьте фотографию для анимации:\n\n"
            "💡 <b>Подходящие фото:</b>\n"
            "• Портреты людей\n"
            "• Животные\n"
            "• Объекты с четкими контурами\n\n"
            "📝 <b>Требования:</b>\n"
            "• Формат: JPG, PNG, WebP\n"
            "• Размер: до 10 МБ\n"
            "• Разрешение: желательно 1280x720\n\n"
            "💰 Стоимость: 130₽\n\n"
            "👑 <i>Для админов - бесплатно!</i>"
        )
        
        await callback.message.edit_text(
            text,
            reply_markup=back_button(),
            parse_mode=ParseMode.HTML
        )
        await state.set_state(AIToolsFSM.waiting_animate_photo)
        await callback.answer()
    
    # ============ Генерация видео (перенаправление) ============
    @dp.callback_query(F.data == "generate_video")
    async def generate_video_redirect(callback: types.CallbackQuery, state: FSMContext):
        # Вызываем функцию генерации видео
        text = (
            "🎬 <b>AI Генерация видео</b>\n\n"
            "Опишите видео, которое хотите создать:\n\n"
            "💡 <b>Примеры:</b>\n"
            "• Волны океана на закате\n"
            "• Полет через облака\n"
            "• Танцующие огни северного сияния\n"
            "• Кот играет с мячиком\n\n"
            "⏱ Длительность: 4 секунды\n"
            "📐 Разрешение: 1280x720 (HD)\n"
            "💰 Стоимость: 150₽\n\n"
            "👑 <i>Для админов - бесплатно!</i>"
        )
        
        await callback.message.edit_text(
            text,
            reply_markup=back_button(),
            parse_mode=ParseMode.HTML
        )
        await state.set_state(AIToolsFSM.waiting_video_prompt)
        await callback.answer()
    
    # ============ Контакты ============
    @dp.callback_query(F.data == "support")
    async def show_support(callback: types.CallbackQuery):
        text = (
            "📞 <b>Контакты</b>\n\n"
            "<b>Company Name:</b> Monitorson OÜ\n"
            "<b>Registration Number:</b> 17255773\n"
            "<b>Registered address:</b> Türi vald, Türi linn, Aia tn 12, 72215\n\n"
            f"<b>Contact:</b> {config.SUPPORT_USERNAME}"
        )
        
        await callback.message.edit_text(
            text,
            reply_markup=back_button(),
            parse_mode=ParseMode.HTML
        )
        await callback.answer()
    
    # ============ Платные подписки ============
    @dp.callback_query(F.data == "subscriptions")
    async def show_subscriptions(callback: types.CallbackQuery):
        text = (
            "💎 <b>Платные подписки</b>\n\n"
            "Выберите канал для подписки:"
        )
        
        await callback.message.edit_text(
            text,
            reply_markup=subscriptions_menu(),
            parse_mode=ParseMode.HTML
        )
        await callback.answer()
    
    # ============ Описания каналов ============
    @dp.callback_query(F.data == "channel_crypto")
    async def show_crypto_channel(callback: types.CallbackQuery):
        text = (
            "🪙 <b>Крипто-канал</b>\n\n"
            "📊 Что внутри:\n"
            "• Ежедневные обзоры рынка криптовалют\n"
            "• Анализ топовых монет и альткоинов\n"
            "• Сигналы для входа и выхода из позиций\n"
            "• Обучающие материалы по трейдингу\n"
            "• Новости крипто-индустрии\n\n"
            "💰 Стоимость: 1500-3000₽\n"
            "💎 Платное ведение: +100₽/день\n\n"
            "⚠️ Для подписки пополните баланс и выберите канал"
        )
        
        await callback.message.edit_text(
            text,
            reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[
                [types.InlineKeyboardButton(text="💳 Пополнить баланс", callback_data="topup_balance")],
                [types.InlineKeyboardButton(text="⬅️ Назад", callback_data="subscriptions")]
            ]),
            parse_mode=ParseMode.HTML
        )
        await callback.answer()
    
    @dp.callback_query(F.data == "channel_fitness")
    async def show_fitness_channel(callback: types.CallbackQuery):
        text = (
            "💪 <b>Фитнес-канал</b>\n\n"
            "🏋️ Что внутри:\n"
            "• Программы тренировок для разных уровней\n"
            "• Упражнения с видео-инструкциями\n"
            "• Советы по технике выполнения\n"
            "• Планы восстановления и растяжки\n"
            "• Мотивационный контент\n\n"
            "💰 Стоимость: 1500-3000₽\n"
            "💎 Платное ведение: +100₽/день\n\n"
            "⚠️ Для подписки пополните баланс и выберите канал"
        )
        
        await callback.message.edit_text(
            text,
            reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[
                [types.InlineKeyboardButton(text="💳 Пополнить баланс", callback_data="topup_balance")],
                [types.InlineKeyboardButton(text="⬅️ Назад", callback_data="subscriptions")]
            ]),
            parse_mode=ParseMode.HTML
        )
        await callback.answer()
    
    @dp.callback_query(F.data == "channel_nutrition")
    async def show_nutrition_channel(callback: types.CallbackQuery):
        text = (
            "🥗 <b>Канал по питанию</b>\n\n"
            "🍎 Что внутри:\n"
            "• Сбалансированные планы питания\n"
            "• Рецепты здоровых блюд\n"
            "• Расчет калорий и БЖУ\n"
            "• Советы по правильному питанию\n"
            "• Списки полезных продуктов\n\n"
            "💰 Стоимость: 1500-3000₽\n"
            "💎 Платное ведение: +100₽/день\n\n"
            "⚠️ Для подписки пополните баланс и выберите канал"
        )
        
        await callback.message.edit_text(
            text,
            reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[
                [types.InlineKeyboardButton(text="💳 Пополнить баланс", callback_data="topup_balance")],
                [types.InlineKeyboardButton(text="⬅️ Назад", callback_data="subscriptions")]
            ]),
            parse_mode=ParseMode.HTML
        )
        await callback.answer()
    
    @dp.callback_query(F.data == "channel_ai")
    async def show_ai_channel(callback: types.CallbackQuery):
        text = (
            "🤖 <b>AI-канал</b>\n\n"
            "🧠 Что внутри:\n"
            "• Обзоры новых AI-инструментов\n"
            "• Готовые промпты для ChatGPT и других AI\n"
            "• Кейсы использования AI в бизнесе\n"
            "• Обучающие материалы по работе с AI\n"
            "• Новости искусственного интеллекта\n\n"
            "💰 Стоимость: 1500-3000₽\n"
            "💎 Платное ведение: +100₽/день\n\n"
            "⚠️ Для подписки пополните баланс и выберите канал"
        )
        
        await callback.message.edit_text(
            text,
            reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[
                [types.InlineKeyboardButton(text="💳 Пополнить баланс", callback_data="topup_balance")],
                [types.InlineKeyboardButton(text="⬅️ Назад", callback_data="subscriptions")]
            ]),
            parse_mode=ParseMode.HTML
        )
        await callback.answer()
    
    # ============ AI-инструменты ============
    @dp.callback_query(F.data == "ai_tools")
    async def show_ai_tools(callback: types.CallbackQuery):
        text = (
            "🤖 <b>AI-инструменты</b>\n\n"
            "Выберите нужный инструмент:\n\n"
            "📝 <b>Генератор постов</b> - создание постов для Telegram\n"
            "💡 <b>Генератор названий</b> - 10 вариантов названий для канала/бренда\n"
            "🎯 <b>Персональный промпт</b> - детальный промпт для ChatGPT/Claude\n\n"
            "💧 <b>Калькулятор воды</b> - расчет нормы воды по весу\n"
            "🍽 <b>Расчет БЖУ</b> - расчет белков, жиров, углеводов\n\n"
            "🪙 <b>Топ-3 монет</b> - анализ топовых криптовалют\n"
            "🏦 <b>Надежные биржи</b> - список проверенных бирж\n"
            "🔮 <b>Крипто-гороскоп</b> - шуточный гороскоп для трейдеров\n\n"
            "👑 <i>Для админов все функции бесплатны!</i>"
        )
        
        await callback.message.edit_text(
            text,
            reply_markup=ai_tools_menu(),
            parse_mode=ParseMode.HTML
        )
        await callback.answer()
    
    # ============ Баланс ============
    @dp.callback_query(F.data == "balance")
    async def show_balance(callback: types.CallbackQuery):
        user_id = callback.from_user.id
        balance = await get_balance(user_id)
        
        text = (
            f"💰 <b>Ваш баланс: {balance}₽</b>\n\n"
            f"<b>📋 Прайс-лист услуг:</b>\n\n"
            f"<b>🎨 AI Генератор изображений:</b>\n"
            f"• 🖼 Генерация изображений - 120₽\n"
            f"• ✨ Улучшение качества - 100₽\n"
            f"• 🎭 Оживление фото - 130₽\n"
            f"• 🎬 Генерация видео - 150₽\n\n"
            f"<b>💎 Платные каналы:</b>\n"
            f"• Стоимость: 1500-3000₽ (+100₽/день ведение)\n\n"
            f"<b>🤖 AI-инструменты:</b>\n"
            f"• 📝 Генератор постов - 5₽\n"
            f"• 💡 Генератор названий - 10₽\n"
            f"• 🎯 Персональный промпт - 15₽\n\n"
            f"<b>🏋️ Фитнес и питание:</b>\n"
            f"• 💧 Калькулятор воды - 10₽\n"
            f"• 🍽 Расчет БЖУ - 10₽\n"
            f"• 💊 Аптечка спортсмена - 10₽\n\n"
            f"<b>💰 Крипто-инструменты:</b>\n"
            f"• 🪙 Топ-3 монет - 5₽\n"
            f"• 🏦 Надежные биржи - 5₽\n"
            f"• 🔮 Крипто-гороскоп - 10₽"
        )
        
        await callback.message.edit_text(
            text,
            reply_markup=balance_menu(),
            parse_mode=ParseMode.HTML
        )
        await callback.answer()
    
    # ============ Пополнение баланса через СБП ============
    @dp.callback_query(F.data == "topup_balance")
    async def topup_balance(callback: types.CallbackQuery, state: FSMContext):
        text = (
            "💳 <b>Пополнение баланса через СБП</b>\n\n"
            "Введите сумму для пополнения (от 100 до 50000 рублей):\n\n"
            "💡 <i>Например: 500</i>"
        )
        
        await callback.message.edit_text(
            text,
            reply_markup=back_button(),
            parse_mode=ParseMode.HTML
        )
        await state.set_state(TopupFSM.waiting_amount)
        await callback.answer()
    
    @dp.message(TopupFSM.waiting_amount)
    async def process_topup_amount(message: types.Message, state: FSMContext):
        try:
            amount = float(message.text.strip())
            
            if not (100 <= amount <= 50000):
                await message.answer(
                    "⚠️ Сумма должна быть от 100 до 50000 рублей.\n"
                    "Попробуйте еще раз:"
                )
                return
            
            # Create SBP payment
            from sbp_payment import SBPPaymentService
            payment_service = SBPPaymentService()
            
            payment_result = payment_service.create_payment_form(
                amount=amount,
                user_id=message.from_user.id,
                description=f"Пополнение баланса BridgeAPI Bot на {amount} ₽"
            )
            
            if payment_result["success"]:
                # Save payment to database
                await create_payment(
                    user_id=message.from_user.id,
                    payment_id=payment_result["payment_id"],
                    amount=int(amount * 100)  # Store in kopecks
                )
                
                keyboard = types.InlineKeyboardMarkup(inline_keyboard=[
                    [types.InlineKeyboardButton(
                        text="💳 Оплатить через СБП", 
                        url=payment_result["payment_url"]
                    )],
                    [types.InlineKeyboardButton(
                        text="🔄 Проверить оплату", 
                        callback_data=f"check_payment_{payment_result['payment_id']}"
                    )],
                    [types.InlineKeyboardButton(
                        text="⬅️ Назад", 
                        callback_data="balance"
                    )]
                ])
                
                text = (
                    f"💳 <b>Оплата через СБП</b>\n\n"
                    f"💰 Сумма: {amount} ₽\n"
                    f"🆔 ID платежа: {payment_result['payment_id']}\n\n"
                    f"1️⃣ Нажмите кнопку \"Оплатить через СБП\"\n"
                    f"2️⃣ Выберите свой банк в приложении\n"
                    f"3️⃣ Подтвердите платеж\n"
                    f"4️⃣ Нажмите \"Проверить оплату\" после оплаты\n\n"
                    f"⏱ Платеж действителен 15 минут"
                )
                
                await message.answer(
                    text,
                    reply_markup=keyboard,
                    parse_mode=ParseMode.HTML
                )
            else:
                await message.answer(
                    f"❌ <b>Ошибка создания платежа</b>\n\n"
                    f"Причина: {payment_result.get('error', 'Неизвестная ошибка')}\n\n"
                    f"Попробуйте позже или обратитесь в поддержку: {config.SUPPORT_USERNAME}",
                    reply_markup=back_button(),
                    parse_mode=ParseMode.HTML
                )
            
            await state.clear()
            
        except ValueError:
            await message.answer(
                "⚠️ Введите корректную сумму числом.\n"
                "Например: 500"
            )
    
    # ============ Проверка статуса платежа ============
    @dp.callback_query(F.data.startswith("check_payment_"))
    async def check_payment_status(callback: types.CallbackQuery):
        payment_id = callback.data.replace("check_payment_", "")
        
        from sbp_payment import SBPPaymentService
        payment_service = SBPPaymentService()
        
        # Check payment status via API
        status_result = payment_service.check_payment_status(payment_id)
        
        if status_result.get("success"):
            payment_status = status_result.get("status", "pending")
            
            if payment_status == "completed":
                # Get payment from database
                payment = await get_payment_by_id(payment_id)
                if payment and payment["status"] == "pending":
                    # Update payment status
                    await update_payment_status(payment_id, "completed")
                    
                    # Add balance
                    amount_rubles = payment["amount"] // 100  # Convert from kopecks
                    await update_balance(payment["user_id"], amount_rubles)
                    
                    text = (
                        f"✅ <b>Платеж успешно обработан!</b>\n\n"
                        f"💰 Зачислено: {amount_rubles} ₽\n"
                        f"🆔 ID платежа: {payment_id}\n\n"
                        f"Баланс обновлен. Спасибо за пополнение!"
                    )
                    
                    keyboard = types.InlineKeyboardMarkup(inline_keyboard=[
                        [types.InlineKeyboardButton(text="💰 Мой баланс", callback_data="balance")],
                        [types.InlineKeyboardButton(text="⬅️ В главное меню", callback_data="back_to_main")]
                    ])
                else:
                    text = "✅ Платеж уже был обработан ранее."
                    keyboard = back_button()
                    
            elif payment_status == "failed":
                await update_payment_status(payment_id, "failed")
                text = (
                    f"❌ <b>Платеж отклонен</b>\n\n"
                    f"🆔 ID платежа: {payment_id}\n\n"
                    f"Попробуйте создать новый платеж или обратитесь в поддержку: {config.SUPPORT_USERNAME}"
                )
                keyboard = types.InlineKeyboardMarkup(inline_keyboard=[
                    [types.InlineKeyboardButton(text="💳 Новый платеж", callback_data="topup_balance")],
                    [types.InlineKeyboardButton(text="⬅️ Назад", callback_data="balance")]
                ])
            else:
                text = (
                    f"⏳ <b>Платеж в обработке</b>\n\n"
                    f"🆔 ID платежа: {payment_id}\n"
                    f"📊 Статус: {payment_status}\n\n"
                    f"Пожалуйста, подождите или проверьте позже."
                )
                keyboard = types.InlineKeyboardMarkup(inline_keyboard=[
                    [types.InlineKeyboardButton(
                        text="🔄 Проверить еще раз", 
                        callback_data=f"check_payment_{payment_id}"
                    )],
                    [types.InlineKeyboardButton(text="⬅️ Назад", callback_data="balance")]
                ])
        else:
            text = (
                f"❌ <b>Ошибка проверки платежа</b>\n\n"
                f"Не удалось получить статус платежа.\n"
                f"Обратитесь в поддержку: {config.SUPPORT_USERNAME}"
            )
            keyboard = back_button()
        
        await callback.message.edit_text(
            text,
            reply_markup=keyboard,
            parse_mode=ParseMode.HTML
        )
        await callback.answer()
    
    # ============ Выбор канала (ЗАБЛОКИРОВАНО) ============
    @dp.callback_query(F.data.startswith("channel_"))
    async def channel_selection_blocked(callback: types.CallbackQuery):
        text = (
            "⚠️ <b>Подписка временно недоступна</b>\n\n"
            "К сожалению, функция подписки на каналы временно отключена.\n"
            "Пожалуйста, свяжитесь с поддержкой для получения дополнительной информации."
        )
        
        await callback.message.edit_text(
            text,
            reply_markup=back_button(),
            parse_mode=ParseMode.HTML
        )
        await callback.answer()
    
    
    # ============ Гороскоп AI ============
    @dp.callback_query(F.data == "horoscope")
    async def show_horoscope_menu(callback: types.CallbackQuery):
        text = (
            "🔮 <b>Гороскоп AI</b>\n\n"
            "Получайте персональные гороскопы на основе вашей даты рождения.\n\n"
            "✨ Бесплатно для всех пользователей!"
        )
        
        await callback.message.edit_text(
            text,
            reply_markup=horoscope_menu(True),  # Всегда показываем как с подпиской
            parse_mode=ParseMode.HTML
        )
        await callback.answer()
    
    # ============ Получить гороскоп ============
    @dp.callback_query(F.data == "get_horoscope")
    async def get_horoscope(callback: types.CallbackQuery, state: FSMContext):
        user_id = callback.from_user.id
        
        # Проверяем дату рождения
        birthdate = await get_birthdate(user_id)
        if not birthdate:
            text = (
                "📅 <b>Введите дату рождения</b>\n\n"
                "Формат: ДД.ММ.ГГГГ\n"
                "Например: 15.03.1990"
            )
            await callback.message.edit_text(
                text,
                reply_markup=back_button(),
                parse_mode=ParseMode.HTML
            )
            await state.set_state(HoroscopeFSM.waiting_birthdate)
            await callback.answer()
            return
        
        # Генерируем гороскоп
        await callback.answer("🔮 Генерирую гороскоп...")
        
        horoscope_text = await generate_horoscope(birthdate)
        await save_horoscope(user_id, horoscope_text)
        
        await callback.message.edit_text(
            f"🔮 <b>Ваш гороскоп на сегодня</b>\n\n{horoscope_text}",
            reply_markup=back_button(),
            parse_mode=ParseMode.HTML
        )
    
    @dp.message(HoroscopeFSM.waiting_birthdate)
    async def process_birthdate(message: types.Message, state: FSMContext):
        try:
            # Проверяем формат даты
            birthdate = datetime.strptime(message.text.strip(), "%d.%m.%Y")
            birthdate_str = birthdate.strftime("%d.%m.%Y")
            
            # Сохраняем
            await save_birthdate(message.from_user.id, birthdate_str)
            
            # Генерируем гороскоп
            horoscope_text = await generate_horoscope(birthdate_str)
            await save_horoscope(message.from_user.id, horoscope_text)
            
            await message.answer(
                f"🔮 <b>Ваш гороскоп на сегодня</b>\n\n{horoscope_text}",
                reply_markup=back_button(),
                parse_mode=ParseMode.HTML
            )
            await state.clear()
        except ValueError:
            await message.answer(
                "⚠️ Неверный формат даты. Используйте ДД.ММ.ГГГГ\n"
                "Например: 15.03.1990"
            )


async def generate_horoscope(birthdate: str) -> str:
    """Генерация гороскопа через DeepSeek API"""
    # Определяем знак зодиака
    day, month, year = map(int, birthdate.split("."))
    zodiac = get_zodiac_sign(day, month)
    
    # Если нет API ключа - возвращаем заглушку
    if not config.DEEPSEEK_API_KEY:
        return (
            f"♈️ <b>Знак зодиака: {zodiac}</b>\n\n"
            f"Сегодня благоприятный день для новых начинаний. "
            f"Звезды советуют обратить внимание на финансовые вопросы. "
            f"В личной жизни возможны приятные сюрпризы. "
            f"Будьте внимательны к деталям в работе."
        )
    
    try:
        today = datetime.now().strftime("%d.%m.%Y")
        
        prompt = f"""Ты профессиональный астролог. Составь персональный гороскоп на сегодня ({today}) для человека со знаком зодиака {zodiac}.

Гороскоп должен быть:
- Позитивным и мотивирующим
- Конкретным (упомяни карьеру, любовь, здоровье, финансы)
- Объемом 150-200 слов
- На русском языке

Не используй общие фразы. Сделай прогноз интересным и персональным."""

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {config.DEEPSEEK_API_KEY}"
        }
        
        payload = {
            "model": "deepseek-chat",
            "messages": [
                {"role": "system", "content": "Ты профессиональный астролог, который составляет точные и интересные гороскопы."},
                {"role": "user", "content": prompt}
            ],
            "temperature": 0.7,
            "max_tokens": 500
        }
        
        response = requests.post(
            "https://api.deepseek.com/v1/chat/completions",
            headers=headers,
            json=payload,
            timeout=30
        )
        
        if response.status_code == 200:
            data = response.json()
            if "choices" in data and len(data["choices"]) > 0:
                horoscope_text = data["choices"][0]["message"]["content"].strip()
                return f"♈️ <b>Знак зодиака: {zodiac}</b>\n\n{horoscope_text}"
        
        # Если что-то пошло не так - возвращаем заглушку
        return (
            f"♈️ <b>Знак зодиака: {zodiac}</b>\n\n"
            f"Сегодня благоприятный день для новых начинаний. "
            f"Звезды советуют обратить внимание на финансовые вопросы. "
            f"В личной жизни возможны приятные сюрпризы. "
            f"Будьте внимательны к деталям в работе."
        )
        
    except Exception as e:
        # В случае ошибки возвращаем заглушку
        return (
            f"♈️ <b>Знак зодиака: {zodiac}</b>\n\n"
            f"Сегодня благоприятный день для новых начинаний. "
            f"Звезды советуют обратить внимание на финансовые вопросы. "
            f"В личной жизни возможны приятные сюрпризы. "
            f"Будьте внимательны к деталям в работе."
        )


def get_zodiac_sign(day: int, month: int) -> str:
    """Определить знак зодиака по дате"""
    zodiac_signs = [
        (1, 20, "Козерог"), (2, 19, "Водолей"), (3, 20, "Рыбы"),
        (4, 20, "Овен"), (5, 21, "Телец"), (6, 21, "Близнецы"),
        (7, 23, "Рак"), (8, 23, "Лев"), (9, 23, "Дева"),
        (10, 23, "Весы"), (11, 22, "Скорпион"), (12, 22, "Стрелец"),
        (12, 31, "Козерог")
    ]
    
    for m, d, sign in zodiac_signs:
        if month < m or (month == m and day <= d):
            return sign
    return "Козерог"


# ============ AI-инструменты обработчики ============

async def handle_ai_tool_payment(callback: types.CallbackQuery, tool_name: str, cost: int, ai_function):
    """Универсальный обработчик оплаты AI-инструментов"""
    user_id = callback.from_user.id
    balance = await get_balance(user_id)
    
    if balance < cost:
        await callback.message.edit_text(
            f"❌ <b>Недостаточно средств</b>\n\n"
            f"Стоимость: {cost}₽\n"
            f"Ваш баланс: {balance}₽\n"
            f"Не хватает: {cost - balance}₽\n\n"
            f"Пополните баланс для использования этой функции.",
            reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[
                [types.InlineKeyboardButton(text="💳 Пополнить баланс", callback_data="topup_balance")],
                [types.InlineKeyboardButton(text="⬅️ Назад", callback_data="ai_tools")]
            ]),
            parse_mode=ParseMode.HTML
        )
        await callback.answer()
        return
    
    # Списываем средства
    await update_balance(user_id, -cost)
    
    # Показываем процесс
    await callback.message.edit_text(
        f"🔄 <b>Обработка запроса...</b>\n\n"
        f"Инструмент: {tool_name}\n"
        f"Списано: {cost}₽\n\n"
        f"Пожалуйста, подождите...",
        reply_markup=None,
        parse_mode=ParseMode.HTML
    )
    await callback.answer()
    
    # Выполняем AI функцию
    try:
        result = await ai_function()
        
        if result.get("success"):
            await callback.message.edit_text(
                f"✅ <b>{tool_name}</b>\n\n"
                f"{result.get('text', 'Результат готов!')}\n\n"
                f"💰 Списано: {cost}₽",
                reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[
                    [types.InlineKeyboardButton(text="🤖 Другие AI-инструменты", callback_data="ai_tools")],
                    [types.InlineKeyboardButton(text="⬅️ В главное меню", callback_data="back_to_main")]
                ]),
                parse_mode=ParseMode.HTML
            )
        else:
            # Возвращаем деньги при ошибке
            await update_balance(user_id, cost)
            
            await callback.message.edit_text(
                f"❌ <b>Ошибка обработки</b>\n\n"
                f"Не удалось выполнить запрос: {result.get('error', 'Неизвестная ошибка')}\n\n"
                f"💰 Средства возвращены на баланс",
                reply_markup=back_button(),
                parse_mode=ParseMode.HTML
            )
            
    except Exception as e:
        # Возвращаем деньги при исключении
        await update_balance(user_id, cost)
        
        await callback.message.edit_text(
            f"❌ <b>Техническая ошибка</b>\n\n"
            f"Произошла ошибка при обработке запроса.\n\n"
            f"💰 Средства возвращены на баланс",
            reply_markup=back_button(),
            parse_mode=ParseMode.HTML
        )
    # ============ Баланс ============
    @dp.callback_query(F.data == "balance")
    async def show_balance(callback: types.CallbackQuery):
        user_id = callback.from_user.id
        balance = await get_balance(user_id)
        
        text = (
            f"💰 <b>Ваш баланс</b>\n\n"
            f"💵 Текущий баланс: {balance}₽\n\n"
            f"💡 <i>Используйте баланс для оплаты AI-инструментов и подписок</i>"
        )
        
        await callback.message.edit_text(
            text,
            reply_markup=balance_menu(),
            parse_mode=ParseMode.HTML
        )
        await callback.answer()
    
    # ============ Пополнение баланса ============
    @dp.callback_query(F.data == "topup_balance")
    async def topup_balance_start(callback: types.CallbackQuery, state: FSMContext):
        text = (
            "💳 <b>Пополнение баланса через 1payment.com</b>\n\n"
            "Введите сумму для пополнения (от 100 до 50000 рублей):\n\n"
            "💡 <i>Например: 500</i>\n"
            "💡 <i>Или /cancel для отмены</i>\n\n"
            "🔹 Доступные способы оплаты:\n"
            "• СБП (Система быстрых платежей)\n"
            "• Банковские карты\n"
            "• Электронные кошельки"
        )
        
        await callback.message.edit_text(
            text,
            reply_markup=back_button(),
            parse_mode=ParseMode.HTML
        )
        await state.set_state(TopupFSM.waiting_amount)
        await callback.answer()
    
    @dp.message(TopupFSM.waiting_amount)
    async def topup_amount_entered(message: types.Message, state: FSMContext):
        if message.text == "/cancel":
            await message.answer("❌ Пополнение отменено")
            await state.clear()
            return
        
        try:
            amount = float(message.text.strip())
            
            if amount < 100:
                await message.answer(
                    "⚠️ Минимальная сумма пополнения: 100₽\n"
                    "Попробуйте еще раз или /cancel для отмены"
                )
                return
            
            if amount > 50000:
                await message.answer(
                    "⚠️ Максимальная сумма пополнения: 50000₽\n"
                    "Попробуйте еще раз или /cancel для отмены"
                )
                return
            
            # Создаем платеж через 1payment.com SBP
            from sbp_payment import SBPPaymentService
            
            payment_service = SBPPaymentService()
            payment_result = payment_service.create_payment_form(
                amount=amount,
                user_id=message.from_user.id,
                description=f"Пополнение баланса BridgeAPI Bot"
            )
            
            if payment_result.get("success"):
                payment_url = payment_result.get("payment_url")
                payment_id = payment_result.get("payment_id")
                
                # Сохраняем платеж в БД
                await create_payment(
                    user_id=message.from_user.id,
                    amount=amount,
                    payment_id=payment_id,
                    payment_type="sbp_1payment"
                )
                
                # Отправляем ссылку на оплату
                keyboard = types.InlineKeyboardMarkup(inline_keyboard=[
                    [types.InlineKeyboardButton(text="💳 Оплатить через СБП", url=payment_url)],
                    [types.InlineKeyboardButton(text="🔄 Проверить оплату", callback_data=f"check_payment_{payment_id}")],
                    [types.InlineKeyboardButton(text="❌ Отменить", callback_data="back_to_main")]
                ])
                
                await message.answer(
                    f"💳 <b>Пополнение баланса через 1payment.com</b>\n\n"
                    f"💰 Сумма: {amount}₽\n"
                    f"🆔 Номер платежа: {payment_id}\n\n"
                    f"👆 Нажмите кнопку ниже для оплаты через СБП\n\n"
                    f"⏰ После оплаты нажмите 'Проверить оплату'",
                    reply_markup=keyboard,
                    parse_mode=ParseMode.HTML
                )
                
                await state.clear()
                
            else:
                await callback.message.edit_text(
                    f"❌ <b>Ошибка создания платежа</b>\n\n"
                    f"Не удалось создать платеж: {payment_result.get('error', 'Неизвестная ошибка')}\n"
                    f"Детали: {payment_result.get('details', 'Нет деталей')}\n\n"
                    f"⚠️ <b>Временное решение:</b>\n"
                    f"Обратитесь к администратору для ручного пополнения:\n"
                    f"{config.SUPPORT_USERNAME}\n\n"
                    f"Укажите:\n"
                    f"• Ваш ID: <code>{message.from_user.id}</code>\n"
                    f"• Сумму: {amount}₽\n"
                    f"• Способ оплаты: СБП",
                    parse_mode=ParseMode.HTML
                )
                await state.clear()
                
        except ValueError:
            await message.answer(
                "⚠️ Введите корректную сумму (только цифры)\n"
                "Например: 500\n"
                "Или /cancel для отмены"
            )
    
    # ============ Проверка платежа ============
    @dp.callback_query(F.data.startswith("check_payment_"))
    async def check_payment(callback: types.CallbackQuery):
        payment_id = callback.data.replace("check_payment_", "")
        
        try:
            # Проверяем статус платежа через 1payment.com API
            from sbp_payment import SBPPaymentService
            
            payment_service = SBPPaymentService()
            status_result = payment_service.check_payment_status(payment_id)
            
            if status_result.get("success"):
                status = status_result.get("status")
                
                if status == "paid" or status == "completed":
                    # Платеж успешен - зачисляем средства
                    payment_data = await get_payment_by_id(payment_id)
                    
                    if payment_data and payment_data.get("status") != "completed":
                        amount = payment_data.get("amount")
                        user_id = payment_data.get("user_id")
                        
                        # Обновляем статус платежа
                        await update_payment_status(payment_id, "completed")
                        
                        # Зачисляем средства
                        await update_balance(user_id, amount)
                        
                        new_balance = await get_balance(user_id)
                        
                        await callback.message.edit_text(
                            f"✅ <b>Платеж успешно обработан!</b>\n\n"
                            f"💰 Зачислено: {amount}₽\n"
                            f"💵 Новый баланс: {new_balance}₽\n\n"
                            f"Спасибо за пополнение!",
                            reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[
                                [types.InlineKeyboardButton(text="💰 Мой баланс", callback_data="balance")],
                                [types.InlineKeyboardButton(text="⬅️ В главное меню", callback_data="back_to_main")]
                            ]),
                            parse_mode=ParseMode.HTML
                        )
                    else:
                        await callback.message.edit_text(
                            f"✅ <b>Платеж уже обработан</b>\n\n"
                            f"Средства уже зачислены на ваш баланс.",
                            reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[
                                [types.InlineKeyboardButton(text="💰 Мой баланс", callback_data="balance")],
                                [types.InlineKeyboardButton(text="⬅️ В главное меню", callback_data="back_to_main")]
                            ]),
                            parse_mode=ParseMode.HTML
                        )
                        
                elif status == "pending" or status == "waiting":
                    await callback.message.edit_text(
                        f"⏳ <b>Платеж в обработке</b>\n\n"
                        f"Платеж еще не завершен. Попробуйте проверить через несколько минут.\n\n"
                        f"💡 Если вы уже оплатили, подождите немного - обработка может занять до 5 минут.\n\n"
                        f"📊 Статус: {status_result.get('original_status', 'неизвестно')}",
                        reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[
                            [types.InlineKeyboardButton(text="🔄 Проверить еще раз", callback_data=f"check_payment_{payment_id}")],
                            [types.InlineKeyboardButton(text="⬅️ В главное меню", callback_data="back_to_main")]
                        ]),
                        parse_mode=ParseMode.HTML
                    )
                    
                else:
                    await callback.message.edit_text(
                        f"❌ <b>Платеж не найден или отменен</b>\n\n"
                        f"Статус: {status}\n\n"
                        f"Если вы оплатили, но статус неверный, обратитесь в поддержку: {config.SUPPORT_USERNAME}",
                        reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[
                            [types.InlineKeyboardButton(text="💳 Создать новый платеж", callback_data="topup_balance")],
                            [types.InlineKeyboardButton(text="⬅️ В главное меню", callback_data="back_to_main")]
                        ]),
                        parse_mode=ParseMode.HTML
                    )
            else:
                await callback.message.edit_text(
                    f"❌ <b>Ошибка проверки платежа</b>\n\n"
                    f"Не удалось получить статус платежа.\n"
                    f"Обратитесь в поддержку: {config.SUPPORT_USERNAME}",
                    reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[
                        [types.InlineKeyboardButton(text="🔄 Попробовать еще раз", callback_data=f"check_payment_{payment_id}")],
                        [types.InlineKeyboardButton(text="⬅️ В главное меню", callback_data="back_to_main")]
                    ]),
                    parse_mode=ParseMode.HTML
                )
                
        except Exception as e:
            print(f"Error checking payment: {e}")
            await callback.message.edit_text(
                f"❌ <b>Техническая ошибка</b>\n\n"
                f"Произошла ошибка при проверке платежа.\n"
                f"Обратитесь в поддержку: {config.SUPPORT_USERNAME}",
                reply_markup=types.InlineKeyboardMarkup(inline_keyboard=[
                    [types.InlineKeyboardButton(text="🔄 Попробовать еще раз", callback_data=f"check_payment_{payment_id}")],
                    [types.InlineKeyboardButton(text="⬅️ В главное меню", callback_data="back_to_main")]
                ]),
                parse_mode=ParseMode.HTML
            )
        
        await callback.answer()