# webhook_handler.py - Webhook handler for SBP payment callbacks
import asyncio
import json
from typing import Dict, Any
from sbp_payment import SBPPaymentService
from db import update_payment_status, get_payment_by_id, update_balance
import config


class PaymentWebhookHandler:
    """Handler for payment system webhooks"""
    
    def __init__(self):
        self.payment_service = SBPPaymentService()
    
    async def handle_payment_callback(self, callback_data: Dict[str, Any]) -> Dict[str, str]:
        """
        Handle payment callback from 1payment.com
        
        Args:
            callback_data: Callback data from payment system
            
        Returns:
            Response dictionary for the payment system
        """
        try:
            # Verify callback signature
            if not self.payment_service.verify_callback(callback_data.copy()):
                return {
                    "status": "error",
                    "message": "Invalid signature"
                }
            
            payment_id = callback_data.get("payment_id")
            status = callback_data.get("status")
            amount = callback_data.get("amount")
            
            if not payment_id or not status:
                return {
                    "status": "error",
                    "message": "Missing required parameters"
                }
            
            # Get payment from database
            payment = await get_payment_by_id(payment_id)
            if not payment:
                return {
                    "status": "error",
                    "message": "Payment not found"
                }
            
            # Update payment status
            await update_payment_status(payment_id, status)
            
            # If payment is completed, add balance
            if status == "completed":
                amount_rubles = payment["amount"] // 100  # Convert from kopecks
                await update_balance(payment["user_id"], amount_rubles)
                
                print(f"Payment {payment_id} completed: {amount_rubles} rubles added to user {payment['user_id']}")
            
            return {
                "status": "ok",
                "message": "Callback processed successfully"
            }
            
        except Exception as e:
            print(f"Error processing payment callback: {e}")
            return {
                "status": "error",
                "message": "Internal server error"
            }


# Example Flask integration (optional)
"""
from flask import Flask, request, jsonify

app = Flask(__name__)
webhook_handler = PaymentWebhookHandler()

@app.route('/payment-callback', methods=['POST'])
def payment_callback():
    try:
        callback_data = request.get_json()
        
        # Run async handler
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        result = loop.run_until_complete(
            webhook_handler.handle_payment_callback(callback_data)
        )
        loop.close()
        
        return jsonify(result)
        
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
"""