# mulenpay_service.py - MulenPay payment service for BridgeAPI Bot
import uuid
import asyncio
from typing import Dict, Any, Optional
import config
from mulenpay import MulenPayClient, MulenPayError


class MulenPayService:
    """Service for handling payments through MulenPay API"""
    
    def __init__(self):
        self.secret_key = config.MULENPAY_SECRET_KEY
        self.private_key2 = config.MULENPAY_PRIVATE_KEY2
        self.shop_id = str(config.MULENPAY_SHOP_ID)
        self.client = None
    
    async def _get_client(self) -> MulenPayClient:
        """Get or create MulenPay client"""
        if self.client is None:
            self.client = MulenPayClient(secret_key=self.secret_key)
        return self.client
    
    async def create_payment(
        self, 
        amount: float, 
        user_id: int, 
        description: str = "Пополнение баланса BridgeAPI Bot"
    ) -> Dict[str, Any]:
        """
        Create payment through MulenPay
        
        Args:
            amount: Payment amount in rubles
            user_id: Telegram user ID
            description: Payment description
            
        Returns:
            Dict with payment data or error
        """
        try:
            client = await self._get_client()
            
            # Generate unique payment UUID
            payment_uuid = str(uuid.uuid4())
            
            # Create payment
            result = await client.create_payment(
                private_key2=self.private_key2,
                currency="rub",
                amount=int(amount),  # MulenPay expects integer kopecks
                uuid=payment_uuid,
                shopId=self.shop_id,
                description=description
            )
            
            # Extract payment data
            payment_id = result.get("id")
            widget_url = result.get("widget_url") or result.get("paymentUrl")  # Support both formats
            
            if not payment_id or not widget_url:
                return {
                    "success": False,
                    "error": "Invalid response from MulenPay",
                    "details": "Missing payment_id or widget_url",
                    "raw_response": result
                }
            
            # Try to get QR link from widget
            qr_link = await self._extract_qr_link(widget_url)
            
            return {
                "success": True,
                "payment_id": str(payment_id),
                "payment_uuid": payment_uuid,
                "widget_url": widget_url,
                "qr_link": qr_link,
                "amount": amount,
                "raw_response": result
            }
            
        except MulenPayError as e:
            return {
                "success": False,
                "error": "MulenPay API Error",
                "details": str(e),
                "status_code": e.status_code,
                "payload": e.payload
            }
        except Exception as e:
            return {
                "success": False,
                "error": "Internal error",
                "details": str(e)
            }
    
    async def check_payment_status(self, payment_id: str) -> Dict[str, Any]:
        """
        Check payment status
        
        Args:
            payment_id: Payment ID from create_payment
            
        Returns:
            Dict with payment status
        """
        try:
            client = await self._get_client()
            
            result = await client.get_payment(
                private_key2=self.private_key2,
                payment_id=payment_id
            )
            
            status = result.get("status", "unknown")
            
            # Map MulenPay statuses to our format
            status_map = {
                "paid": "completed",
                "success": "completed", 
                "completed": "completed",
                "pending": "pending",
                "waiting": "pending",
                "created": "pending",
                "failed": "failed",
                "cancelled": "failed",
                "expired": "failed"
            }
            
            mapped_status = status_map.get(status.lower(), "unknown")
            
            return {
                "success": True,
                "status": mapped_status,
                "original_status": status,
                "raw_response": result
            }
            
        except MulenPayError as e:
            return {
                "success": False,
                "error": "MulenPay API Error",
                "details": str(e),
                "status_code": e.status_code
            }
        except Exception as e:
            return {
                "success": False,
                "error": "Internal error",
                "details": str(e)
            }
    
    async def _extract_qr_link(self, widget_url: str) -> Optional[str]:
        """
        Try to extract QR link from MulenPay widget
        
        Args:
            widget_url: Widget URL from MulenPay
            
        Returns:
            QR link or None if failed
        """
        try:
            import httpx
            import re
            
            # Extract UUID from widget URL
            uuid_match = re.search(r'/payment/widget/([a-f0-9-]+)', widget_url)
            if not uuid_match:
                return None
            
            payment_uuid = uuid_match.group(1)
            sbp_url = f'https://mulenpay.ru/payment/widget/{payment_uuid}/sbp'
            
            async with httpx.AsyncClient(timeout=10) as client:
                response = await client.get(sbp_url)
                
                if response.status_code == 200:
                    # Try to find QR link in response
                    content = response.text
                    
                    # Look for various QR link patterns
                    qr_patterns = [
                        r'https://qr\.nspk\.ru/[A-Z0-9]+',
                        r'https://[^"\'>\s]+qr[^"\'>\s]*',
                        r'bank://[^"\'>\s]+',
                        r'https://[^"\'>\s]*sbp[^"\'>\s]*'
                    ]
                    
                    for pattern in qr_patterns:
                        match = re.search(pattern, content, re.IGNORECASE)
                        if match:
                            return match.group(0)
            
            return None
            
        except Exception as e:
            print(f"Error extracting QR link: {e}")
            return None
    
    async def close(self):
        """Close the client connection"""
        if self.client:
            await self.client.aclose()
            self.client = None
    
    def format_payment_amount(self, amount: float) -> str:
        """Format amount for display"""
        return f"{amount:.2f} ₽"
    
    def validate_amount(self, amount: float) -> bool:
        """Validate payment amount"""
        return 1.0 <= amount <= 100000.0  # Min 1 ruble, max 100k rubles