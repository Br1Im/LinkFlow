# admin_handlers.py - Админские функции для BridgeAPI_Bot
from aiogram import types, F
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.context import FSMContext
from aiogram.enums import ParseMode
from aiogram.filters import Command
import asyncio

from db import (
    get_all_users, get_user_by_id, update_balance, get_balance,
    get_user_payments, get_all_payments_stats
)
import config

# FSM состояния для админки
class AdminFSM(StatesGroup):
    waiting_user_id = State()
    waiting_balance_amount = State()
    waiting_broadcast_message = State()

def setup_admin_handlers(dp, bot):
    """Регистрация админских обработчиков"""
    
    # Проверка админских прав
    def is_admin(user_id: int) -> bool:
        return user_id in config.ADMIN_IDS
    
    # ============ Админское меню ============
    @dp.message(Command("admin"))
    async def admin_menu(message: types.Message):
        if not is_admin(message.from_user.id):
            await message.answer("❌ У вас нет прав администратора")
            return
        
        text = (
            "👑 <b>Админ-панель BridgeAPI_Bot</b>\n\n"
            "Выберите действие:"
        )
        
        keyboard = types.InlineKeyboardMarkup(inline_keyboard=[
            [types.InlineKeyboardButton(text="👥 Все пользователи", callback_data="admin_users")],
            [types.InlineKeyboardButton(text="💰 Зачислить баланс", callback_data="admin_add_balance")],
            [types.InlineKeyboardButton(text="📊 Статистика", callback_data="admin_stats")],
            [types.InlineKeyboardButton(text="📢 Рассылка", callback_data="admin_broadcast")],
            [types.InlineKeyboardButton(text="💳 История платежей", callback_data="admin_payments")]
        ])
        
        await message.answer(text, reply_markup=keyboard, parse_mode=ParseMode.HTML)
    
    # ============ Список всех пользователей ============
    @dp.callback_query(F.data == "admin_users")
    async def admin_users_list(callback: types.CallbackQuery):
        if not is_admin(callback.from_user.id):
            await callback.answer("❌ Нет прав")
            return
        
        users = await get_all_users()
        
        if not users:
            await callback.message.edit_text(
                "👥 <b>Пользователи</b>\n\n❌ Пользователей пока нет",
                reply_markup=admin_back_button(),
                parse_mode=ParseMode.HTML
            )
            await callback.answer()
            return
        
        # Формируем список пользователей (по 10 на страницу)
        users_text = "👥 <b>Все пользователи</b>\n\n"
        
        for i, user in enumerate(users[:20], 1):  # Показываем первых 20
            username = user.get('username', 'Без username')
            balance = user.get('balance', 0)
            created = user.get('created_at', 'Неизвестно')[:10]  # Только дата
            
            users_text += (
                f"{i}. <code>{user['user_id']}</code> | @{username}\n"
                f"   💰 {balance}₽ | 📅 {created}\n\n"
            )
        
        if len(users) > 20:
            users_text += f"... и еще {len(users) - 20} пользователей"
        
        users_text += f"\n📊 <b>Всего пользователей: {len(users)}</b>"
        
        keyboard = types.InlineKeyboardMarkup(inline_keyboard=[
            [types.InlineKeyboardButton(text="💰 Зачислить баланс", callback_data="admin_add_balance")],
            [types.InlineKeyboardButton(text="⬅️ Назад", callback_data="admin_menu")]
        ])
        
        await callback.message.edit_text(
            users_text,
            reply_markup=keyboard,
            parse_mode=ParseMode.HTML
        )
        await callback.answer()
    
    # ============ Зачисление баланса ============
    @dp.callback_query(F.data == "admin_add_balance")
    async def admin_add_balance_start(callback: types.CallbackQuery, state: FSMContext):
        if not is_admin(callback.from_user.id):
            await callback.answer("❌ Нет прав")
            return
        
        text = (
            "💰 <b>Зачисление баланса</b>\n\n"
            "Введите ID пользователя:\n\n"
            "💡 <i>Например: 123456789</i>\n"
            "💡 <i>Или отправьте /cancel для отмены</i>"
        )
        
        await callback.message.edit_text(
            text,
            reply_markup=admin_back_button(),
            parse_mode=ParseMode.HTML
        )
        await state.set_state(AdminFSM.waiting_user_id)
        await callback.answer()
    
    @dp.message(AdminFSM.waiting_user_id)
    async def admin_add_balance_user_id(message: types.Message, state: FSMContext):
        if not is_admin(message.from_user.id):
            await state.clear()
            return
        
        if message.text == "/cancel":
            await message.answer("❌ Операция отменена")
            await state.clear()
            return
        
        try:
            user_id = int(message.text.strip())
            
            # Проверяем существование пользователя
            user = await get_user_by_id(user_id)
            if not user:
                await message.answer(
                    f"❌ Пользователь с ID {user_id} не найден\n"
                    f"Попробуйте другой ID или /cancel для отмены"
                )
                return
            
            # Сохраняем ID и запрашиваем сумму
            await state.update_data(target_user_id=user_id)
            
            username = user.get('username', 'Без username')
            current_balance = user.get('balance', 0)
            
            await message.answer(
                f"👤 <b>Пользователь найден</b>\n\n"
                f"🆔 ID: <code>{user_id}</code>\n"
                f"👤 Username: @{username}\n"
                f"💰 Текущий баланс: {current_balance}₽\n\n"
                f"💵 Введите сумму для зачисления:\n\n"
                f"💡 <i>Например: 1000</i>\n"
                f"💡 <i>Или /cancel для отмены</i>",
                parse_mode=ParseMode.HTML
            )
            await state.set_state(AdminFSM.waiting_balance_amount)
            
        except ValueError:
            await message.answer(
                "⚠️ Введите корректный числовой ID\n"
                "Или /cancel для отмены"
            )
    
    @dp.message(AdminFSM.waiting_balance_amount)
    async def admin_add_balance_amount(message: types.Message, state: FSMContext):
        if not is_admin(message.from_user.id):
            await state.clear()
            return
        
        if message.text == "/cancel":
            await message.answer("❌ Операция отменена")
            await state.clear()
            return
        
        try:
            amount = int(message.text.strip())
            
            if amount <= 0:
                await message.answer(
                    "⚠️ Сумма должна быть положительной\n"
                    "Попробуйте еще раз или /cancel для отмены"
                )
                return
            
            data = await state.get_data()
            target_user_id = data.get('target_user_id')
            
            # Получаем данные пользователя
            user = await get_user_by_id(target_user_id)
            old_balance = user.get('balance', 0)
            
            # Зачисляем баланс
            await update_balance(target_user_id, amount)
            new_balance = await get_balance(target_user_id)
            
            # Уведомляем админа
            username = user.get('username', 'Без username')
            
            await message.answer(
                f"✅ <b>Баланс успешно зачислен!</b>\n\n"
                f"👤 Пользователь: @{username} (<code>{target_user_id}</code>)\n"
                f"💰 Было: {old_balance}₽\n"
                f"💰 Зачислено: +{amount}₽\n"
                f"💰 Стало: {new_balance}₽\n\n"
                f"Пользователь получит уведомление.",
                parse_mode=ParseMode.HTML
            )
            
            # Уведомляем пользователя
            try:
                await bot.send_message(
                    target_user_id,
                    f"🎉 <b>Баланс пополнен!</b>\n\n"
                    f"💰 Зачислено: +{amount}₽\n"
                    f"💰 Ваш баланс: {new_balance}₽\n\n"
                    f"Средства зачислены администратором.",
                    parse_mode=ParseMode.HTML
                )
            except Exception as e:
                await message.answer(f"⚠️ Не удалось уведомить пользователя: {e}")
            
            await state.clear()
            
        except ValueError:
            await message.answer(
                "⚠️ Введите корректную сумму (число)\n"
                "Или /cancel для отмены"
            )
    
    # ============ Статистика ============
    @dp.callback_query(F.data == "admin_stats")
    async def admin_stats(callback: types.CallbackQuery):
        if not is_admin(callback.from_user.id):
            await callback.answer("❌ Нет прав")
            return
        
        # Получаем статистику
        users = await get_all_users()
        payments_stats = await get_all_payments_stats()
        
        total_users = len(users)
        total_balance = sum(user.get('balance', 0) for user in users)
        
        # Статистика по платежам
        total_payments = len(payments_stats)
        completed_payments = len([p for p in payments_stats if p.get('status') == 'completed'])
        pending_payments = len([p for p in payments_stats if p.get('status') == 'pending'])
        failed_payments = len([p for p in payments_stats if p.get('status') == 'failed'])
        
        total_revenue = sum(p.get('amount', 0) for p in payments_stats if p.get('status') == 'completed') / 100  # Из копеек в рубли
        
        # Активные пользователи (с балансом > 0)
        active_users = len([u for u in users if u.get('balance', 0) > 0])
        
        text = (
            f"📊 <b>Статистика BridgeAPI_Bot</b>\n\n"
            f"👥 <b>Пользователи:</b>\n"
            f"• Всего: {total_users}\n"
            f"• С балансом: {active_users}\n"
            f"• Общий баланс: {total_balance}₽\n\n"
            f"💳 <b>Платежи:</b>\n"
            f"• Всего: {total_payments}\n"
            f"• Завершено: {completed_payments}\n"
            f"• В обработке: {pending_payments}\n"
            f"• Отклонено: {failed_payments}\n"
            f"• Выручка: {total_revenue:.2f}₽\n\n"
            f"📈 <b>Конверсия:</b>\n"
            f"• Платящие: {(completed_payments/total_users*100 if total_users > 0 else 0):.1f}%\n"
            f"• Успешность: {(completed_payments/total_payments*100 if total_payments > 0 else 0):.1f}%"
        )
        
        await callback.message.edit_text(
            text,
            reply_markup=admin_back_button(),
            parse_mode=ParseMode.HTML
        )
        await callback.answer()
    
    # ============ История платежей ============
    @dp.callback_query(F.data == "admin_payments")
    async def admin_payments(callback: types.CallbackQuery):
        if not is_admin(callback.from_user.id):
            await callback.answer("❌ Нет прав")
            return
        
        payments = await get_all_payments_stats()
        
        if not payments:
            await callback.message.edit_text(
                "💳 <b>История платежей</b>\n\n❌ Платежей пока нет",
                reply_markup=admin_back_button(),
                parse_mode=ParseMode.HTML
            )
            await callback.answer()
            return
        
        # Показываем последние 15 платежей
        text = "💳 <b>Последние платежи</b>\n\n"
        
        for i, payment in enumerate(payments[-15:], 1):
            user_id = payment.get('user_id', 'N/A')
            amount = payment.get('amount', 0) / 100  # Из копеек в рубли
            status = payment.get('status', 'unknown')
            created = payment.get('created_at', 'N/A')[:16]  # Дата и время
            
            status_emoji = {
                'completed': '✅',
                'pending': '⏳',
                'failed': '❌'
            }.get(status, '❓')
            
            text += (
                f"{i}. {status_emoji} {amount}₽ | <code>{user_id}</code>\n"
                f"   📅 {created}\n\n"
            )
        
        if len(payments) > 15:
            text += f"... и еще {len(payments) - 15} платежей"
        
        await callback.message.edit_text(
            text,
            reply_markup=admin_back_button(),
            parse_mode=ParseMode.HTML
        )
        await callback.answer()
    
    # ============ Рассылка ============
    @dp.callback_query(F.data == "admin_broadcast")
    async def admin_broadcast_start(callback: types.CallbackQuery, state: FSMContext):
        if not is_admin(callback.from_user.id):
            await callback.answer("❌ Нет прав")
            return
        
        text = (
            "📢 <b>Рассылка сообщения</b>\n\n"
            "Введите текст для рассылки всем пользователям:\n\n"
            "💡 <i>Поддерживается HTML разметка</i>\n"
            "💡 <i>Или /cancel для отмены</i>"
        )
        
        await callback.message.edit_text(
            text,
            reply_markup=admin_back_button(),
            parse_mode=ParseMode.HTML
        )
        await state.set_state(AdminFSM.waiting_broadcast_message)
        await callback.answer()
    
    @dp.message(AdminFSM.waiting_broadcast_message)
    async def admin_broadcast_send(message: types.Message, state: FSMContext):
        if not is_admin(message.from_user.id):
            await state.clear()
            return
        
        if message.text == "/cancel":
            await message.answer("❌ Рассылка отменена")
            await state.clear()
            return
        
        broadcast_text = message.text
        users = await get_all_users()
        
        if not users:
            await message.answer("❌ Нет пользователей для рассылки")
            await state.clear()
            return
        
        # Подтверждение рассылки
        confirm_text = (
            f"📢 <b>Подтверждение рассылки</b>\n\n"
            f"👥 Получателей: {len(users)}\n\n"
            f"📝 <b>Текст сообщения:</b>\n"
            f"{broadcast_text}\n\n"
            f"❓ Отправить рассылку?"
        )
        
        keyboard = types.InlineKeyboardMarkup(inline_keyboard=[
            [
                types.InlineKeyboardButton(text="✅ Отправить", callback_data="confirm_broadcast"),
                types.InlineKeyboardButton(text="❌ Отмена", callback_data="admin_menu")
            ]
        ])
        
        await message.answer(confirm_text, reply_markup=keyboard, parse_mode=ParseMode.HTML)
        await state.update_data(broadcast_text=broadcast_text, users=users)
    
    @dp.callback_query(F.data == "confirm_broadcast")
    async def admin_broadcast_confirm(callback: types.CallbackQuery, state: FSMContext):
        if not is_admin(callback.from_user.id):
            await callback.answer("❌ Нет прав")
            return
        
        data = await state.get_data()
        broadcast_text = data.get('broadcast_text')
        users = data.get('users', [])
        
        # Начинаем рассылку
        await callback.message.edit_text(
            f"📢 <b>Рассылка запущена...</b>\n\n"
            f"👥 Отправляем {len(users)} пользователям\n"
            f"⏳ Пожалуйста, подождите...",
            parse_mode=ParseMode.HTML
        )
        await callback.answer()
        
        # Отправляем сообщения
        sent = 0
        failed = 0
        
        for user in users:
            try:
                await bot.send_message(
                    user['user_id'],
                    broadcast_text,
                    parse_mode=ParseMode.HTML
                )
                sent += 1
                
                # Небольшая задержка чтобы не превысить лимиты
                await asyncio.sleep(0.1)
                
            except Exception as e:
                failed += 1
                print(f"Failed to send to {user['user_id']}: {e}")
        
        # Результат рассылки
        result_text = (
            f"📢 <b>Рассылка завершена!</b>\n\n"
            f"✅ Отправлено: {sent}\n"
            f"❌ Не доставлено: {failed}\n"
            f"📊 Успешность: {(sent/(sent+failed)*100 if (sent+failed) > 0 else 0):.1f}%"
        )
        
        await callback.message.edit_text(
            result_text,
            reply_markup=admin_back_button(),
            parse_mode=ParseMode.HTML
        )
        
        await state.clear()
    
    # ============ Возврат в админ меню ============
    @dp.callback_query(F.data == "admin_menu")
    async def admin_menu_callback(callback: types.CallbackQuery):
        if not is_admin(callback.from_user.id):
            await callback.answer("❌ Нет прав")
            return
        
        text = (
            "👑 <b>Админ-панель BridgeAPI_Bot</b>\n\n"
            "Выберите действие:"
        )
        
        keyboard = types.InlineKeyboardMarkup(inline_keyboard=[
            [types.InlineKeyboardButton(text="👥 Все пользователи", callback_data="admin_users")],
            [types.InlineKeyboardButton(text="💰 Зачислить баланс", callback_data="admin_add_balance")],
            [types.InlineKeyboardButton(text="📊 Статистика", callback_data="admin_stats")],
            [types.InlineKeyboardButton(text="📢 Рассылка", callback_data="admin_broadcast")],
            [types.InlineKeyboardButton(text="💳 История платежей", callback_data="admin_payments")]
        ])
        
        await callback.message.edit_text(text, reply_markup=keyboard, parse_mode=ParseMode.HTML)
        await callback.answer()


def admin_back_button() -> types.InlineKeyboardMarkup:
    """Кнопка возврата в админ меню"""
    return types.InlineKeyboardMarkup(
        inline_keyboard=[
            [types.InlineKeyboardButton(text="⬅️ Админ меню", callback_data="admin_menu")]
        ]
    )