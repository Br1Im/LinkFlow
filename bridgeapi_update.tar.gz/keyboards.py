# keyboards.py - Клавиатуры объединенного бота
from aiogram import types
from typing import List

def main_menu(has_horoscope: bool = False) -> types.InlineKeyboardMarkup:
    """Главное меню с приветствием"""
    return types.InlineKeyboardMarkup(
        inline_keyboard=[
            # Длинные кнопки
            [types.InlineKeyboardButton(text="📄 Политика конфиденциальности", callback_data="privacy_policy")],
            [types.InlineKeyboardButton(text="📋 Пользовательское соглашение", callback_data="user_agreement")],
            # Премиум функция
            [types.InlineKeyboardButton(text="🎨 AI Генератор изображений", callback_data="ai_image_generator")],
            # Две колонки
            [
                types.InlineKeyboardButton(text="💎 Платные каналы", callback_data="subscriptions"),
                types.InlineKeyboardButton(text="🤖 AI-инструменты", callback_data="ai_tools"),
            ],
            [
                types.InlineKeyboardButton(text="🔮 Гороскоп AI", callback_data="horoscope"),
                types.InlineKeyboardButton(text="💰 Баланс", callback_data="balance"),
            ],
            [
                types.InlineKeyboardButton(text="📞 Контакты", callback_data="support"),
            ],
        ]
    )

def subscriptions_menu() -> types.InlineKeyboardMarkup:
    """Меню выбора канала для подписки"""
    return types.InlineKeyboardMarkup(
        inline_keyboard=[
            [types.InlineKeyboardButton(text="🪙 Крипто-канал", callback_data="channel_crypto")],
            [types.InlineKeyboardButton(text="💪 Фитнес-канал", callback_data="channel_fitness")],
            [types.InlineKeyboardButton(text="🥗 Питание", callback_data="channel_nutrition")],
            [types.InlineKeyboardButton(text="🤖 AI-канал", callback_data="channel_ai")],
            [types.InlineKeyboardButton(text="⬅️ Назад", callback_data="back_to_main")],
        ]
    )

def balance_menu() -> types.InlineKeyboardMarkup:
    """Меню баланса"""
    return types.InlineKeyboardMarkup(
        inline_keyboard=[
            [types.InlineKeyboardButton(text="💳 Пополнить баланс", callback_data="topup_balance")],
            [types.InlineKeyboardButton(text="⬅️ Назад", callback_data="back_to_main")],
        ]
    )

def back_button() -> types.InlineKeyboardMarkup:
    """Простая кнопка назад"""
    return types.InlineKeyboardMarkup(
        inline_keyboard=[
            [types.InlineKeyboardButton(text="⬅️ Назад", callback_data="back_to_main")],
        ]
    )

def horoscope_menu(has_subscription: bool) -> types.InlineKeyboardMarkup:
    """Меню гороскопа"""
    return types.InlineKeyboardMarkup(
        inline_keyboard=[
            [types.InlineKeyboardButton(text="🔮 Получить гороскоп", callback_data="get_horoscope")],
            [types.InlineKeyboardButton(text="⬅️ Назад", callback_data="back_to_main")]
        ]
    )

def ai_image_generator_menu() -> types.InlineKeyboardMarkup:
    """Меню AI Генератора изображений"""
    return types.InlineKeyboardMarkup(
        inline_keyboard=[
            [types.InlineKeyboardButton(text="🖼 Генерация изображений - 120₽", callback_data="ai_generate_image")],
            [types.InlineKeyboardButton(text="🎤 Синтез речи - 50₽", callback_data="ai_text_to_speech")],
            [types.InlineKeyboardButton(text="🎭 Оживление фото - 130₽", callback_data="ai_animate_photo")],
            [types.InlineKeyboardButton(text="🎬 Генерация видео - 150₽", callback_data="ai_generate_video")],
            [types.InlineKeyboardButton(text="⬅️ Назад", callback_data="back_to_main")],
        ]
    )

def ai_tools_menu() -> types.InlineKeyboardMarkup:
    """Меню AI-инструментов"""
    return types.InlineKeyboardMarkup(
        inline_keyboard=[
            [types.InlineKeyboardButton(text="📝 Генератор постов - 5₽", callback_data="generate_post")],
            [types.InlineKeyboardButton(text="💡 Генератор названий - 10₽", callback_data="generate_names")],
            [types.InlineKeyboardButton(text="🎯 Персональный промпт - 15₽", callback_data="generate_prompt")],
            [types.InlineKeyboardButton(text="💧 Калькулятор воды - 10₽", callback_data="water_calculator")],
            [types.InlineKeyboardButton(text="🍽 Расчет БЖУ - 10₽", callback_data="bju_calculator")],
            [types.InlineKeyboardButton(text="🪙 Топ-3 монет - 5₽", callback_data="crypto_top3")],
            [types.InlineKeyboardButton(text="🏦 Надежные биржи - 5₽", callback_data="crypto_exchanges")],
            [types.InlineKeyboardButton(text="🔮 Крипто-гороскоп - 10₽", callback_data="crypto_horoscope")],
            [types.InlineKeyboardButton(text="🎨 Генерация изображений - 120₽", callback_data="ai_generate_image")],
            [types.InlineKeyboardButton(text="🎤 Синтез речи - 50₽", callback_data="ai_text_to_speech")],
            [types.InlineKeyboardButton(text="🎬 Генерация видео - 150₽", callback_data="ai_generate_video")],
            [types.InlineKeyboardButton(text="⬅️ Назад", callback_data="back_to_main")],
        ]
    )
