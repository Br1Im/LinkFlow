# Crypto Bot (@crypto_vip_robot) - Локальный запуск

## Текущая конфигурация

- **Бот**: @crypto_vip_robot
- **Канал**: -1003227332437
- **Админ**: 7687872174
- **Тариф**: 450₽ за 1 месяц (225 Stars)

## Запуск бота локально

1. Установить зависимости:
```bash
pip install -r requirements.txt
```

2. Запустить бота:
```bash
python run.py
```

## Запуск на сервере

Бот уже установлен на сервере 85.192.56.74 в директории `/root/Cryptoliqbez`

Для запуска через PM2:
```bash
cd /root/Cryptoliqbez
pm2 start --name crypto-bot --interpreter python3.11 run.py
pm2 save
```

Для перезапуска:
```bash
pm2 restart crypto-bot
```

Для просмотра логов:
```bash
pm2 logs crypto-bot
```

## Структура бота

- `run.py` - главный файл запуска
- `config.py` - конфигурация (читает из .env)
- `handlers_public.py` - обработчики для пользователей
- `handlers_admin.py` - обработчики для админов
- `tariffs.py` - тарифы подписки
- `keyboards.py` - клавиатуры бота
- `db.py` - работа с базой данных
- `services.py` - вспомогательные функции
- `tasks.py` - фоновые задачи
- `payments/` - модули оплаты (YooKassa, TON, Stars, IntellectMoney, Tribute)

## Примечания

- Бот использует SQLite базу данных `subscriptions.db`
- Логи записываются в `bot.log`
- Для работы нужен Python 3.11+
