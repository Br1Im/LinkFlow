# Инструкция по установке crypto_vip_robot на сервер

## Шаг 1: Подготовка файлов

Файлы для загрузки на сервер (без venv и кэша):
- `*.py` - все Python файлы
- `.env` - конфигурация
- `requirements.txt` - зависимости
- `payments/` - папка с модулями оплаты
- `subscriptions.db` - база данных (с включенными способами оплаты)

## Шаг 2: Загрузка на сервер

```bash
# На локальной машине создайте архив (без venv)
cd crypto_bot_backup
tar -czf crypto_bot.tar.gz *.py .env requirements.txt payments/ subscriptions.db *.json *.md

# Загрузите на сервер
scp crypto_bot.tar.gz root@85.192.56.74:/root/

# Подключитесь к серверу
ssh root@85.192.56.74
```

## Шаг 3: Установка на сервере

```bash
# Остановите старого бота
pm2 stop crypto-bot
pm2 delete crypto-bot

# Создайте резервную копию
cd /root
mv Cryptoliqbez Cryptoliqbez_backup_$(date +%Y%m%d_%H%M%S)

# Распакуйте новые файлы
mkdir Cryptoliqbez
cd Cryptoliqbez
tar -xzf ../crypto_bot.tar.gz

# Установите зависимости
pip3.11 install -r requirements.txt

# Удалите кэш Python
find . -type d -name __pycache__ -exec rm -rf {} + 2>/dev/null || true
find . -type f -name "*.pyc" -delete

# Проверьте .env файл
cat .env

# Запустите бота
pm2 start --name crypto-bot --interpreter python3.11 run.py
pm2 save

# Проверьте логи
pm2 logs crypto-bot --lines 50
```

## Шаг 4: Проверка работы

1. Отправьте /start боту @crypto_vip_robot
2. Проверьте приветственное сообщение
3. Нажмите "Подписка" → должна показаться информация о стоимости
4. Нажмите "Ввести сумму" → введите сумму (например, 3500)
5. Должны появиться способы оплаты

## Важные команды PM2

```bash
# Просмотр логов
pm2 logs crypto-bot

# Перезапуск
pm2 restart crypto-bot

# Остановка
pm2 stop crypto-bot

# Статус
pm2 status

# Удаление из PM2
pm2 delete crypto-bot
```

## Откат к старой версии (если что-то пошло не так)

```bash
pm2 stop crypto-bot
pm2 delete crypto-bot
cd /root
rm -rf Cryptoliqbez
mv Cryptoliqbez_backup_YYYYMMDD_HHMMSS Cryptoliqbez
cd Cryptoliqbez
pm2 start --name crypto-bot --interpreter python3.11 run.py
pm2 save
```

## Что изменилось в новой версии

1. ✅ Новый приветственный текст про криптовалюты
2. ✅ Кастомный payment flow с вводом суммы 3000-5000₽
3. ✅ Автоматический расчёт персонального ведения (100₽/день, макс 20 дней)
4. ✅ Исправлен путь к базе данных (теперь относительный)
5. ✅ Включены все способы оплаты в базе данных
